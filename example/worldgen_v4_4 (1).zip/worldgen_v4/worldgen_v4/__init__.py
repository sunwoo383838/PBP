"""worldgen 4.1: deterministic scenario generation, no LLM calls."""
__version__ = "4.1.0"

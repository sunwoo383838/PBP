"""추적 월드(TracingWorld): 정답 함수가 세계를 읽는 유일한 통로.

읽기마다 need와 출처를 기록한다. 출처 타입:
  rule      규정 문서 {ref}              (규칙 값은 여기서만 읽는다)
  db        등록된 최신 버전 {key, v}
  db_query  없는 레코드(ABSENT) 또는 집계 {key|query, result, reads}
  frag      이력 조각 {frag: holders...}   (operational 조각, 또는 최신 버전이 아직 DB에 없는 db_pending 조각)
반사실 지점(stale / partial / neardup / wrong_owner)은 기준 실행에서 전부 열거되고(points),
mode=(이름, 번호|"all")로 다시 실행하면 그 지점만 비튼다.
"""
import collections

from .const import NUMERIC_ATTR, SOFTWARE, TIER_RANK
from .world import Skip, kstr

DOMAIN_ROLE = {"HR": "records", "IT": "access", "FIN": "budgeting", "PROC": "buying", "LEGAL": "compliance"}


class TW:
    def __init__(t, w, root, mode=None):
        t.w, t.root, t.day, t.mode = w, root, w.day, mode
        t.needs, t.cur = [], None
        t.cnt, t.points, t.hit, t.ops, t.resolved = collections.Counter(), [], [], [], {}

    # ── 기록 기본 ──
    def begin(t, sem, g, role):
        t.cur = {"sem": sem, "group": g, "role": role, "order": len(t.needs) + 1, "local": g == t.root,
                 "sources": [], "card": t.w.card(g, role)}
        t.needs.append(t.cur)

    def _pt(t, name, at):
        """반사실 지점 등록. 원격 need에서만. 기준 실행이면 열거, mode 실행이면 해당 지점에서 True."""
        if t.cur is None or t.cur["local"]: return False
        k = t.cnt[name]; t.cnt[name] += 1
        if t.mode is None: t.points.append({"mode": name, "idx": k, "need": t.cur["sem"], "at": at})
        if t.mode is not None and t.mode[0] == name and (t.mode[1] == "all" or t.mode[1] == k):
            t.hit.append(k); return True
        return False

    def op(t, tier, why): t.ops.append([tier, why])

    def catalog(t, group, collection, entity):
        key = f"{collection}/{entity}"
        value = t.w.catalog[group][key]
        prev = t.cur
        if t.cur is None or t.cur["group"] != group:
            t.begin(f"{group}/catalog/{key}", group, DOMAIN_ROLE[group.split('-')[0]])
        t.cur["sources"].append({"type": "catalog", "group": group, "key": key})
        t.cur = prev
        return value

    def rule(t, rid):
        R = t.w.rules[rid]                                 # 없으면 KeyError: 규정에 없는 규칙은 쓸 수 없다
        g = R["group"]
        if t.cur is not None and t.cur["group"] == g:
            t.cur["sources"].append({"type": "rule", "ref": rid})
        else:                                               # 다른 그룹 규칙 → 별도 need로 기록하고 현재 need 유지
            prev = t.cur; t.begin(f"{g}/rule/{rid.split('.', 1)[1]}", g, DOMAIN_ROLE[g.split('-')[0]])
            t.cur["sources"].append({"type": "rule", "ref": rid}); t.cur = prev
        return R["params"]

    def db(t, key, numeric=None):
        num = NUMERIC_ATTR.get((key[1], key[3]), True) if numeric is None else numeric
        vs = t.w.db.get(key, [])
        if not vs:
            t.cur["sources"].append({"type": "db_query", "key": kstr(key), "result": "ABSENT", "asof": t.day}); return None
        latest = vs[-1]
        if latest["db_day"] <= t.day:                                   # DB에 등록된 최신값
            stale = len(vs) > 1 and t._pt("stale", kstr(key))
            t.cur["sources"].append({"type": "db", "key": kstr(key), "v": latest["v"]})
            return vs[-2]["value"] if stale else latest["value"]
        vis = [v for v in vs if v["db_day"] <= t.day]                    # 최신값은 아직 이력에만 있음
        if t._pt("partial", latest["fid"]): return vs[-2]["value"] if len(vs) > 1 else None   # 최신 조각만 빠지면 직전 버전이 보인다
        stale = len(vs) > 1 and t._pt("stale", kstr(key))
        t.cur["sources"].append({"type": "frag", "key": kstr(key), "v": latest["v"], "db_visible_v": vis[-1]["v"] if vis else "ABSENT",
                                 "frag": t.w.fsrc(latest["fid"], num)})
        return vs[-2]["value"] if stale else latest["value"]

    def frag(t, fid, numeric=None, distractor=False):
        f = t.w.frags[fid]; num = f["numeric"] if numeric is None else numeric
        if distractor:
            t.cur["sources"].append({"type": "frag", "role": "distractor", "frag": t.w.fsrc(fid, num)}); return True
        if t._pt("partial", fid): return False
        t.cur["sources"].append({"type": "frag", "frag": t.w.fsrc(fid, num)}); return True

    def agg(t, query, result, reads):
        t.cur["sources"].append({"type": "db_query", "query": query, "result": result, "reads": reads})

    def neg(t, what):
        """부재 관측: 확인했지만 해당 기록·메모가 없었다는 사실도 정답에 필요한 관측이다."""
        t.cur["sources"].append({"type": "negative", "query": what, "result": []})

    def near_emp(t, e):
        r = t.w.emps[e]["region"]; allr = sorted(x for x in t.w.emps if t.w.emps[x]["region"] == r)
        return allr[(allr.index(e) + 1) % len(allr)]

    # ═════════ HR ═════════
    def hr_profile(t, e):
        r = t.w.emps[e]["region"]; g = f"HR-{r}"; t.begin(f"{g}/{e}/profile", g, "records")
        if t._pt("neardup", e): e = t.near_emp(e)
        t.catalog(g, "employees", e)
        p = t.db((g, "emp", e, "profile"))
        if p is None: raise Skip
        return p

    def hr_timeline(t, e):
        """부서 배치 타임라인: 현재 소속 + 발효 전 승인된 이동(operational 조각)."""
        r = t.w.emps[e]["region"]; g = f"HR-{r}"; t.begin(f"{g}/{e}/assignment_timeline", g, "records")
        if t._pt("neardup", e): e = t.near_emp(e)
        t.catalog(g, "employees", e)
        p = t.db((g, "emp", e, "profile"))
        if p is None: raise Skip
        pol = t.rule(f"{g}.transfer_effective_day")
        tr = t.w.transfers.get(e); pend = None
        if tr and tr["status"] == "approved" and t.frag(tr["fid"]): pend = tr
        else: t.neg(f"{g} memo on an approved, not yet effective transfer: {e}")
        return {"dept": p["dept"], "to": pend["to"] if pend else None, "eff": pend["eff"] if pend else None, "inclusive": pol["inclusive"],
                "contract": p["contract"], "grade": p["grade"], "status": p["status"], "hire_day": p["hire_day"]}

    def dept_on(t, x, day):
        if x["to"]:
            t.op("R2", "transfer_date_branch")
            moved = day >= x["eff"] if x["inclusive"] else day > x["eff"]
            return x["to"] if moved else x["dept"]
        return x["dept"]

    def hr_headcount(t, r, dept, excl_contract=False):
        """배분 계획 인원: 재직 인원(records·payroll 기록) + 기간 내 입사 확정자(recruiting 메모) ± 기간 내 발효 이동(mobility 메모)."""
        g = f"HR-{r}"; t.begin(f"{g}/{dept}/planning_headcount" + ("-regular" if excl_contract else ""), g, "records")
        if t._pt("neardup", dept): dept = t.w.sibling(r, dept)
        pol = t.rule(f"{g}.headcount_definition"); plan = t.rule(f"{g}.planning_headcount"); H = plan["horizon"]; n, n_db, reads = 0, 0, []
        ok = lambda v: bool(v) and v["status"] == pol["count_status"] and not (excl_contract and v["contract"] == "contractor")
        moves = {e: tr for e, tr in t.w.transfers.items() if plan["apply_transfers"] and tr["status"] == "approved"
                 and t.w.emps[e]["region"] == r and t.day < tr["eff"] <= t.day + H}
        memo = False
        for e in sorted(t.w.emps):
            if t.w.emps[e]["region"] != r: continue
            key = (g, "emp", e, "profile"); vs = t.w.db.get(key)
            if not vs: continue
            mv = moves.get(e)
            rel = lambda v: bool(v) and (v["dept"] == dept or bool(mv and mv["to"] == dept))
            inc = lambda v: ok(v) and v["dept"] == dept
            vis = [v for v in vs if v["db_day"] <= t.day]
            if vs[-1]["db_day"] <= t.day:
                if not (rel(vs[-1]["value"]) or (len(vs) > 1 and rel(vs[-2]["value"]))): continue
                if len(vs) > 1 and inc(vs[-1]["value"]) != inc(vs[-2]["value"]):
                    val = t.db(key)                                 # 직전 버전이면 셈이 달라지는 레코드 → stale 지점으로 기록
                else:
                    val = vs[-1]["value"]; reads.append([kstr(key), vs[-1]["v"]])
            else:
                if not (rel(vs[-1]["value"]) or (vis and rel(vis[-1]["value"]))): continue
                val = t.db(key)                                     # 미등록 변경: 이력 조각이 출처
            if not ok(val): continue
            d = val["dept"]; n_db += int(d == dept)
            if mv and (d == dept or mv["to"] == dept):
                memo = True
                if t.frag(mv["fid"]): t.op("R2", "planned_transfer"); d = mv["to"]
            if d == dept: n += 1
        if plan["include_confirmed_hires"]:
            for o in t.w.offers:
                if o["region"] == r and o["dept"] == dept and o["status"] == "offered" and o["start"] <= t.day + H \
                        and not (excl_contract and o["contract"] == "contractor"):
                    memo = True
                    if t.frag(o["fid"]): t.op("R2", "confirmed_hire"); n += 1
        if not memo: t.neg(f"{g} {dept} memos on confirmed hires / transfers within the horizon")
        t.agg(f"COUNT(emp WHERE region={r} AND dept={dept} AND status={pol['count_status']}" + (" AND contract=regular" if excl_contract else "") + ")", n_db, reads)
        t.op("R1", "aggregate_count")
        return n

    # ═════════ FIN ═════════
    def commit_state(t, c):
        key = (c["group"], "commit", c["cid"], "status")
        if t.w.db.get(key): return t.db(key)
        if t.frag(c["review_fid"]):
            return {"status": "reviewing", "amount": c["amount"], "expected_settle": c["expected_settle"]}
        return None

    def fin_schedule(t, r, dept):
        """부서 라인의 잔액과 차감 대상(검토 중·가승인) 목록. 집행 주체 예외가 있으면 다른 지역 재무로 간다."""
        g0 = f"FIN-{r}"; t.begin(f"{g0}/{dept}/budget_schedule", g0, "budgeting"); dept0 = dept
        if t._pt("neardup", dept): dept = t.w.sibling(r, dept)
        rr = r
        for x in t.w.owner_exc:
            if x["dept"] == dept and x["from"] == r and x["start"] <= t.day <= x["end"]:
                if t._pt("wrong_owner", dept): break
                if t.frag(x["fid"]) and t.rule(f"{g0}.owner_exception")["exception_overrides_owner"]:
                    t.op("R2", "owner_exception"); rr = x["to"]
                break
        g = f"FIN-{rr}"; t.resolved[(r, dept0)] = (g, dept)          # 같은 과제의 재설정 조회도 같은 그룹·같은(혼동된) 부서를 쓴다
        if rr != r: t.begin(f"{g}/{dept}/budget_schedule", g, "budgeting")
        rem = t.db((g, "line", dept, "remaining"))
        if rem is None: raise Skip
        pol = t.rule(f"{g}.pending_deduction"); statuses = pol["deduct_statuses"]
        last = (lambda s: s - 1) if pol["deduct_until"] == "day_before_settle" else (lambda s: s)   # 차감 마지막 날
        pend, reads = [], []
        if pol["earmarks_deducted"]:
            for x in t.w.earmarks:
                if x["group"] == g and x["dept"] == dept and x["start"] <= t.day <= x["end"] and t.frag(x["fid"]):
                    pend.append((x["amount"], x["end"], "earmark:" + x["fid"]))          # 선점은 기한 당일까지
        for cid in sorted(t.w.commits):
            c = t.w.commits[cid]
            if c["group"] != g or c["dept"] != dept: continue
            key = (g, "commit", cid, "status"); vs = t.w.db.get(key)
            if vs and vs[-1]["db_day"] <= t.day and not (len(vs) > 1 and (vs[-1]["value"]["status"] in statuses) != (vs[-2]["value"]["status"] in statuses)):
                st = vs[-1]["value"]; reads.append([kstr(key), vs[-1]["v"]])   # 등록된 값, 이전 버전과 차감 여부 같음 → 조회 결과로만
            else:
                st = t.commit_state(c)
            if st and st["status"] in statuses: pend.append((st["amount"], last(st["expected_settle"]), cid))
        t.agg(f"SELECT commit WHERE group={g} AND dept={dept} AND status IN {statuses}", [p[2] for p in pend], reads)
        t.op("R1", "deduct_pending")
        return rem, [(a, s) for a, s, _ in pend]

    @staticmethod
    def avail_on(rem, pend, d):
        """규정 4.2: pend = [(금액, 차감 마지막 날)]. d일의 집행 가능액 = 잔액 − (마지막 날 ≥ d인 금액 합)."""
        return rem - sum(a for a, last in pend if last >= d)

    def fin_available(t, r, dept):
        rem, pend = t.fin_schedule(r, dept)
        return t.avail_on(rem, pend, t.day)

    def fin_reset(t, r, dept):
        """다음 재설정일과 기준 배정액. 집행 주체 예외로 옮겨진 라인은 옮겨간 재무 그룹의 라인이 재설정된다."""
        g, dept = t.resolved.get((r, dept), (f"FIN-{r}", dept)); t.begin(f"{g}/{dept}/next_reset", g, "budgeting")
        days = t.rule(f"{g}.reset_calendar")["days"]
        return next((d for d in days if d > t.day), None), t.db((g, "line", dept, "base"))

    def fin_approval(t, r, amount, prof, dept):
        g = f"FIN-{r}"; t.begin(f"{g}/approval", g, "budgeting")
        tiers = t.rule(f"{g}.approval_tiers")["tiers"]
        appr, gov = next(who for lim, who in tiers if lim is None or amount <= lim), "tiers"
        nw = t.rule(f"{g}.newcomer_waiver"); t.op("R1", "approval_policy")
        if t.day - prof["hire_day"] <= nw["days"] and amount <= nw["cap"]:
            appr, gov = nw["approver"], "newcomer_waiver"; t.op("R2", "newcomer_waiver")
        for q in t.w.q_exc:
            if q["region"] == r and q["dept"] == dept and q["start"] <= t.day <= q["end"] and amount > q["threshold"]:
                if t.frag(q["fid"]):
                    appr, gov = t.rule(f"{g}.q_exception_approver")["approver"], "q_exception"; t.op("R2", "q_exception")
        return appr, gov

    # ═════════ IT ═════════
    def it_tier(t, r, grade, e=None):
        g = f"IT-{r}"; t.begin(f"{g}/eligibility" + (f"/{e}" if e else ""), g, "access"); t.op("R1", "eligibility_policy")
        tier = t.rule(f"{g}.eligibility")["grade_tier"][str(grade)]
        if e:
            for x in t.w.tier_exc:
                if x["emp"] == e and x["start"] <= t.day <= x["end"] and t.frag(x["fid"]) and t.rule(f"{g}.tier_exception")["exception_raises_tier"]:
                    if TIER_RANK[x["tier"]] > TIER_RANK[tier]: tier = x["tier"]; t.op("R2", "tier_exception")
        return tier

    def it_inventory(t, r, itype):
        g = f"IT-{r}"; t.begin(f"{g}/inventory/{itype}", g, "assets"); hp = t.rule(f"{g}.hold_policy")["holds_reduce_available"]; out = []
        for iid in sorted(t.w.inv):
            x = t.w.inv[iid]
            if x["region"] != r or x["type"] != itype: continue
            x = t.catalog(g, "inventory", iid)
            q = t.db((g, "inv", iid, "qty")) or 0
            for hd in t.w.holds:
                if hp and hd["iid"] == iid and hd["start"] <= t.day <= hd["end"] and t.frag(hd["fid"]): q -= 1
            if q > 0: out.append({"id": iid, "tier": x["tier"], "cost": x["cost"], "country": r, "lead": 0, "lead_ok": True, "excluded": False, "vendor": None})
        return out

    def it_stock(t, r, iid):
        """한 품목의 가용 재고 = 등록 수량(assets 기록) − 유효 홀드(provisioning·assets 메모)."""
        g = f"IT-{r}"; t.begin(f"{g}/stock/{iid}", g, "assets")
        t.catalog(g, "inventory", iid); hp = t.rule(f"{g}.hold_policy")["holds_reduce_available"]
        q = t.db((g, "inv", iid, "qty")) or 0; memo = False
        for hd in t.w.holds:
            if hp and hd["iid"] == iid and hd["start"] <= t.day <= hd["end"]:
                memo = True
                if t.frag(hd["fid"]): q -= 1
        if not memo: t.neg(f"{g} {iid} memos on active holds")
        t.op("R1", "available_stock")
        return q

    def it_assets(t, e):
        r = t.w.emps[e]["region"]; g = f"IT-{r}"; t.begin(f"{g}/{e}/assets", g, "assets")
        if t._pt("neardup", e): e = t.near_emp(e)
        out = []
        for aid in sorted(t.w.assets):
            if e in t.w.assets[aid]["history"]:
                v = t.db((g, "asset", aid, "holder"))
                if v and v.get("emp") == e: out.append(aid)
        t.agg(f"SELECT asset WHERE holder={e}", out, [])                   # 빈 결과도 관측으로 기록
        return out

    def it_free(t, r, sw):
        g = f"IT-{r}"; t.begin(f"{g}/license/{sw}", g, "licenses")
        if t._pt("neardup", sw): sw = SOFTWARE[(SOFTWARE.index(sw) + 1) % len(SOFTWARE)]
        v = t.db((g, "lic", sw, "seats")); hp = t.rule(f"{g}.hold_policy")["holds_reduce_available"]; res = 0
        for x in t.w.reservations:
            if hp and x["sw"] == sw and x["region"] == r and x["start"] <= t.day <= x["end"] and t.frag(x["fid"]): res += x["n"]
        return v["seats"] - v["used"] - res

    def commit_pick(t, cid):
        """과제 문장의 가승인 번호로 건을 집는다. neardup: 번호가 이웃한 다른 건과 혼동."""
        if t._pt("neardup", cid):
            g = t.w.commits[cid]["group"]; cs = sorted(c for c, x in t.w.commits.items() if x["group"] == g)
            cid = cs[(cs.index(cid) + 1) % len(cs)]
        g = t.w.commits[cid]["group"]
        if f"commits/{cid}" in t.w.catalog[g]: t.catalog(g, "commits", cid)
        else:                                                     # 아직 DB에 등록되지 않은 건: 마스터에 없다는 것도 관측
            prev = t.cur
            if t.cur is None or t.cur["group"] != g: t.begin(f"{g}/catalog/commits/{cid}", g, DOMAIN_ROLE["FIN"])
            t.neg(f"{g} catalog commits/{cid}"); t.cur = prev
        return t.w.commits[cid]

    # ═════════ PROC ═════════
    def proc_quotes(t, regions, itype, purpose):
        out = []
        for r in regions:
            g = f"PROC-{r}"; t.begin(f"{g}/quotes/{itype}", g, "buying")
            lim = t.rule(f"{g}.lead_time_limit")[purpose]; ex = set(); delay = collections.Counter()
            for x in t.w.exclusions:
                if x["region"] == r and x["start"] <= t.day <= x["end"] and t.frag(x["fid"]): ex.add(x["vendor"])
            vs_here = {q["vendor"] for q in t.w.quotes.values() if q["region"] == r and q["type"] == itype}
            for x in t.w.delays:                                   # 납기 지연 통보(vendors 역할 메모)
                if x["region"] == r and x["vendor"] in vs_here and x["start"] <= t.day <= x["end"] and t.frag(x["fid"]):
                    if t.rule(f"{g}.delay_notice")["delay_adds_to_lead"]: delay[x["vendor"]] += x["add"]
            for qid in sorted(t.w.quotes):
                q = t.w.quotes[qid]
                if q["region"] != r or q["type"] != itype: continue
                q = t.catalog(g, "quotes", qid)
                vendor = t.catalog(g, "vendors", q["vendor"])
                lead = t.db((g, "vendor", q["vendor"], "lead")) + delay[q["vendor"]]
                out.append({"id": qid, "vendor": q["vendor"], "tier": q["tier"], "cost": t.db((g, "quote", qid, "amount")),
                            "lead": lead, "lead_ok": lead <= lim, "country": vendor["country"], "excluded": q["vendor"] in ex})
        return out

    def proc_seat_price(t, r, sw):
        g = f"PROC-{r}"; t.begin(f"{g}/seat_price/{sw}", g, "buying"); return t.db((g, "seatprice", sw, "amount"))

    def proc_receipt(t, r, cid):
        g = f"PROC-{r}"; t.begin(f"{g}/receipt/{cid}", g, "receiving"); return bool(t.db((g, "receipt", cid, "received")))

    def proc_price_notice(t, r, itype, on_day):
        g = f"PROC-{r}"; t.begin(f"{g}/price_notice/{itype}", g, "buying"); pol = t.rule(f"{g}.price_notice_policy"); pct = 0
        for n in t.w.price_notices:
            if n["region"] == r and n["type"] == itype and (n["from"] <= on_day or not pol["apply_from_effective_day"]) and t.frag(n["fid"]): pct = n["pct"]
        return pct

    def proc_vendor_registered(t, r, vid):
        g = f"PROC-{r}"; t.begin(f"{g}/vendor/{vid}/registration", g, "vendors")
        step = t.rule(f"{g}.vendor_onboarding")["unregistered_step"]
        return bool(t.db((g, "vendor", vid, "registered"))), step

    # ═════════ LEGAL ═════════
    def legal_terms(t, e, numeric=False):
        r = t.w.emps[e]["region"]; g = f"LEGAL-{r}"; t.begin(f"{g}/{e}/contract", g, "contracts")
        if t._pt("neardup", e): e = t.near_emp(e)
        terms = t.db((g, "contract", e, "terms"), numeric=numeric); pol = t.rule(f"{g}.contractor_policy"); ov = {"ov": None, "nda": None}
        for o in t.w.overrides:                                    # 장비 예외(compliance 메모)
            if o["emp"] == e and o["start"] <= t.day <= o["end"] and t.frag(o["fid"]): ov["ov"] = o
        if terms and terms["nda"]:
            for x in t.w.nda_checks:                               # NDA 서명본 확인(review 메모)
                if x["emp"] == e and x["start"] <= t.day <= x["end"] and t.frag(x["fid"]): ov["nda"] = x
        return terms, ov, pol

    def legal_residency(t, r):
        g = f"LEGAL-{r}"; t.begin(f"{g}/residency", g, "privacy"); return t.rule(f"{g}.residency")["restricted_depts"]

    def legal_sw_block(t, r, sw):
        g = f"LEGAL-{r}"; t.begin(f"{g}/sw_contractor/{sw}", g, "compliance"); return sw in t.rule(f"{g}.sw_contractor")["blocked"]


def legal_gate(terms, ov, tier, pol):
    if terms is None: return "ok"
    ov = ov or {}
    above = TIER_RANK[tier] > TIER_RANK[terms["allowed_tier"]]
    if (tier == "premium" and pol["premium_requires_override"]) or (above and pol["above_allowed_requires_override"]):
        return "override" if ov.get("ov") else "deny"
    if tier == "standard" and terms["nda"]:
        return "ok" if (ov.get("nda") and pol.get("nda_confirmation_clears")) else pol["standard_with_nda"]
    return "ok"

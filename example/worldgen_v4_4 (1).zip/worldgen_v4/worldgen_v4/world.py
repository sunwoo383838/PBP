"""세계 모델: 그룹·에이전트·공유 DB(등록 지연)·규정·에이전트별 대화 이력(원문)·조각·출생-사멸·로컬 작업.

v3 대비 핵심 변경
  - 초기화 단계에서는 swarm 워커를 만들지 않는다(coordinator가 기록). 워커 소멸도 큐 이벤트.
  - 에이전트 이탈(lifecycle)도 큐 이벤트. 날이 바뀌면 round = 0. push는 현재 시각보다 앞선 시각을 받지 않는다.
  - 대화 이력은 원문(text, role, tokens, summary, fragment_ids)을 전부 저장한다.
  - 조각은 origin(operational / db_pending)을 가진다. 발견성 H2는 내용을 바꾸지 않고 선행 발화 + 지시어 발화로 나눈다.
  - 규칙 값은 전부 self.rules(rulebook.build) 에서 읽는다.
"""
import bisect, collections, copy, hashlib, heapq, json, random, re

from . import rulebook
from .const import (ALL_DOMAINS, ALL_REGIONS, CARD, DEPTS, ITEM_CODE, ITEM_TYPES, NAMES, NUMERIC_ATTR, PRICE, ROLES, SOFTWARE,
                    TARGET_EMP_PER_REGION)
from .textkit import ntok, summarize


def kstr(key): return "/".join(str(x) for x in key)
def h(x): return int(hashlib.md5(str(x).encode()).hexdigest(), 16)


class RNG:
    """이름 붙은 난수 흐름: 한 구성요소의 변경이 다른 구성요소의 난수를 밀지 않는다."""
    def __init__(s, seed): s.seed, s.st = seed, {}
    def __call__(s, name):
        if name not in s.st:
            s.st[name] = random.Random(int(hashlib.sha256(f"{s.seed}|{name}".encode()).hexdigest()[:16], 16))
        return s.st[name]


def poisson(r, lam):
    L, k, p = pow(2.718281828, -lam), 0, 1.0
    while True:
        p *= r.random()
        if p <= L: return k
        k += 1


class Skip(Exception): pass


FILLERS = ["[Memo] Handled another inquiry first.", "[Memo] Coordinating a meeting schedule.", "[Memo] Replied to a document request email.",
           "[Memo] Checked the system maintenance notice.", "[Memo] Drafting the weekly report."]
ROUTINE = {"HR": ["Process an employment certificate request", "Answer a remaining-leave inquiry", "Compile the internal training sign-up list", "Check an attendance record correction request"],
           "IT": ["Process a password reset request", "Answer a printer driver installation inquiry", "Explain a VPN connection error", "Answer a mailbox quota increase inquiry"],
           "FIN": ["Notify about a missing corporate card receipt", "Announce the month-end expense schedule", "Explain the travel expense claim form", "Answer a supplier payment confirmation inquiry"],
           "PROC": ["Answer a delivery schedule inquiry", "Explain the quotation template", "Update supplier contact details", "Explain how to request consumables"],
           "LEGAL": ["Explain the standard contract template", "Answer a personal data handling inquiry", "Process an NDA template request", "Explain the contract review schedule"]}
NO_SUMMARY = {"filler", "routine", "xreq_est", "worker_report", "result_routine", "result"}


class World:
    def __init__(w, P):
        w.P, w.R = P, RNG(P.seed)
        w.domains, w.regions = ALL_DOMAINS[:P.D], ALL_REGIONS[:P.R]
        w.day, w.round, w.seq, w.phase = -P.warmup, 0, 0, "init"
        w.groups, w.agent_group, w.agent_role, w.active = {}, {}, {}, {}
        w.agent_meta = {}
        # 대화 이력: 에이전트별 원문 + 누적 토큰(원문 창) + 누적 요약 토큰(digest)
        w.tx, w.cum, w.scum = collections.defaultdict(list), collections.defaultdict(list), collections.defaultdict(list)
        w.frags, w.db, w.db_due = {}, {}, collections.defaultdict(list)
        w.journal, w.activity = collections.defaultdict(list), collections.defaultdict(list)
        w.entity_index = collections.defaultdict(lambda: collections.defaultdict(set))
        w.timeline, w.pq, w.ids, w.canaries = [], [], collections.Counter(), set()
        # 엔티티
        w.emps, w.commits, w.assets, w.inv, w.vendors, w.quotes = {}, {}, {}, {}, {}, {}
        w.transfers, w.holds, w.reservations, w.earmarks = {}, [], [], []
        w.owner_exc, w.q_exc, w.exclusions, w.overrides, w.price_notices = [], [], [], [], []
        w.offers, w.tier_exc, w.delays, w.nda_checks = [], [], [], []          # v4.2 역할 간 운영 사슬
        w.name_pool = {r: list(NAMES[r][TARGET_EMP_PER_REGION:]) for r in ALL_REGIONS}
        w.rules = {}
        w.catalog = collections.defaultdict(dict)
        w.tasks, w.sig, w.cooldown, w.counts = [], collections.Counter(), {}, collections.Counter()
        w.local_gold, w.snapshot, w.cur_eid, w.cur_root = [], None, None, False
        w.handle_commit, w.follow_q, w.need_seen = {}, [], {}
        w.pop_series, w.candidates, w.index_pending = [], [], []
        w.acc = {"cls": collections.Counter(), "grp": collections.Counter(), "R": collections.Counter(), "disc": collections.Counter(), "cops": 0,
                 "sub_n": collections.Counter(), "sub_hit": collections.Counter(), "md": collections.Counter(), "md_n": 0}

    # ═════════ 기본 도구 ═════════
    def has(w, d): return d in w.domains
    def newid(w, p): w.ids[p] += 1; return f"{p}-{w.ids[p]:05d}"
    def next_seq(w): w.seq += 1; return w.seq
    def rule(w, rid): return w.rules[rid]["params"]           # 세계 로직도 규정 문서에서만 읽는다
    def canary(w, lo, hi):
        r = w.R("canary")
        while True:
            v = r.randrange(lo, hi)
            if v % 1000 and v not in w.canaries: w.canaries.add(v); return v
    def canary_plus(w, base, lo, hi):
        """파생 금액(견적 + 부대비용)도 카나리로 유일하게 만든다 → 하네스가 문자열 매칭으로 어느 사실의 어느 버전인지 추적 가능."""
        r = w.R("canary")
        while True:
            v = base + r.randrange(lo, hi)
            if v % 1000 and v not in w.canaries: w.canaries.add(v); return v
    def log(w, typ, **kw):
        s = w.next_seq()
        w.timeline.append({"day": w.day, "round": w.round, "seq": s, "type": typ, "phase": w.phase, **kw})
    def push(w, day, rnd, prio, typ, payload):
        """큐 삽입. 현재 시각보다 앞선 시각은 현재 시각으로 당긴다 → 타임라인 순서 역전이 생길 수 없다."""
        if (day, rnd) < (w.day, w.round): day, rnd = w.day, w.round
        heapq.heappush(w.pq, (day, rnd, prio, w.next_seq(), typ, payload))
    def other_regions(w, r): return [x for x in w.regions if x != r]
    def sibling(w, r, dept): d = DEPTS[r]; return d[(d.index(dept) + 1) % len(d)] if dept in d else dept

    def catalog_put(w, group, collection, entity, value):
        """Queryable business metadata; no pending facts, holders, or gold labels."""
        key = f"{collection}/{entity}"
        w.catalog[group][key] = copy.deepcopy(value)
        if w.phase != "init":
            w.log("catalog_upsert", group=group, key=key, value=copy.deepcopy(value))

    # ═════════ 대화 이력 ═════════
    def say(w, aid, role, kind, text, summary=None, fids=(), extra_tok=0, shadow=False):
        """이력 한 줄. shadow=True는 생성기 내부 모사용(평가 기간의 에이전트 자기 출력). 하네스 타임라인에는 싣지 않는다."""
        t = ntok(text) + extra_tok
        if summary is None: summary = "" if kind in NO_SUMMARY else summarize(text)
        st = ntok(summary)
        e = {"i": len(w.tx[aid]), "day": w.day, "round": w.round, "seq": w.next_seq(), "role": role, "kind": kind,
             "text": text, "tok": t, "tok_est": extra_tok, "summary": summary, "stok": st, "fids": list(fids),
             "shadow": shadow, "eid": w.cur_eid}
        w.tx[aid].append(e)
        w.cum[aid].append((w.cum[aid][-1] if w.cum[aid] else 0) + t)
        w.scum[aid].append((w.scum[aid][-1] if w.scum[aid] else 0) + st)
        if not shadow and w.phase != "init":
            w.log("tx", agent=aid, i=e["i"], role=role, text=text, tokens=t, summary=summary, eid=w.cur_eid)
        return e["i"]

    # ── ShadowContexts: 에이전트 창 = 최근 K 토큰 원문 + 그 이전의 결정적 요약(S 토큰) ──
    def raw_start(w, aid):
        cum = w.cum[aid]
        if not cum: return 0
        thr = cum[-1] - w.P.K
        if thr <= 0: return 0
        return bisect.bisect_left(cum, thr) + 1
    def entry_state(w, aid, i):
        r0 = w.raw_start(aid)
        if i >= r0: return "raw"
        e = w.tx[aid][i]
        if not e["stok"]: return None
        tot = w.scum[aid][r0 - 1] - (w.scum[aid][i - 1] if i > 0 else 0)
        return "digest" if tot <= w.P.S else None
    def frag_alive(w, fid, numeric):
        """이 조각이 지금 주인의 컨텍스트에서 need에 쓸 수 있게 살아 있는가."""
        f = w.frags[fid]; a = f["agent"]
        if not w.active.get(a): return False, "inactive"
        if f["disc"] == "H2":
            ante, ana = f["entries"]
            sa, sb = w.entry_state(a, ante), w.entry_state(a, ana)
            ok = sb == "raw" and sa in ("raw", "digest")
            return ok, f"{sa}+{sb}"
        st = w.entry_state(a, f["entries"][0])
        return (st == "raw" or (st == "digest" and not numeric)), st
    def fsrc(w, fid, numeric):
        f = w.frags[fid]; hs = []
        for x in [fid] + f["copies"]:
            ok, st = w.frag_alive(x, numeric)
            hs.append({"agent": w.frags[x]["agent"], "fid": x, "alive": ok, "state": st, "active": w.active.get(w.frags[x]["agent"], False)})
        return {"fid": fid, "kind": f["kind"], "origin": f["origin"], "disc": f["disc"], "day": f["day"], "numeric": numeric, "holders": hs}

    # ── 조각 ──
    def frag(w, g, aid, kind, origin, key, value, target, body, numeric, disc=None, copy_of=None, role=None, shadow=False):
        fid = w.newid("FR")
        if disc is None: disc = w.R("disc").choices(["H0", "H1", "H2"], w.P.disc_mix)[0]
        text = f"{target} {body}".strip()
        f = {"fid": fid, "group": g, "agent": aid, "day": w.day, "round": w.round, "seq": w.seq, "kind": kind, "origin": origin,
             "key": kstr(key) if key else None, "value": value, "target": target, "body": body, "text": text, "disc": disc,
             "numeric": numeric, "entries": [], "copies": [], "copy_of": copy_of, "eid": w.cur_eid, "shadow": shadow}
        w.frags[fid] = f
        role = role or ("tool" if origin == "db_pending" else "user")
        pre = "[Tool result] Recorded — " if role == "tool" else ""
        if disc == "H2":        # 내용은 그대로, 대상과 값을 선행 발화 / 지시어 발화로 나눈다
            i1 = w.say(aid, "user", "frag_ante", f"[Memo] Received the {target} item, checking.", fids=[fid], shadow=shadow)
            for _ in range(w.R("h2gap").randint(0, 2)): w.say(aid, "user", "filler", w.R("h2gap").choice(FILLERS), shadow=shadow)
            i2 = w.say(aid, role, "frag_ana", f"{pre}On that item: {body}", summary="memo on that item", fids=[fid], shadow=shadow)
            f["entries"] = [i1, i2]
        else:
            f["entries"] = [w.say(aid, role, "frag", pre + text, fids=[fid], shadow=shadow)]
        ents = w.entities(key, f"{target} {body}")                   # v4.4: 조각이 언급하는 모든 엔티티(사실 종류 attr는 넣지 않음)
        f["index_entities"] = ents if disc in ("H0", "H1") else []
        if disc == "H0":
            w.journal[g].append({"fid": fid, "day": w.day, "agent": aid, "text": text, "entities": ents})
            for ent in ents: w.entity_index[g][ent].add(aid)
            if not shadow and w.phase != "init": w.index_pending.append({"group": g, "index": "journal", "agent": aid, "text": text, "entities": ents})
        elif disc == "H1":
            w.activity[g].append({"fid": fid, "day": w.day, "agent": aid, "trace": f"{aid} handled: {target}", "entities": ents})
            for ent in ents: w.entity_index[g][ent].add(aid)
            if not shadow and w.phase != "init": w.index_pending.append({"group": g, "index": "activity", "agent": aid, "trace": f"{aid} handled: {target}", "entities": ents})
        if w.agent_role.get(aid) == "worker" and copy_of is None:         # swarm: coordinator에는 요약만
            coord = f"{g.lower()}.c0"
            if w.R("summary").random() < w.P.p_summary_value:
                w.frag(g, coord, "summary", origin, key, value, target, "[Worker report] " + body, numeric, disc="H1", copy_of=fid, shadow=shadow)
            else:
                w.say(coord, "user", "worker_report", f"[Worker report] {target} item done", shadow=shadow)
        if copy_of: w.frags[copy_of]["copies"].append(fid)
        return fid

    # ── 색인 엔티티 ──
    _IDRX = re.compile(r"\b(?:CMT|OF|INV|Q|A|V|E)-[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*")
    def entities(w, key, text):
        """색인 키: DB 키의 엔티티 + 본문에 나오는 부서·품목·소프트웨어·id·직원(id로). 사실 종류(attr)는 넣지 않는다.
        같은 조각을 부서 단위 need(예산, 계획 인원)에서도, 개별 id need에서도 찾을 수 있게 한다."""
        ks = {str(key[2])} if key else set()
        s = text.split(" Stored value: ", 1)[0]
        ks |= {d for r in w.regions for d in DEPTS[r] if d in s}
        ks |= {i for i in ITEM_TYPES if re.search(r"\b" + i + r"\b", s)} | {x for x in SOFTWARE if x in s}
        ks |= set(w._IDRX.findall(s))
        ks |= {e for e, x in w.emps.items() if re.search(r"\b" + re.escape(x["name"]) + r"(?![0-9A-Za-z])", s)}
        return sorted(ks)

    # ── 공유 DB (등록 지연) ──
    def write(w, g, etype, eid, attr, value, holder, target, body, kind="observation", lag=None, disc=None):
        key = (g, etype, eid, attr)
        if lag is None: lag = w.R("lag").randint(*w.P.db_lag)
        numeric = NUMERIC_ATTR.get((etype, attr), True)
        # Every write carries the complete actual value in its owner's raw
        # observation, including during the DB registration delay.
        body += " Stored value: " + json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        fid = w.frag(g, holder, kind, "db_pending", key, value, target, body, numeric, disc)
        vs = w.db.setdefault(key, [])
        vs.append({"v": len(vs) + 1, "day": w.day, "round": w.round, "seq": w.seq, "db_day": w.day + lag, "value": value, "fid": fid})
        w.db_due[w.day + lag].append((key, len(vs)))
        return fid
    def cur(w, key):
        """세계의 참값(최신 버전, 등록 여부 무관). 세계 로직 전용 — 정답 함수는 TW만 쓴다."""
        vs = w.db.get(key)
        return vs[-1]["value"] if vs else None

    # ═════════ 그룹·에이전트 ═════════
    def add_agent(w, g, aid, role):
        w.groups[g]["agents"].append(aid); w.agent_group[aid] = g; w.agent_role[aid] = role; w.active[aid] = True
        w.agent_meta[aid] = {"group": g, "role": role, "joined": w.day, "left": None}
    def assign(w, g, role, key):
        """specialist: 역할 일치자 중 엔티티 해시 고정 + p_cover 대리. swarm: 작업마다 워커 생성(초기화 단계는 coordinator)."""
        G = w.groups[g]
        if G["topology"] == "swarm":
            if w.phase == "init": return f"{g.lower()}.c0"
            wid = f"{g.lower()}.w{w.newid('WK')[-5:]}"; w.add_agent(g, wid, "worker")
            w.log("spawn", group=g, agent=wid); w.counts["spawn"] += 1
            w.push(w.day, 4, 0, "despawn", {"agent": wid})
            return wid
        c = sorted(a for a in G["agents"] if w.active[a] and w.agent_role[a] == role) or sorted(a for a in G["agents"] if w.active[a])
        a = c[h(key) % len(c)]
        if w.phase != "init" and w.R("cover").random() < w.P.p_cover:
            o = sorted(x for x in G["agents"] if w.active[x] and x != a and w.agent_role[x] != "worker")
            if o: a = w.R("cover").choice(o)
        return a
    def card(w, g, role):
        """card만 보고 고르는 대상. 같은 역할 복제자는 card로 구분 불가 → 정렬상 첫 번째. swarm은 coordinator."""
        G = w.groups[g]
        if G["topology"] == "swarm": return f"{g.lower()}.c0"
        c = sorted(a for a in G["agents"] if w.active[a] and w.agent_role[a] == role) or sorted(a for a in G["agents"] if w.active[a])
        return c[0]
    def despawn(w, p):
        a = p["agent"]
        if w.active.get(a):
            w.active[a] = False; w.agent_meta[a]["left"] = w.day; w.log("despawn", agent=a); w.counts["despawn"] += 1

    # ── 로컬 작업 틀: [작업](user) → 조각·도구 결과 → [결과](assistant, 평가 기간은 shadow) ──
    def task(w, g, aid, kind, text):
        w.cur_eid = w.newid("L")
        ctx = {"eid": w.cur_eid, "g": g, "aid": aid, "kind": kind, "expected": []}
        w.say(aid, "user", "task", "[Task] " + text)
        return ctx
    def done(w, ctx, result, expected=None):
        # local_mode=replay(기본): 로컬 작업은 하네스가 그대로 재생한다. 결과 줄도 공개 tx로 내보내고 추정 토큰을 붙이지 않는다
        # → 에이전트가 보게 될 이력과 설계 등급을 계산한 창이 같다. llm: 평가 기간 결과 줄은 에이전트가 직접 쓰므로 shadow + 추정치.
        replay = w.P.local_mode == "replay"
        w.say(ctx["aid"], "assistant", "result" if ctx["kind"] != "routine" else "result_routine", "[Result] " + result,
              extra_tok=0 if replay else w.P.out_overhead, shadow=(w.day >= 1 and not replay))
        if w.phase != "init":
            w.log("local", eid=ctx["eid"], group=ctx["g"], assignee=ctx["aid"])
            w.local_gold.append({"eid": ctx["eid"], "day": w.day, "group": ctx["g"], "assignee": ctx["aid"], "kind": ctx["kind"], "root": bool(w.cur_root),
                                 "expected": expected if expected is not None else ctx["expected"]})
            if w.day >= 1: w.counts[f"local:{ctx['g'].split('-')[0]}:{ctx['kind']}"] += 1
        w.cur_eid = None
    def tw_write(w, ctx, g, etype, eid, attr, value, target, body, kind="observation", lag=None, disc=None):
        ctx["expected"].append({"op": "db.write", "key": kstr((g, etype, eid, attr)), "value": value})
        return w.write(g, etype, eid, attr, value, ctx["aid"], target, body, kind, lag, disc)
    def tw_frag(w, ctx, kind, key, value, target, body, numeric):
        ctx["expected"].append({"op": "note", "target": target, "value": value})
        return w.frag(ctx["g"], ctx["aid"], kind, "operational", key, value, target, body, numeric)

    # ═════════ 초기화 ═════════
    def init(w):
        r0 = w.R("init")
        for d in w.domains:
            for r in w.regions:
                g = f"{d}-{r}"; top = "swarm" if g in w.P.swarm else "specialist"
                w.groups[g] = {"domain": d, "region": r, "topology": top, "agents": []}
                if top == "swarm": w.add_agent(g, f"{g.lower()}.c0", "coordinator")
                else:
                    for i, role in enumerate(ROLES[d]): w.add_agent(g, f"{g.lower()}.a{i+1}", role)
        w.rules = rulebook.build(w.domains, w.regions, w.R("rules"), w.canary)
        for r in w.regions:
            others = w.other_regions(r); hr, it, fin = f"HR-{r}", f"IT-{r}", f"FIN-{r}"
            for i, nm in enumerate(NAMES[r][:TARGET_EMP_PER_REGION]):
                e = f"E-{r}-{1000+i}"
                w.emps[e] = {"name": nm, "alias": w._alias(nm, r, r0), "region": r}
                w.catalog_put(hr, "employees", e, {"employee_id": e, **w.emps[e]})
                prof = {"dept": r0.choice(DEPTS[r]), "grade": r0.randint(1, 5), "contract": "contractor" if r0.random() < 0.28 else "regular",
                        "hire_day": -r0.randint(40, 900), "status": "active"}
                a = w.assign(hr, "records", e); ctx = w.task(hr, a, "init", f"Migrate HR record of {nm}")
                w.tw_write(ctx, hr, "emp", e, "profile", prof, f"HR record of {nm}", f"{prof['dept']}, grade {prof['grade']}, {prof['contract']}.", lag=0, disc="H0")
                w.done(ctx, "Migration done")
                if w.has("LEGAL") and prof["contract"] == "contractor":
                    lg = f"LEGAL-{r}"; terms = {"allowed_tier": r0.choice(["basic", "standard"]), "expiry": r0.randint(5, 120), "nda": r0.random() < 0.6}
                    a = w.assign(lg, "contracts", e); ctx = w.task(lg, a, "init", f"Migrate contract of {nm}")
                    w.tw_write(ctx, lg, "contract", e, "terms", terms, f"Contract of {nm}", f"allowed tier {terms['allowed_tier']}, expires day {terms['expiry']}, NDA {'yes' if terms['nda'] else 'no'}.", lag=0)
                    w.done(ctx, "Migration done")
            for dept in DEPTS[r]:
                v = w.canary(2_400_000, 5_000_000); a = w.assign(fin, "budgeting", dept); ctx = w.task(fin, a, "init", f"Migrate budget line of {dept}")
                w.tw_write(ctx, fin, "line", dept, "remaining", v, f"{dept} capex balance", f"{v:,} KRW confirmed.", lag=0, disc="H0")
                w.tw_write(ctx, fin, "line", dept, "base", v, f"{dept} quarterly base allocation", f"{v:,} KRW.", lag=0, disc="H0")
                w.done(ctx, "Migration done")
            for itype, tiers in ITEM_TYPES.items():
                for tier in tiers:
                    iid = f"INV-{r}-{ITEM_CODE[itype]}{tier[0].upper()}"
                    w.inv[iid] = {"region": r, "type": itype, "tier": tier, "cost": w.canary(*PRICE[tier])}
                    w.catalog_put(it, "inventory", iid, {"item_id": iid, **w.inv[iid]})
                    a = w.assign(it, "assets", iid); ctx = w.task(it, a, "init", f"Stocktake of in-house {itype} ({tier})")
                    w.tw_write(ctx, it, "inv", iid, "qty", r0.randint(1, 3), f"In-house stock {itype} ({tier})", "Quantity checked.", lag=0)
                    w.done(ctx, "Stocktake done")
            for e, x in list(w.emps.items()):
                if x["region"] != r: continue
                for _ in range(r0.randint(1, 2)):
                    itype = r0.choice(list(ITEM_TYPES)); tier = r0.choice(ITEM_TYPES[itype]); aid = f"A-{r}-{w.canary(3000, 9999)}"
                    w.assets[aid] = {"region": r, "type": itype, "tier": tier, "history": {e}}
                    w.catalog_put(it, "assets", aid, {"asset_id": aid, "region": r, "type": itype, "tier": tier})
                    a = w.assign(it, "assets", aid); ctx = w.task(it, a, "init", f"Migrate asset register entry {aid}")
                    w.tw_write(ctx, it, "asset", aid, "holder", {"emp": e}, f"{aid} {itype}", f"Assigned to {x['name']}.", lag=0)
                    w.done(ctx, "Migration done")
            for sw in SOFTWARE:
                seats = r0.randint(18, 40); a = w.assign(it, "licenses", sw); ctx = w.task(it, a, "init", f"Seat audit of {sw}")
                v = {"seats": seats, "used": seats - r0.randint(1, 8)}
                w.tw_write(ctx, it, "lic", sw, "seats", v, f"{sw} seats", f"In use {v['used']}/{v['seats']} seats.", lag=0)
                w.done(ctx, "Stocktake done")
            if w.has("PROC"):
                pg = f"PROC-{r}"
                for vi in range(4):
                    vid = f"V-{r}-{vi}"; country = r if vi < 2 else ("CN" if vi == 3 else (others[0] if others else r))
                    w.vendors[vid] = {"region": r, "country": country}
                    w.catalog_put(pg, "vendors", vid, {"vendor_id": vid, **w.vendors[vid]})
                    a = w.assign(pg, "vendors", vid); ctx = w.task(pg, a, "init", f"Migrate supplier record {vid}")
                    w.tw_write(ctx, pg, "vendor", vid, "lead", r0.randint(3, 11), f"Supplier {vid}", f"Lead time checked, located in {country}.", lag=0)
                    w.tw_write(ctx, pg, "vendor", vid, "registered", vi != 3, f"Supplier {vid}", "Registered." if vi != 3 else "Not registered.", lag=0)
                    w.done(ctx, "Migration done")
                    for itype, tiers in ITEM_TYPES.items():
                        for tier in tiers:
                            if r0.random() < 0.8:
                                qid = f"Q-{vid}-{ITEM_CODE[itype]}{tier[0].upper()}"; w.quotes[qid] = {"region": r, "vendor": vid, "type": itype, "tier": tier}
                                w.catalog_put(pg, "quotes", qid, {"quote_id": qid, **w.quotes[qid]})
                                v = w.canary(*PRICE[tier]); a = w.assign(pg, "buying", itype); ctx = w.task(pg, a, "init", f"Migrate quotes of {vid}")
                                w.tw_write(ctx, pg, "quote", qid, "amount", v, f"{vid} {itype} ({tier}) quote {qid}", f"{v:,} KRW.", lag=0)
                                w.done(ctx, "Migration done")
                for sw in SOFTWARE:
                    v = w.canary(110_000, 280_000); a = w.assign(pg, "buying", sw); ctx = w.task(pg, a, "init", f"Migrate seat price of {sw}")
                    w.tw_write(ctx, pg, "seatprice", sw, "amount", v, f"{sw} seat price", f"{v:,} KRW.", lag=0)
                    w.done(ctx, "Migration done")
        w.phase = "warmup"

    def _alias(w, nm, r, rr):
        parts = nm.split()                                      # "Family Given" (로마자)
        if r == "SEL": return parts[-1] + rr.choice([" (Manager)", " (Assistant Manager)", " (Senior)", " (Lead)"])
        if r == "TYO": return parts[0] + "-san"
        return parts[0] + " (mgr)"

    # ═════════ 세계 이벤트 ═════════
    def schedule_day(w):
        r = w.R("slots")
        if w.day > -w.P.warmup: w.push(w.day, 0, 0, "lifecycle", {})
        for g, G in w.groups.items():
            n_act = sum(1 for a in G["agents"] if w.active[a]) if G["topology"] == "specialist" else 3
            lam = w.P.local_per_agent * n_act                      # 뿌리 발생률: 분산을 줄인 층화 반올림(창별 발생률 안정)
            for _ in range(int(lam) + (1 if r.random() < lam % 1 else 0)):
                w.push(w.day, r.randint(1, 3), 2, "local", {"group": g})
        if w.has("HR"):
            for reg in w.regions: w.push(w.day, r.randint(1, 3), 2, "hr_flow", {"r": reg})
        if w.day >= 1:
            for _ in range(w.P.tasks_per_day): w.push(w.day, r.randint(1, 3), 3, "cross", {})
        if w.day in w.rule(f"FIN-{w.regions[0]}.reset_calendar")["days"]:
            w.push(w.day, 1, 1, "budget_reset", {})

    def register_due(w):
        for key, v in w.db_due.pop(w.day, []):
            if w.day >= 1 or w.phase == "warmup":
                w.log("db_register", key=kstr(key), v=v, value=w.db[key][v - 1]["value"])
            if key[1] == "commit" and key[3] == "status" and f"commits/{key[2]}" not in w.catalog[key[0]]:
                c = w.commits[key[2]]      # 가승인이 DB에 처음 보이는 시점에만 업무 마스터(catalog)에 올린다
                w.catalog_put(key[0], "commits", key[2], {"commit_id": key[2], "department": c["dept"], "item": c["item"], "work": c["handle"]})

    def lifecycle(w, p):
        r = w.R("life")
        for g, G in w.groups.items():
            if G["topology"] == "swarm": continue
            for a in sorted(G["agents"]):
                if w.active[a] and r.random() < w.P.mu_agent:
                    w.active[a] = False; w.agent_meta[a]["left"] = w.day; ho = r.random() < w.P.p_handover
                    na = f"{g.lower()}.n{w.newid('AG')[-4:]}"
                    w.log("agent_leave", group=g, agent=a, handover=ho); w.counts["agent_leave"] += 1
                    w.push(w.day + 1, 0, 1, "agent_join", {"group": g, "agent": na, "role": w.agent_role[a], "from": a, "handover": ho})

    def agent_join(w, p):
        w.add_agent(p["group"], p["agent"], p["role"]); w.log("agent_join", **p); w.counts["agent_join"] += 1
        if p["handover"]:
            recent = [f for f in w.frags.values() if f["agent"] == p["from"] and f["value"] is not None
                      and f["copy_of"] is None and not f["shadow"]][-3:]
            for f in recent:
                w.frag(p["group"], p["agent"], "handover", f["origin"], None, f["value"], f["target"], "[Handover] " + f["body"],
                       f["numeric"], disc="H1", copy_of=f["fid"])

    def active_emps(w, r):
        return sorted(e for e, x in w.emps.items() if x["region"] == r and (w.cur((f"HR-{r}", "emp", e, "profile")) or {}).get("status") == "active")

    def hr_flow(w, p):
        """직원 출생-사멸: 퇴사 ~ Poisson(μ·현재 + κ·초과), 입사 ~ Poisson(μ·목표 + κ·부족) → 목표 근처로 평균 회귀."""
        r = p["r"]; rr = w.R("hrflow"); g = f"HR-{r}"; pop = len(w.active_emps(r)); tgt = TARGET_EMP_PER_REGION; k = w.P.kappa_emp
        pend = sum(1 for o in w.offers if o["region"] == r and o["status"] == "offered") // 2   # 입사 확정 대기자는 절반만 인원으로 본다(지연 보정)
        for _ in range(poisson(rr, w.P.mu_emp * pop + k * max(0, pop - tgt))): w.L_HR_exit(g, r, rr)
        pop = len(w.active_emps(r))                                                         # 오늘 퇴사를 반영한 뒤 충원을 정한다
        for _ in range(poisson(rr, w.P.mu_emp * tgt + k * max(0, tgt - pop - pend))): w.L_HR_offer(g, r, rr, urgent=pop < tgt - 2)

    def local(w, p):
        g = p["group"]; G = w.groups[g]; d, r = G["domain"], G["region"]; rr = w.R("local")
        kinds = w.P.local_mix[d]
        if d == "FIN" and len(w.regions) < 2: kinds = [(k, (0 if k == "owner_exc" else q)) for k, q in kinds]
        k = rr.choices([x for x, _ in kinds], [q for _, q in kinds])[0]
        w.cur_root = True; getattr(w, f"L_{d}_{k}", w.L_routine)(g, r, rr); w.cur_root = False

    def L_routine(w, g, r, rr):
        d = w.groups[g]["domain"]; a = w.assign(g, rr.choice(ROLES[d]), rr.random())
        ctx = w.task(g, a, "routine", rr.choice(ROUTINE[d])); w.done(ctx, "Answered", expected=[])

    # ── HR ──
    def L_HR_transfer(w, g, r, rr):
        es = [e for e in w.active_emps(r) if (w.transfers.get(e) or {}).get("status") != "approved"]
        if not es: return
        e = rr.choice(es); prof = w.cur((g, "emp", e, "profile")); to = rr.choice([x for x in DEPTS[r] if x != prof["dept"]])
        eff = w.day + rr.randint(2, 12); nm = w.emps[e]["name"]
        a = w.assign(g, "mobility", e); ctx = w.task(g, a, "transfer", f"Review transfer request of {nm}")
        fid = w.tw_frag(ctx, "pending_intent", (g, "emp", e, "transfer"), {"to": to, "effective": eff},
                        f"Transfer of {nm}", f"approved from {prof['dept']} to {to}, effective day {eff} (stays in {prof['dept']} until then).", numeric=True)
        w.transfers[e] = {"emp": e, "to": to, "eff": eff, "fid": fid, "status": "approved", "seq": w.seq, "group": g}
        w.push(eff, 1, 1, "transfer_effect", {"e": e}); w.done(ctx, "Transfer approval recorded")
    def transfer_effect(w, p):
        e = p["e"]; tr = w.transfers[e]; g = tr["group"]; r = w.emps[e]["region"]
        prof = dict(w.cur((g, "emp", e, "profile")))
        tr["status"] = "done"
        if prof["status"] != "active": return
        old = prof["dept"]; prof["dept"] = tr["to"]; a = w.assign(g, "mobility", e); ctx = w.task(g, a, "transfer_effect", f"Apply transfer of {w.emps[e]['name']}")
        w.tw_write(ctx, g, "emp", e, "profile", prof, f"HR record of {w.emps[e]['name']}", f"moved from {old} to {tr['to']}, grade {prof['grade']}, {prof['contract']}.")
        w.done(ctx, "Transfer applied")
    def L_HR_offer(w, g, r, rr, urgent=False):
        """입사 확정(recruiting): 입사일 전까지 인사 기록에 없는 operational 조각. 계획 인원 산정에 들어간다."""
        oid = w.newid("OF"); dept = rr.choice(DEPTS[r]); contract = "contractor" if rr.random() < 0.4 else "regular"
        start = w.day + (0 if urgent else rr.randint(1, 5)); a = w.assign(g, "recruiting", oid)   # 결원이 크면 긴급 충원(당일 입사)
        ctx = w.task(g, a, "offer", f"Confirm new hire for {dept}")
        fid = w.tw_frag(ctx, "pending_intent", (g, "offer", oid, "start"), {"dept": dept, "start": start, "contract": contract},
                        f"{dept} confirmed hire {oid}", f"starts day {start}, {contract} (not yet in HR records).", numeric=True)
        w.offers.append({"oid": oid, "region": r, "dept": dept, "start": start, "contract": contract, "fid": fid, "status": "offered", "seq": w.seq})
        w.push(start, 1 if start > w.day else 3, 2, "offer_start", {"oid": oid}); w.done(ctx, "Hire confirmation recorded")
    def offer_start(w, p):
        o = next(x for x in w.offers if x["oid"] == p["oid"])
        if o["status"] != "offered": return
        o["status"] = "hired"; w.L_HR_hire(f"HR-{o['region']}", o["region"], w.R("hrflow"), offer=o)
    def L_HR_hire(w, g, r, rr, offer=None):
        e = f"E-{r}-{2000 + w.ids['hire']}"; w.ids["hire"] += 1
        nm = w.name_pool[r].pop(0) if w.name_pool[r] else rr.choice(NAMES[r]) + str(w.ids["hire"])
        w.emps[e] = {"name": nm, "alias": w._alias(nm, r, rr), "region": r}
        w.catalog_put(g, "employees", e, {"employee_id": e, **w.emps[e]})
        prof = {"dept": offer["dept"] if offer else rr.choice(DEPTS[r]), "grade": rr.randint(1, 3),
                "contract": offer["contract"] if offer else ("contractor" if rr.random() < 0.4 else "regular"), "hire_day": w.day, "status": "active"}
        a = w.assign(g, "recruiting", e); ctx = w.task(g, a, "hire", f"Onboard {nm}")
        w.tw_write(ctx, g, "emp", e, "profile", prof, f"HR record of {nm}", f"joined {prof['dept']}, grade {prof['grade']}, {prof['contract']}.")
        w.done(ctx, "Onboarded")
        if w.has("LEGAL") and prof["contract"] == "contractor": w.push(w.day + rr.randint(1, 2), 1, 2, "contract_create", {"e": e})
        w.counts["employee_birth"] += 1
    def L_HR_exit(w, g, r, rr):
        es = w.active_emps(r)
        if not es: return
        e = rr.choice(es); prof = dict(w.cur((g, "emp", e, "profile"))); prof["status"] = "exited"
        a = w.assign(g, "records", e); ctx = w.task(g, a, "exit", f"Process exit of {w.emps[e]['name']}")
        w.tw_write(ctx, g, "emp", e, "profile", prof, f"HR record of {w.emps[e]['name']}", f"exit processed ({prof['dept']}).")
        w.done(ctx, "Exit processed"); w.counts["employee_death"] += 1
        if e in w.transfers and w.transfers[e]["status"] == "approved": w.transfers[e]["status"] = "void"
    def L_HR_grade(w, g, r, rr):
        es = w.active_emps(r)
        if not es: return
        e = rr.choice(es); prof = dict(w.cur((g, "emp", e, "profile"))); prof["grade"] = max(1, min(5, prof["grade"] + rr.choice([-1, 1])))
        a = w.assign(g, "payroll", e); ctx = w.task(g, a, "grade", f"Apply grade change of {w.emps[e]['name']}")
        w.tw_write(ctx, g, "emp", e, "profile", prof, f"HR record of {w.emps[e]['name']}", f"changed to grade {prof['grade']} (review result), {prof['dept']}.", kind="rationale")
        w.done(ctx, "Change applied")

    # ── IT ──
    def L_IT_assign(w, g, r, rr, e=None, iid=None, handle=None):
        items = [i for i, x in w.inv.items() if x["region"] == r and (w.cur((g, "inv", i, "qty")) or 0) > 0]
        es = w.active_emps(r)
        if not items or not es: return
        iid = iid if iid in items else rr.choice(sorted(items)); e = e or rr.choice(es); x = w.inv[iid]
        a = w.assign(g, "assets", iid); ctx = w.task(g, a, "assign", f"Assign equipment to {w.emps[e]['name']}" + (f" (follow-up of {handle})" if handle else ""))
        w.tw_write(ctx, g, "inv", iid, "qty", w.cur((g, "inv", iid, "qty")) - 1, f"In-house stock {x['type']} ({x['tier']})", "1 unit issued.")
        aid = f"A-{r}-{w.canary(10000, 99999)}"; w.assets[aid] = {"region": r, "type": x["type"], "tier": x["tier"], "history": {e}}
        w.catalog_put(g, "assets", aid, {"asset_id": aid, "region": r, "type": x["type"], "tier": x["tier"]})
        w.tw_write(ctx, g, "asset", aid, "holder", {"emp": e}, f"{aid} {x['type']}", f"Assigned to {w.emps[e]['name']}.")
        w.done(ctx, "Assigned")
    def L_IT_restock(w, g, r, rr):
        iid = rr.choice(sorted(i for i, x in w.inv.items() if x["region"] == r)); a = w.assign(g, "assets", iid); x = w.inv[iid]
        ctx = w.task(g, a, "restock", f"Add received {x['type']} ({x['tier']}) to stock")
        w.tw_write(ctx, g, "inv", iid, "qty", (w.cur((g, "inv", iid, "qty")) or 0) + rr.randint(1, 2), f"In-house stock {x['type']} ({x['tier']})", "Receipt added.")
        w.done(ctx, "Applied")
    def L_IT_license(w, g, r, rr, sw=None, delta=None, handle=None):
        sw = sw or rr.choice(SOFTWARE); v = dict(w.cur((g, "lic", sw, "seats"))); a = w.assign(g, "licenses", sw)
        v["used"] = max(0, min(v["seats"], v["used"] + (delta if delta is not None else rr.choice([-2, -1, 1, 2, 3]))))
        ctx = w.task(g, a, "license", f"Change {sw} seat usage" + (f" (follow-up of {handle})" if handle else ""))
        w.tw_write(ctx, g, "lic", sw, "seats", v, f"{sw} seats", f"In use {v['used']}/{v['seats']} seats.")
        w.done(ctx, "Changed")

    def apply_seat_allocation(w, p):
        """Atomic exogenous allocation; recheck capacity at next-day execution.

        Transfers conserve seats; purchases add seats; allocation only adds used.
        If intervening events invalidate the decision, emit an explicit failure
        instead of silently freeing seats or clipping the requested allocation.
        """
        r, sw = p["r"], p["sw"]
        g = f"IT-{r}"; key = (g, "lic", sw, "seats")
        dst = dict(w.cur(key)); other = w.other_regions(r)
        srcg = f"IT-{other[0]}" if other else None
        src = dict(w.cur((srcg, "lic", sw, "seats"))) if srcg else None
        reserved = lambda reg: sum(x["n"] for x in w.reservations if x["region"] == reg and x["sw"] == sw and x["start"] <= w.day <= x["end"])
        n, transfer, buy = p["allocate"], p["transfer"], p["buy"]
        assert min(n, transfer, buy) >= 0
        source_free = max(0, src["seats"] - src["used"] - reserved(other[0])) if src else 0
        if transfer > source_free or n > dst["seats"] + transfer + buy - dst["used"] - reserved(r):
            w.log("world", event="seat_allocation_failed", work=p["handle"], reason="capacity_changed")
            return
        if transfer:
            src["seats"] -= transfer
            a = w.assign(srcg, "licenses", sw)
            ctx = w.task(srcg, a, "seat_transfer_out", f"Transfer {transfer} {sw} seats to {r} (follow-up of {p['handle']})")
            w.tw_write(ctx, srcg, "lic", sw, "seats", src, f"{sw} seats", f"after transfer in use {src['used']}/{src['seats']} seats.")
            w.done(ctx, "Transfer applied")
        dst["seats"] += transfer + buy; dst["used"] += n
        a = w.assign(g, "licenses", sw)
        ctx = w.task(g, a, "seat_allocation", f"Receive {transfer} transferred {sw} seats, buy {buy}, allocate {n} (follow-up of {p['handle']})")
        w.tw_write(ctx, g, "lic", sw, "seats", dst, f"{sw} seats", f"after allocation in use {dst['used']}/{dst['seats']} seats.")
        w.done(ctx, "Allocation applied")
    def L_IT_recover(w, g, r, rr, only=None, handle=None):
        cands = []
        for aid, x in w.assets.items():
            if x["region"] != r: continue
            hv = w.cur((g, "asset", aid, "holder"))
            if hv and hv.get("emp"):
                st = (w.cur((f"HR-{r}", "emp", hv["emp"], "profile")) or {}).get("status")
                if (only and aid in only) or (not only and st == "exited"): cands.append(aid)
        if not cands: return
        aid = rr.choice(sorted(cands)); a = w.assign(g, "assets", aid)
        ctx = w.task(g, a, "recover", f"Recover asset {aid}" + (f" (follow-up of {handle})" if handle else ""))
        w.tw_write(ctx, g, "asset", aid, "holder", {"emp": None}, f"{aid} {w.assets[aid]['type']}", "recovered, back in storage.")
        w.done(ctx, "Recovered")
    def L_IT_hold(w, g, r, rr):
        items = sorted(i for i, x in w.inv.items() if x["region"] == r and (w.cur((g, "inv", i, "qty")) or 0) > 0)
        if not items: return
        iid = rr.choice(items); x = w.inv[iid]; dept = rr.choice(DEPTS[r]); end = w.day + rr.randint(4, 12)
        onboard = rr.random() < 0.5                                   # 입사자 준비(provisioning) / 고장 교체 예비(assets)
        a = w.assign(g, "provisioning" if onboard else "assets", f"hold/{iid}/{w.day}/{dept}")
        ctx = w.task(g, a, "hold", f"Reserve equipment for an incoming {dept} hire" if onboard else f"Reserve a spare for broken {dept} equipment")
        why = f"for an incoming {dept} hire" if onboard else f"as a {dept} replacement spare"
        fid = w.tw_frag(ctx, "pending_intent", (g, "inv", iid, "hold"), {"iid": iid, "qty": 1, "end": end},
                        f"In-house stock {x['type']} ({x['tier']})", f"1 unit held {why} until day {end}.", numeric=True)
        w.holds.append({"iid": iid, "region": r, "start": w.day, "end": end, "fid": fid, "seq": w.seq}); w.done(ctx, "Hold recorded")
    def L_IT_reserve(w, g, r, rr):
        sw = rr.choice(SOFTWARE); n = rr.randint(2, 4); dept = rr.choice(DEPTS[r]); end = w.day + rr.randint(5, 14)
        onboard = rr.random() < 0.5                                   # 입사자 준비(provisioning) / 프로젝트 좌석(licenses)
        a = w.assign(g, "provisioning" if onboard else "licenses", f"res/{sw}/{w.day}/{dept}")
        ctx = w.task(g, a, "reserve", f"Reserve onboarding seats for {dept}" if onboard else f"Reserve project seats for {dept}")
        fid = w.tw_frag(ctx, "pending_intent", (g, "lic", sw, "reserve"), {"sw": sw, "n": n, "end": end},
                        f"{sw} seats", f"{n} seats reserved for {dept} {'onboarding' if onboard else 'project'} until day {end}.", numeric=True)
        w.reservations.append({"sw": sw, "region": r, "n": n, "start": w.day, "end": end, "fid": fid, "seq": w.seq}); w.done(ctx, "Reservation recorded")

    def L_IT_tier_exc(w, g, r, rr):
        """장비 등급 예외(access): 직급 기본 등급보다 한 단계 높은 등급을 기간 동안 허용."""
        es = [e for e in w.active_emps(r) if not any(x["emp"] == e and x["end"] >= w.day for x in w.tier_exc)]
        if not es: return
        e = rr.choice(es); grade = w.cur((f"HR-{r}", "emp", e, "profile"))["grade"]
        base = w.rule(f"IT-{r}.eligibility")["grade_tier"][str(grade)]
        if base == "premium": return
        tier = {"basic": "standard", "standard": "premium"}[base]; end = w.day + rr.randint(7, 25); nm = w.emps[e]["name"]
        a = w.assign(g, "access", e); ctx = w.task(g, a, "tier_exc", f"Review equipment tier exception for {nm}")
        fid = w.tw_frag(ctx, "exception", (g, "emp", e, "tier_exc"), {"emp": e, "tier": tier, "end": end},
                        f"Equipment tier of {nm}", f"up to {tier} allowed until day {end} for work reasons (IT exception approved).", numeric=False)
        w.tier_exc.append({"emp": e, "region": r, "tier": tier, "start": w.day, "end": end, "fid": fid, "seq": w.seq}); w.done(ctx, "Exception recorded")

    # ── FIN ──
    def L_FIN_line_adjust(w, g, r, rr):
        dept = rr.choice(DEPTS[r]); v = w.canary(1_600_000, 4_800_000); a = w.assign(g, "budgeting", dept)
        why = rr.choice(["division reallocation", "quarter carry-over", "urgent spend deduction", "refund applied"])
        ctx = w.task(g, a, "line_adjust", f"Adjust {dept} budget ({why})")
        w.tw_write(ctx, g, "line", dept, "remaining", v, f"{dept} capex balance", f"adjusted to {v:,} KRW ({why}).", kind="rationale")
        w.done(ctx, "Adjusted")
    def commit_review(w, g, r, dept, amount, item, rr, handle=None):
        cid = w.newid("CMT"); a = w.assign(g, "payables", cid); settle = w.day + rr.randint(4, 14)
        ctx = w.task(g, a, "commit_review", f"Review provisional approval: {dept} {item}" + (f" (follow-up of {handle})" if handle else ""))
        tgt = f"{cid} {dept} {item} provisional approval" + (f" (order of {handle})" if handle else "")
        fid = w.tw_frag(ctx, "pending_intent", (g, "commit", cid, "status"), {"status": "reviewing", "amount": amount, "expected_settle": settle},
                        tgt, f"{amount:,} KRW under review, settlement expected day {settle}.", numeric=True)
        c = {"cid": cid, "group": g, "dept": dept, "amount": amount, "item": item, "review_day": w.day, "review_seq": w.seq,
             "review_fid": fid, "expected_settle": settle, "talk_fid": None, "handle": handle}
        w.commits[cid] = c
        # catalog 등록은 가승인이 DB에 처음 등록되는 날(register_due)에 한다. 검토 중인 건의 존재는 운영 메모에만 있다.
        if handle: w.handle_commit[handle] = cid
        if rr.random() < 0.12: w.push(w.day + rr.randint(1, 5), 2, 1, "commit_cancel", {"cid": cid})
        else: w.push(w.day + rr.randint(2, 6), 2, 1, "commit_confirm", {"cid": cid})
        w.done(ctx, "Review recorded")
        if rr.random() < 0.18:
            b = w.assign(g, "budgeting", dept); ctx2 = w.task(g, b, "talk", f"Attend {dept} budget meeting")
            c["talk_fid"] = w.tw_frag(ctx2, "observation", None, "cancel_talk", f"{cid} item", "someone suggested cancelling it (not decided).", numeric=False)
            w.done(ctx2, "Meeting memo")
        w.counts["commit_birth"] += 1
        return cid
    def L_FIN_commit_review(w, g, r, rr):
        dept = rr.choice(DEPTS[r])
        for x in w.owner_exc:                                   # 소유권 예외 중인 부서는 다른 지역 재무에서 집행
            if x["dept"] == dept and x["from"] == r and x["start"] <= w.day <= x["end"]: g = f"FIN-{x['to']}"
        w.commit_review(g, r, dept, w.canary(200_000, 1_000_000), rr.choice(list(ITEM_TYPES) + ["meeting room equipment", "travel advance"]), rr)
    def commit_confirm(w, p):
        c = w.commits[p["cid"]]; a = w.assign(c["group"], "payables", c["cid"])
        ctx = w.task(c["group"], a, "commit_confirm", f"Confirm provisional approval {c['cid']}")
        w.tw_write(ctx, c["group"], "commit", c["cid"], "status", {"status": "pending", "amount": c["amount"], "expected_settle": c["expected_settle"]},
                   f"{c['cid']} {c['dept']} provisional approval", f"{c['amount']:,} KRW confirmed, settlement expected day {c['expected_settle']}.")
        w.done(ctx, "Confirmed")
        w.push(c["expected_settle"], 2, 1, "commit_settle", {"cid": c["cid"]})
    def commit_settle(w, p):
        c = w.commits[p["cid"]]
        if (w.cur((c["group"], "commit", c["cid"], "status")) or {}).get("status") != "pending": return
        a = w.assign(c["group"], "payables", c["cid"]); ctx = w.task(c["group"], a, "commit_settle", f"Settle {c['cid']}")
        w.tw_write(ctx, c["group"], "commit", c["cid"], "status", {"status": "settled", "amount": c["amount"], "expected_settle": c["expected_settle"]},
                   f"{c['cid']} {c['dept']} provisional approval", "settled.")
        w.done(ctx, "Settled"); w.counts["commit_death"] += 1
    def commit_cancel(w, p):
        c = w.commits[p["cid"]]; a = w.assign(c["group"], "closing", c["dept"])
        ctx = w.task(c["group"], a, "commit_cancel", f"Confirm cancellation of {c['cid']}")
        w.tw_write(ctx, c["group"], "commit", c["cid"], "status", {"status": "cancelled", "amount": c["amount"], "expected_settle": c["expected_settle"]},
                   f"{c['cid']} {c['dept']} provisional approval", "cancellation confirmed.")
        w.done(ctx, "Cancelled"); w.counts["commit_death"] += 1
    def L_FIN_earmark(w, g, r, rr):
        dept = rr.choice(DEPTS[r]); amt = w.canary(150_000, 600_000); end = w.day + rr.randint(5, 15)
        why = rr.choice(["training equipment", "new-hire equipment", "meeting room replacement", "quarter-end consumables"])
        a = w.assign(g, "budgeting", dept); ctx = w.task(g, a, "earmark", f"Earmark {dept} budget ({why})")
        fid = w.tw_frag(ctx, "pending_intent", (g, "line", dept, "earmark"), {"dept": dept, "amount": amt, "end": end},
                        f"{dept} capex", f"{amt:,} KRW earmarked for {why} until day {end} (no voucher yet).", numeric=True)
        w.done(ctx, "Earmark recorded")
        w.earmarks.append({"group": g, "dept": dept, "amount": amt, "start": w.day, "end": end, "fid": fid, "seq": w.seq})
    def L_FIN_owner_exc(w, g, r, rr):
        o = rr.choice(w.other_regions(r)); dept = rr.choice(DEPTS[r])
        if any(x["dept"] == dept and x["end"] >= w.day for x in w.owner_exc): return
        a = w.assign(g, "control", dept); end = w.day + rr.randint(10, 25)
        ctx = w.task(g, a, "owner_exc", f"Meeting on who executes the {dept} budget")
        fid = w.tw_frag(ctx, "exception", (g, "line", dept, "owner"), {"dept": dept, "to": o, "end": end},
                        f"{dept} capex executing office", f"agreed that {o} finance executes it until day {end}.", numeric=False)
        w.done(ctx, "Agreement recorded")
        og = f"FIN-{o}"; b = w.assign(og, "budgeting", dept); ctx2 = w.task(og, b, "owner_exc_in", f"Receive {r} {dept} capex line")
        w.tw_write(ctx2, og, "line", dept, "remaining", w.cur((g, "line", dept, "remaining")), f"{dept} capex balance (moved from {r})", f"{w.cur((g, 'line', dept, 'remaining')):,} KRW received.")
        w.tw_write(ctx2, og, "line", dept, "base", w.cur((g, "line", dept, "base")), f"{dept} quarterly base allocation (moved from {r})", f"{w.cur((g, 'line', dept, 'base')):,} KRW.")
        w.done(ctx2, "Line received")
        w.owner_exc.append({"dept": dept, "from": r, "to": o, "start": w.day, "end": end, "fid": fid, "seq": w.seq})
    def L_FIN_q_exc(w, g, r, rr):
        dept = rr.choice(DEPTS[r]); a = w.assign(g, "control", dept); thr = rr.choice([800_000, 1_000_000, 1_200_000])
        ctx = w.task(g, a, "q_exc", f"Apply quarterly spending control for {dept}")
        end = w.day + rr.randint(10, 25)
        fid = w.tw_frag(ctx, "exception", (g, "line", dept, "control"), {"dept": dept, "threshold": thr, "end": end},
                        f"{dept} new equipment spending control", f"items above {thr:,} KRW need division head approval until day {end}.", numeric=True)
        w.done(ctx, "Control applied")
        w.q_exc.append({"region": r, "dept": dept, "threshold": thr, "start": w.day, "end": end, "fid": fid, "seq": w.seq})
    def budget_reset(w, p):
        for r in w.regions:
            g = f"FIN-{r}"
            for dept in sorted(k[2] for k in w.db if k[0] == g and k[1] == "line" and k[3] == "base"):   # 이관받은 라인 포함
                a = w.assign(g, "budgeting", dept); base = w.cur((g, "line", dept, "base"))
                ctx = w.task(g, a, "budget_reset", f"Quarterly reset of {dept}")
                w.tw_write(ctx, g, "line", dept, "remaining", base, f"{dept} capex balance", f"reset to {base:,} KRW for the new quarter.")
                w.done(ctx, "Reset")
        w.log("world", event="budget_reset")

    # ── PROC ──
    def L_PROC_quote_update(w, g, r, rr):
        qs = sorted(q for q, x in w.quotes.items() if x["region"] == r)
        if not qs: return
        q = rr.choice(qs); x = w.quotes[q]; v = w.canary(*PRICE[x["tier"]]); a = w.assign(g, "buying", x["type"])
        ctx = w.task(g, a, "quote_update", f"Update quote of {x['vendor']}")
        w.tw_write(ctx, g, "quote", q, "amount", v, f"{x['vendor']} {x['type']} ({x['tier']}) quote {q}", f"changed to {v:,} KRW (raw material prices).", kind="rationale")
        w.done(ctx, "Updated")
    def L_PROC_exclude(w, g, r, rr):
        vs = [x for x, y in sorted(w.vendors.items()) if y["region"] == r and not any(e["vendor"] == x and e["end"] >= w.day for e in w.exclusions)]
        if not vs: return                                             # 이미 제외 중인 공급사에 중복 제외 메모를 만들지 않는다
        v = rr.choice(vs); a = w.assign(g, "quality", v); end = w.day + rr.randint(5, 14)
        ctx = w.task(g, a, "exclude", f"Review quality issue of supplier {v}")
        fid = w.tw_frag(ctx, "handover", (g, "vendor", v, "excluded"), {"vendor": v, "end": end},
                        f"Supplier {v}", f"exclude from comparisons until day {end} due to a quality issue.", numeric=False)
        w.done(ctx, "Exclusion recorded")
        w.exclusions.append({"region": r, "vendor": v, "start": w.day, "end": end, "fid": fid, "seq": w.seq})
    def L_PROC_receipt(w, g, r, rr):
        cs = sorted(c for c, x in w.commits.items() if x["group"] == f"FIN-{r}" and (w.cur((g, "receipt", c, "received")) is None)
                    and (w.cur((x["group"], "commit", c, "status")) or {}).get("status") in ("pending", "cancelled"))
        if not cs: return
        c = rr.choice(cs); a = w.assign(g, "receiving", c); ctx = w.task(g, a, "receipt", f"Confirm goods receipt for {c}")
        w.tw_write(ctx, g, "receipt", c, "received", True, f"Goods of {c}", "receipt confirmed.")
        w.done(ctx, "Receipt recorded")
    def L_PROC_lead(w, g, r, rr):
        v = rr.choice(sorted(x for x, y in w.vendors.items() if y["region"] == r)); a = w.assign(g, "vendors", v)
        ctx = w.task(g, a, "lead", f"Recheck lead time of supplier {v}")
        w.tw_write(ctx, g, "vendor", v, "lead", rr.randint(3, 12), f"Supplier {v}", "lead time change notice applied.")
        w.done(ctx, "Applied")
    def L_PROC_lead_delay(w, g, r, rr):
        """납기 지연 통보(vendors): 등록된 리드타임은 그대로, 통보 기간 동안 지연 일수를 더해 판단."""
        vs = [x for x, y in sorted(w.vendors.items()) if y["region"] == r and not any(d["vendor"] == x and d["end"] >= w.day for d in w.delays)]
        if not vs: return
        v = rr.choice(vs); add = rr.randint(2, 5); end = w.day + rr.randint(5, 14); a = w.assign(g, "vendors", v)
        ctx = w.task(g, a, "lead_delay", f"Log delivery delay notice from supplier {v}")
        fid = w.tw_frag(ctx, "observation", (g, "vendor", v, "delay"), {"vendor": v, "add": add, "end": end},
                        f"Supplier {v} delivery", f"notified: deliveries delayed by {add} days until day {end}.", numeric=True)
        w.delays.append({"vendor": v, "region": r, "add": add, "start": w.day, "end": end, "fid": fid, "seq": w.seq}); w.done(ctx, "Notice recorded")
    def L_PROC_price_notice(w, g, r, rr):
        itype = rr.choice(list(ITEM_TYPES)); pct = rr.choice([5, 8, 10, 15]); a = w.assign(g, "buying", itype)
        days = w.rule(f"FIN-{w.regions[0]}.reset_calendar")["days"] if w.has("FIN") else [16, 46, 76]
        nxt = next((d for d in days if d > w.day), days[-1])
        ctx = w.task(g, a, "price_notice", f"Review price increase notice for {itype}")
        fid = w.tw_frag(ctx, "observation", (g, "price", itype, "notice"), {"type": itype, "pct": pct, "from": nxt},
                        f"{itype} unit price", f"notified: {pct}% increase from day {nxt}.", numeric=True)
        w.done(ctx, "Notice recorded")
        w.price_notices.append({"region": r, "type": itype, "pct": pct, "from": nxt, "fid": fid, "seq": w.seq})

    # ── LEGAL ──
    def contract_create(w, p):
        e = p["e"]; r = w.emps[e]["region"]; g = f"LEGAL-{r}"; rr = w.R("local")
        terms = {"allowed_tier": rr.choice(["basic", "standard"]), "expiry": w.day + rr.randint(30, 120), "nda": rr.random() < 0.6}
        a = w.assign(g, "contracts", e); ctx = w.task(g, a, "contract_create", f"Sign new contract of {w.emps[e]['name']}")
        w.tw_write(ctx, g, "contract", e, "terms", terms, f"Contract of {w.emps[e]['name']}",
                   f"allowed tier {terms['allowed_tier']}, expires day {terms['expiry']}, NDA {'yes' if terms['nda'] else 'no'}.")
        w.done(ctx, "Contract recorded")
    def contractors(w, r):
        return sorted(e for e in w.emps if w.emps[e]["region"] == r and w.cur((f"LEGAL-{r}", "contract", e, "terms")))
    def L_LEGAL_amend(w, g, r, rr):
        cs = w.contractors(r)
        if not cs: return
        e = rr.choice(cs); t = dict(w.cur((g, "contract", e, "terms"))); t["allowed_tier"] = rr.choice(["basic", "standard"]); t["nda"] = rr.random() < 0.6
        a = w.assign(g, "review", e); ctx = w.task(g, a, "amend", f"Change contract terms of {w.emps[e]['name']}")
        w.tw_write(ctx, g, "contract", e, "terms", t, f"Contract of {w.emps[e]['name']}",
                   f"terms changed: allowed tier {t['allowed_tier']}, expires day {t['expiry']}, NDA {'yes' if t['nda'] else 'no'}.", kind="rationale")
        w.done(ctx, "Change recorded")
    def L_LEGAL_extend(w, g, r, rr, e=None, handle=None):
        cs = w.contractors(r)
        if not cs: return
        e = e or rr.choice(cs); t = dict(w.cur((g, "contract", e, "terms"))); t["expiry"] = max(t["expiry"], w.day) + rr.randint(30, 60)
        a = w.assign(g, "contracts", e); ctx = w.task(g, a, "extend", f"Extend contract of {w.emps[e]['name']}" + (f" (follow-up of {handle})" if handle else ""))
        w.tw_write(ctx, g, "contract", e, "terms", t, f"Contract of {w.emps[e]['name']}",
                   f"extended to day {t['expiry']}, allowed tier {t['allowed_tier']}, NDA {'yes' if t['nda'] else 'no'}.")
        w.done(ctx, "Extension recorded")
    def L_LEGAL_override(w, g, r, rr):
        cs = [e for e in w.contractors(r) if not any(o["emp"] == e and o["end"] >= w.day for o in w.overrides)]   # 유효한 예외가 있으면 중복 심의 안 함
        if not cs: return
        e = rr.choice(cs); a = w.assign(g, "compliance", e); end = w.day + rr.randint(10, 30)
        ctx = w.task(g, a, "override", f"Review equipment exception of {w.emps[e]['name']}")
        fid = w.tw_frag(ctx, "exception", (g, "contract", e, "override"), {"emp": e, "end": end},
                        f"Equipment exception of {w.emps[e]['name']}", f"higher tiers including premium allowed until day {end} for a project, legal check done.", numeric=False)
        w.done(ctx, "Exception recorded")
        w.overrides.append({"emp": e, "start": w.day, "end": end, "fid": fid, "seq": w.seq})

    def L_LEGAL_nda_check(w, g, r, rr):
        """NDA 확인(review): 서명본 확인이 끝나면 기간 동안 NDA 확인 단계를 생략."""
        cs = [e for e in w.contractors(r) if w.cur((g, "contract", e, "terms"))["nda"]
              and not any(x["emp"] == e and x["end"] >= w.day for x in w.nda_checks)]
        if not cs: return
        e = rr.choice(cs); end = w.day + rr.randint(10, 30); a = w.assign(g, "review", e); nm = w.emps[e]["name"]
        ctx = w.task(g, a, "nda_check", f"Check signed NDA of {nm}")
        fid = w.tw_frag(ctx, "observation", (g, "contract", e, "nda_check"), {"emp": e, "end": end},
                        f"NDA of {nm}", f"signed copy verified, NDA check step can be skipped until day {end}.", numeric=False)
        w.nda_checks.append({"emp": e, "region": r, "start": w.day, "end": end, "fid": fid, "seq": w.seq}); w.done(ctx, "Check recorded")

    def flush_index(w):
        """그룹 색인은 하루치를 모아 일과 후(round 4) 한 번에 갱신한다. 정렬해서 내보내므로 이력 줄과 짝지을 수 없다."""
        if w.index_pending:
            w.round = 4
            w.log("index_batch", entries=sorted(w.index_pending, key=lambda x: json.dumps(x, ensure_ascii=False, sort_keys=True)))
            w.index_pending = []

    # ═════════ 1일차 스냅샷 ═════════
    def freeze_day0(w):
        """워밍업이 끝난 시점의 실행 상태를 그대로 동결. 하네스는 여기서 시작한다."""
        reg, pend = [], []
        for key, vs in w.db.items():
            for v in vs:
                row = {"key": kstr(key), "v": v["v"], "day": v["day"], "db_day": v["db_day"], "value": v["value"]}
                (reg if v["db_day"] <= 0 else pend).append(row)
        w.snapshot = {
            "catalog": copy.deepcopy(dict(w.catalog)),
            "db_registered": reg, "db_pending": pend,
            "transcripts": {a: list(es) for a, es in w.tx.items()},
            "journal": {g: list(x) for g, x in w.journal.items()},
            "activity": {g: list(x) for g, x in w.activity.items()},
            "entity_index": {g: {k: sorted(v) for k, v in x.items()} for g, x in w.entity_index.items()},
            "roster": {a: {**m, "active": w.active[a]} for a, m in w.agent_meta.items()},
            "cards": {g: {role: w.card(g, role) for role in sorted(set(ROLES[G["domain"]]))} for g, G in w.groups.items()},
            "queue": [{"day": d, "round": rnd, "prio": pr, "type": typ, "payload": pl} for d, rnd, pr, _, typ, pl in sorted(w.pq)],
            "entities": copy.deepcopy({"commits": w.commits, "transfers": w.transfers, "holds": w.holds, "reservations": w.reservations,
                                       "owner_exc": w.owner_exc, "q_exc": w.q_exc, "exclusions": w.exclusions,
                                       "overrides": w.overrides, "price_notices": w.price_notices, "earmarks": w.earmarks,
                                       "offers": w.offers, "tier_exc": w.tier_exc, "delays": w.delays, "nda_checks": w.nda_checks}),
        }
        w.snapshot["queue"] = copy.deepcopy(w.snapshot["queue"])

    # ═════════ 디스패치 ═════════
    def dispatch(w, typ, p):
        from .generate import gen_cross, apply_effect
        if typ == "cross": gen_cross(w)
        elif typ == "effect": apply_effect(w, p)
        else: getattr(w, typ)(p)

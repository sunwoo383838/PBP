"""교차 작업 합성: 후보 생성 → 결정 필수 성분 판정 → 설계 등급 → 층화 수락 → 반사실 전수 → 확정·렌더링·효과.

층화 수락은 주장에 직결되는 두 축(상태 등급, 관여 그룹 수)만 맞춘다. 목표 비율은 "지금까지 수락한 개수"에 비례하는
누적 할당량으로 적용한다(T와 무관 → 90일 생성의 앞 10·30일이 그대로 T=10·30 시나리오가 된다).
C_ops 하한과 표적 민감도(C_ops→partial, B→neardup|wrong_owner, 반복 요청+값 변경→stale)는 수락 조건이다.
"""
import collections, itertools, math

from .const import CLASS_ORDER, ITEM_TYPES
from .templates import EXT, FOLLOW_SURFACE, ROOT_ROLE, TEMPLATES
from .tracing import TW
from .world import Skip, kstr
from .requests import public_request, clarify_surface

MODES = ("stale", "partial", "neardup", "wrong_owner")
CLASS_TARGET = {"A": .40, "B": .20, "C": .25, "D": .15}
R_TARGET = {"R0": .15, "R1": .40, "R2": .25, "R3": .20}
DISC_TARGET = {"H0": .40, "H1": .40, "H2": .20}


def group_target(D):
    if D <= 3: return {"2": .40, "3+": .60}
    if D == 4: return {"2": .30, "3": .40, "4+": .30}
    return {"2": .20, "3": .30, "4": .30, "5+": .20}


def gbin(n, D):
    keys = list(group_target(D))
    for k in keys:
        if k.endswith("+") and n >= int(k[:-1]): return k
        if not k.endswith("+") and n == int(k): return k
    return keys[0] if n < 2 else keys[-1]


def norm(T, a):
    """닫힌 슬롯 전부(해당 없음 = null)로 정규화. 정답과 반사실 답을 같은 모양으로 저장한다."""
    return {s: a.get(s) for s in T["slots"]} if isinstance(a, dict) else a


def rtier(ops):
    return max((o[0] for o in ops), default="R0")


def run_gold(w, root, fn, p, mode=None):
    t = TW(w, root, mode)
    try: return t, fn(t, p)
    except Skip: return t, "SKIP"


# ═════════ 결정 필수 성분과 설계 등급 ═════════
def critical_fids(w, root, fn, p, gold, points):
    """partial(조각 누락)을 하나씩 적용해 답이 바뀌는(또는 답을 낼 수 없게 되는) 조각만 '결정 필수 성분'으로 본다."""
    crit = set()
    for pt in points:
        if pt["mode"] != "partial": continue
        t2, a = run_gold(w, root, fn, p, ("partial", pt["idx"]))
        if t2.hit and (a == "SKIP" or a != gold): crit.add(pt["at"])
    return crit


def classify(needs, crit):
    """원격 need 등급: A card 대상 한 명(또는 DB·규정)으로 충분 / B 한 명이 갖지만 card 대상 아님 /
    C 둘 이상 합쳐야 함 / D 결정 필수 성분이 활동 중인 누구의 창·요약에도 없음. 작업 등급 = 가장 어려운 need."""
    cls_all, cops = [], False
    for n in needs:
        if n["local"]: n["class"] = None; continue
        comps = [s for s in n["sources"] if s["type"] == "frag" and s.get("role") != "distractor" and s["frag"]["fid"] in crit]
        n["critical_components"] = [s["frag"]["fid"] for s in comps]
        live = [set(h["agent"] for h in s["frag"]["holders"] if h["alive"]) for s in comps]
        if not comps: cl = "A"
        elif any(not L for L in live): cl = "D"
        else:
            inter = set.intersection(*live); cl = "A" if n["card"] in inter else ("B" if inter else "C")
        ops = [L for s, L in zip(comps, live) if s["frag"]["origin"] != "db_pending"]
        n["c_ops"] = cl == "C" and len(ops) >= 2 and not set.intersection(*ops)
        cops = cops or n["c_ops"]
        n["class"] = cl; cls_all.append(cl)
    return (max(cls_all, key=lambda c: CLASS_ORDER[c]) if cls_all else None), cops


def min_cover(live):
    """결정 필수 성분을 모두 덮는 최소 인원(반드시 물어야 하는 사람 수). 살아 있는 보유자가 없는 성분이 있으면 None."""
    if any(not L for L in live): return None
    agents = sorted(set().union(*live)) if live else []
    for k in range(1, len(agents) + 1):
        for combo in itertools.combinations(agents, k):
            cs = set(combo)
            if all(L & cs for L in live): return k
    return 0


def dispersion(needs):
    """need마다 두 지표를 기록한다.
    n_holders: 결정 필수 성분을 하나라도 살아 있게 가진 에이전트의 합집합 크기(정보가 얼마나 넓게 퍼졌나).
    min_cover: 성분을 모두 덮는 최소 인원(몇 명에게 반드시 물어야 하나). min_cover ≥ 2 ⇔ 설계 등급 C.
    반환: (need별 합집합 크기, 도메인별 C need 수)."""
    per, cdom = [], collections.Counter()
    for n in needs:
        if n["local"] or not n.get("critical_components"): continue
        crit = set(n["critical_components"])
        comps = [s for s in n["sources"] if s["type"] == "frag" and s.get("role") != "distractor" and s["frag"]["fid"] in crit]
        live = [{h["agent"] for h in s["frag"]["holders"] if h["alive"]} for s in comps]
        hold = set().union(*live) if live else set()
        n["n_holders"] = len(hold); n["min_cover"] = min_cover(live); per.append(len(hold))
        if n.get("class") == "C": cdom[n["group"].split("-")[0]] += 1
    return per, dict(sorted(cdom.items()))


def need_versions(n):
    """need가 읽은 버전 있는 출처(DB 레코드, 등록 전 최신 버전 조각)의 {key: v}. 같은 need의 값이 바뀌었는지 판정용."""
    return {s["key"]: s["v"] for s in n["sources"] if s.get("key") and "v" in s}


# ═════════ 후보 합성 ═════════
def synth(w, rr, follow=None):
    enabled = sorted(k for k, T in TEMPLATES.items() if T["core"] <= set(w.domains) and any(d in w.domains for d in T["roots"]))
    name = follow["template"] if follow else rr.choices(enabled, [TEMPLATES[k]["weight"] for k in enabled])[0]
    T = TEMPLATES[name]
    if follow:
        p = dict(follow["params"]); rd = follow["root_dom"]
    else:
        rd = rr.choice([d for d in T["roots"] if d in w.domains])
        p = {"r": rr.choice(w.regions), "ext": [x for x in T["exts"] if EXT[x] in w.domains and rr.random() < w.P.p_ext]}
        try: T["sampler"](w, rr, p)
        except Skip: return None
    root = f"{rd}-{p['r']}"
    t0 = TW(w, root)
    if follow and follow.get("result_fid"):                  # 후속 작업: 선행 작업의 결과는 요청 그룹 자기 이력에 있다(로컬 need)
        t0.begin(f"{root}/task/{follow['handle']}/result", root, ROOT_ROLE[rd]); t0.frag(follow["result_fid"], numeric=False)
    try: gold = T["gold"](t0, p)
    except Skip: return None
    remote = [n for n in t0.needs if not n["local"]]
    if not remote or any(not n["sources"] for n in remote): return None
    crit = critical_fids(w, root, lambda t, q: (_pre(t, follow, root, rd), T["gold"](t, q))[1], p, gold, t0.points)
    cls, cops = classify(t0.needs, crit)
    per, mdom = dispersion(t0.needs)
    disc = collections.Counter(s["frag"]["disc"] for n in t0.needs if not n["local"] for s in n["sources"]
                               if s["type"] == "frag" and s["frag"]["fid"] in n.get("critical_components", []))
    groups = [root] + [n["group"] for n in t0.needs]
    seqd = [g for i, g in enumerate(groups) if i == 0 or g != groups[i - 1]]
    ng = len(set(groups)); xr = any(g.split("-")[1] != p["r"] for g in groups)
    sig = (f"F:{name}<{follow['src']}|" if follow else f"{name}|") + f"{rd}|{','.join(sorted(p['ext']))}|{'>'.join(g.split('-')[0] for g in seqd)}|{cls}|{'x' if xr else 'l'}"
    ent = (p["r"], p.get("emp") or p.get("cid") or p.get("dept") or p.get("iid") or p.get("sw") or p.get("itype"), (p.get("teams") or [None])[0])
    rep = False
    for n in remote:
        prev, now = w.need_seen.get(n["sem"]), need_versions(n)
        if prev and any(k in now and now[k] != v for k, v in prev.items()): rep = True
    return {"name": name, "T": T, "rd": rd, "root": root, "p": p, "gold": gold, "t0": t0, "crit": crit, "cls": cls, "cops": cops,
            "n_groups": ng, "gbin": gbin(ng, w.P.D), "path": seqd, "xr": xr, "sig": sig, "ck": (name, ent),
            "R": rtier(t0.ops), "repeat_changed": rep, "follow": follow, "disc": disc, "disp": max(per, default=0), "mdom": mdom}      # mdom = C need가 있는 도메인


def _pre(t, follow, root, rd):
    if follow and follow.get("result_fid"):
        t.begin(f"{root}/task/{follow['handle']}/result", root, ROOT_ROLE[rd]); t.frag(follow["result_fid"], numeric=False)


def counterfactuals(w, c):
    fn = lambda t, q: (_pre(t, c["follow"], c["root"], c["rd"]), c["T"]["gold"](t, q))[1]
    res = {m: {"points": 0, "skipped": 0, "sensitive": []} for m in MODES}
    for pt in c["t0"].points:
        t2, a = run_gold(w, c["root"], fn, c["p"], (pt["mode"], pt["idx"]))
        if not t2.hit: continue
        r = res[pt["mode"]]
        if a == "SKIP": r["skipped"] += 1; continue                   # 비튼 결과 정답 함수 불성립 → 그 지점 제외
        r["points"] += 1
        if a != c["gold"]: r["sensitive"].append({"idx": pt["idx"], "need": pt["need"], "at": pt["at"], "answer": a})
    t3, a3 = run_gold(w, c["root"], fn, c["p"], ("stale", "all"))
    c["cf"] = {m: {"points": r["points"], "skipped": r["skipped"], "n_sensitive": len(r["sensitive"]),
                   "sensitive_points": [{k: v for k, v in s.items() if k != "answer"} for s in r["sensitive"]],
                   "example_answer": norm(c["T"], r["sensitive"][0]["answer"]) if r["sensitive"] else None} for m, r in res.items()}
    c["sensitive"] = {m: res[m]["points"] > 0 and bool(res[m]["sensitive"]) for m in MODES}
    c["applicable"] = {m: res[m]["points"] > 0 for m in MODES}
    c["stale_all_correct"] = bool(t3.hit) and a3 == c["gold"]


# ═════════ 층화 수락 ═════════
def quota_violation(w, c, k):
    P = w.P; A = w.acc
    v = max(0.0, A["cls"][c["cls"]] + 1 - (CLASS_TARGET[c["cls"]] * k + P.slack))
    v += max(0.0, A["grp"][c["gbin"]] + 1 - (group_target(P.D)[c["gbin"]] * k + P.slack))
    v += P.r_weight * max(0.0, A["R"][c["R"]] + 1 - (R_TARGET[c["R"]] * k + P.slack))     # R 등급: 약한 제3축
    n_after = sum(A["disc"].values()) + sum(c["disc"].values())                          # 결정 필수 성분의 발견성: 약한 제4축
    v += P.disc_weight * sum(max(0.0, A["disc"][h] + c["disc"][h] - (DISC_TARGET[h] * n_after + 3)) for h in DISC_TARGET)
    if c["mdom"]:                                                                        # v4.2: C need(둘 이상 합쳐야 함) 수의 도메인 균형(need 단위): 약한 제5축
        m_after = A["md_n"] + sum(c["mdom"].values()); share_d = 1.0 / len(w.domains)
        v += P.dd_weight * sum(max(0.0, A["md"][d] + k - (share_d * m_after + P.dd_slack)) for d, k in c["mdom"].items())
    return v


def sens_ok(w, c):
    """표적 민감도: 부분집합마다 해당 반사실 민감 비율이 sens_min + 0.05 아래로 떨어지게 하는 후보는 받지 않는다."""
    A = w.acc; checks = []
    if c["cops"]: checks.append(("cops", c["sensitive"]["partial"]))
    if c["cls"] == "B": checks.append(("B", c["sensitive"]["neardup"] or c["sensitive"]["wrong_owner"]))
    if c["repeat_changed"]: checks.append(("repeat", c["sensitive"]["stale"]))
    for s, ok in checks:
        n, hit = A["sub_n"][s], A["sub_hit"][s]
        if not ok and (hit / (n + 1)) < w.P.sens_min + 0.05: return False
    return True


def gen_cross(w):
    rr = w.R("task"); P = w.P; k = len(w.tasks) + 1
    tried, best = 0, None
    # 1) 기한이 된 명시적 후속 작업 먼저
    while w.follow_q and w.follow_q[0]["due"] <= w.day:
        f = w.follow_q.pop(0)
        if f["template"] == "conflict":
            cid = w.handle_commit.get(f["handle"])
            if not cid: continue
            f["params"]["cid"] = cid
        c = synth(w, rr, f)
        if c is None: w.counts["follow_invalid"] += 1; continue
        if quota_violation(w, c, k) > P.follow_slack or w.sig[c["sig"]] + 1 > max(3, P.sig_cap * k): w.counts["follow_rejected"] += 1; continue
        counterfactuals(w, c)
        if not sens_ok(w, c): w.counts["follow_rejected"] += 1; continue
        return finalize(w, c, rr)
    # 2) 일반 후보
    pool = []
    deficit0 = w.acc["cops"] < P.cops_aim * k + 1
    for attempt in range(P.max_tries * (2 if deficit0 else 1)):          # C_ops가 모자라면 후보를 더 본다
        c = synth(w, rr)
        if c is None: w.counts["cand_invalid"] += 1; continue
        w.candidates.append({"day": w.day, "cls": c["cls"], "gbin": c["gbin"], "n_groups": c["n_groups"], "cops": c["cops"], "R": c["R"],
                             "template": c["name"], "root": c["rd"], "max_holders": c["disp"], "c_need_domains": c["mdom"]})
        if w.sig[c["sig"]] + 1 > max(3, P.sig_cap * k): w.counts["rej_signature"] += 1; continue
        v = quota_violation(w, c, k)
        if c["ck"] in w.cooldown and w.day - w.cooldown[c["ck"]] < P.cooldown:
            w.counts["rej_cooldown"] += 1; pool.append((v + 5, attempt, c)); continue
        cops_deficit = w.acc["cops"] < P.cops_aim * k + 1
        if cops_deficit and not c["cops"]: v += 2.0
        if v > 0:
            w.counts["rej_quota"] += 1; pool.append((v, attempt, c)); continue
        counterfactuals(w, c)
        if not sens_ok(w, c): w.counts["rej_sensitivity"] += 1; continue
        return finalize(w, c, rr)
    for v, _, c in sorted(pool, key=lambda x: (deficit0 and not x[2]["cops"], x[0], x[1]))[:12]:   # 할당량을 채울 후보가 없으면 가장 덜 넘치는 후보(C_ops 부족 시 C_ops 우선, 민감도 조건은 유지)
        counterfactuals(w, c)
        if sens_ok(w, c):
            w.counts["fallback_accept"] += 1; return finalize(w, c, rr, fallback=True)
    for _ in range(P.max_tries):                               # 그래도 없으면 서명 상한만 지키는 첫 유효 후보 (슬롯을 비우지 않는다)
        c = synth(w, rr)
        if c is None or w.sig[c["sig"]] + 1 > max(3, P.sig_cap * k): continue
        counterfactuals(w, c); w.counts["fallback_any"] += 1
        return finalize(w, c, rr, fallback=True)
    w.counts["slot_empty"] += 1


# ═════════ 확정 ═════════
def result_text(name, g):
    if not isinstance(g, dict): return str(g)
    return ", ".join(f"{k}={v}" for k, v in g.items())


def finalize(w, c, rr, fallback=False):
    P = w.P; T = c["T"]; p = c["p"]; root, rd = c["root"], c["rd"]; t0 = c["t0"]
    seq0 = w.seq                                              # 설계 등급을 판정한 시점(이후 이력 추가 전)
    wid = w.newid("W"); w.cur_eid = wid
    asg = w.assign(root, ROOT_ROLE[rd], wid)
    emp = w.emps.get(p.get("emp"), {})
    if c["follow"]:
        text = FOLLOW_SURFACE[c["follow"].get("surface", c["name"])].format(handle=c["follow"]["handle"], **{k: v for k, v in p.items() if k in ("itype", "tier")})
    else:
        text = T["surface"].format(**{**p, "alias": emp.get("alias", ""), "teams": p.get("teams", ["", "", ""])})
    request = public_request(w, c)
    text = clarify_surface(text, request)
    # 요청자 이력(생성기 모사): 과제 도착 + 정형 결과. 결과는 요청 그룹의 operational 조각(후속 작업의 로컬 need)
    w.say(asg, "user", "cross_task", "[Cross-group task] " + text, shadow=True)
    rfid = w.frag(root, asg, "task_result", "operational", ("task", wid, "result"), c["gold"], f"{wid} item", "result: " + result_text(c["name"], c["gold"]),
                  numeric=True, disc="H1", role="assistant", shadow=True)
    w.tx[asg][-1]["tok"] += P.out_overhead; w.cum[asg][-1] += P.out_overhead
    # 응답자 이력(방법 중립 추정): 원격 그룹마다 card 대상에게 응대 분량만큼 토큰 추가
    for g in sorted({n["group"] for n in t0.needs if not n["local"]}):
        role = next(n["role"] for n in t0.needs if n["group"] == g)
        w.say(w.card(g, role), "user", "xreq_est", "[Cross-group request handled — generator size estimate]", extra_tok=P.resp_est, shadow=True)
    w.cur_eid = None
    c["gold"] = norm(T, c["gold"])
    needs = t0.needs; cross_needs = [n for n in needs if not n["local"]]
    single = True                                             # 한 명 오라클: 그룹마다 결정 필수 성분을 모두 가진 한 명이 있는가
    for grp in {n["group"] for n in cross_needs}:
        live = [set(h["agent"] for h in s["frag"]["holders"] if h["alive"]) for n in cross_needs if n["group"] == grp
                for s in n["sources"] if s["type"] == "frag" and s.get("role") != "distractor" and s["frag"]["fid"] in c["crit"]]
        if live and not set.intersection(*live): single = False
    comps = [s for n in cross_needs for s in n["sources"] if s["type"] == "frag" and s.get("role") != "distractor"]
    crit_comps = [s for s in comps if s["frag"]["fid"] in c["crit"]]
    task = {"wid": wid, "day": w.day, "round": w.round, "seq": seq0, "template": c["name"], "family": T["family"], "root": root,
            "root_domain": rd, "assignee": asg, "assignee_topology": w.groups[root]["topology"], "surface": text, "ext": sorted(p["ext"]),
            "params": {k: v for k, v in p.items() if k != "ext"}, "request": request, "follows": c["follow"]["handle"] if c["follow"] else None,
            "gold": c["gold"], "needs": needs, "path": c["path"], "n_groups": c["n_groups"], "group_bin": c["gbin"],
            "path_len": len(c["path"]), "revisit": len(c["path"]) != len(set(c["path"])),
            "domains": sorted({g.split('-')[0] for g in c["path"]}), "state_class": c["cls"], "c_ops": c["cops"], "R": c["R"], "ops": t0.ops,
            "repeat_changed": c["repeat_changed"], "counterfactual": c["cf"], "sensitive": c["sensitive"], "cf_applicable": c["applicable"],
            "n_frag_components": len(comps), "n_critical_components": len(crit_comps),
            "critical_origin": dict(collections.Counter(s["frag"]["origin"] for s in crit_comps)),
            "critical_disc": dict(collections.Counter(s["frag"]["disc"] for s in crit_comps)),
            "result_fid": rfid, "fallback": fallback, "signature": c["sig"], "max_holders": c["disp"], "c_need_domains": c["mdom"],
            "oracle": {"local_only": False,
                       "db_only": not any(s["type"] == "frag" and s.get("role") != "distractor" for n in needs for s in n["sources"]),
                       "card_db": c["cls"] == "A", "single_holder": single, "all_history": None,
                       "stale_one_version": c["stale_all_correct"]}}
    w.tasks.append(task)
    w.log("cross", work=wid, group=root, assignee=asg, follows=task["follows"])
    # 누적 수락 통계
    A = w.acc; A["md"].update(c["mdom"]); A["md_n"] += sum(c["mdom"].values()); A["cls"][c["cls"]] += 1; A["grp"][c["gbin"]] += 1; A["R"][c["R"]] += 1; A["cops"] += int(c["cops"]); A["disc"].update(c["disc"])
    for s, ok in (("cops", c["sensitive"]["partial"]) if c["cops"] else (None, None),
                  ("B", c["sensitive"]["neardup"] or c["sensitive"]["wrong_owner"]) if c["cls"] == "B" else (None, None),
                  ("repeat", c["sensitive"]["stale"]) if c["repeat_changed"] else (None, None)):
        if s: A["sub_n"][s] += 1; A["sub_hit"][s] += int(ok)
    w.sig[c["sig"]] += 1; w.cooldown[c["ck"]] = w.day
    for n in cross_needs: w.need_seen[n["sem"]] = need_versions(n)
    schedule_effects(w, task, p, rr)
    return task


# ═════════ 작업 간 결합(정답 기준 효과)과 명시적 후속 ═════════
def schedule_effects(w, task, p, rr):
    g, n, wid = task["gold"], task["template"], task["wid"]; P = w.P
    if n == "purchase" and g["decision"] in ("assign", "order"):
        w.push(w.day + 1, rr.randint(1, 3), 2, "effect", {"kind": g["decision"], "r": p["r"], "emp": p["emp"], "option": g["option"], "handle": wid})
    if n == "vendor" and g.get("vendor"):
        w.push(w.day + 1, rr.randint(1, 3), 2, "effect", {"kind": "order_dept", "r": p["r"], "dept": p["dept"], "amount": g["amount"], "handle": wid})
    elif n == "alloc" and sum(g["alloc"]) > 0:
        w.push(w.day + 1, rr.randint(1, 3), 2, "effect", {"kind": "seats", "r": p["r"], "sw": p["sw"],
               "allocate": sum(g["alloc"]), "transfer": g["transfer"], "buy": g["buy"], "handle": wid})
    elif n == "renewal":
        w.push(w.day + 1, rr.randint(1, 3), 2, "effect", {"kind": "renew" if g["renew"] else "recover", "r": p["r"], "emp": p["emp"], "assets": g["recover_assets"], "handle": wid})
    if task["follows"]: return
    fr = w.R("follow")
    n_follow = sum(1 for t in w.tasks if t["follows"]) + len(w.follow_q)
    if n_follow >= P.follow_target * (len(w.tasks) + 1) + 2: return          # 명시적 후속 비율 제어(목표 약 10%)
    base = {"handle": wid, "root_dom": task["root_domain"], "result_fid": task["result_fid"], "src": n}
    if n == "purchase" and g["decision"] in ("assign", "order") and fr.random() < P.p_follow_lookup:
        w.follow_q.append({**base, "template": "lookup", "due": w.day + fr.randint(2, 4), "params": {"r": p["r"], "ext": [], "emp": p["emp"]}})
    elif (n == "purchase" and g["decision"] in ("assign", "order")) or (n == "precedence" and g["approver"] != "not_allowed"):
        if fr.random() < P.p_follow_plan:
            if n == "purchase":
                opt = g["option"]; x = w.quotes.get(opt) or w.inv.get(opt)
                amount = w.cur((f"PROC-{w.quotes[opt]['region']}", "quote", opt, "amount")) if opt in w.quotes else x["cost"]
                vendor = w.quotes[opt]["vendor"] if opt in w.quotes else None; itype, tier = x["type"], x["tier"]
            else:
                amount, vendor, itype, tier = p["amount"], None, p["itype"], p["tier"]
            w.follow_q.append({**base, "template": "plan", "due": w.day + fr.randint(1, 3),
                               "params": {"r": p["r"], "ext": p["ext"], "emp": p["emp"], "itype": itype, "tier": tier, "amount": amount, "vendor": vendor}})
    if n in ("whatif", "temporal") and (g.get("now") or g.get("later") or g.get("budget_dept")) and fr.random() < P.p_follow_plan:
        tiers = ITEM_TYPES[p["itype"]]; vend = sorted(v for v, x in w.vendors.items() if x["region"] == p["r"])
        w.follow_q.append({**base, "template": "plan", "surface": "plan_explicit", "due": w.day + fr.randint(1, 3),     # 원 과제에 없던 등급은 문장에 명시
                           "params": {"r": p["r"], "ext": [x for x in p["ext"] if x in ("proc",)], "emp": p["emp"], "itype": p["itype"],
                                      "tier": tiers[min(1, len(tiers) - 1)], "amount": p["amount"], "vendor": vend[0] if vend else None}})
    if n == "budget" and w.has("PROC") and fr.random() < P.p_follow_plan:
        w.follow_q.append({**base, "template": "vendor", "due": w.day + fr.randint(1, 3),
                           "params": {"r": p["r"], "ext": ["residency"] if w.has("LEGAL") and fr.random() < P.p_ext else [], "dept": p["dept"],
                                      "itype": fr.choice(list(ITEM_TYPES)), "xregion": False}})
    if (n == "purchase" and g["decision"] == "order") or (n == "vendor" and g.get("vendor")):
        if fr.random() < P.p_follow_conflict:
            w.follow_q.append({**base, "template": "conflict", "due": w.day + fr.randint(2, 5),
                               "params": {"r": p["r"], "ext": [x for x in p["ext"] if x == "proc"] or (["proc"] if w.has("PROC") else [])}})
    w.follow_q.sort(key=lambda f: (f["due"], f["handle"]))


def apply_effect(w, p):
    rr, r = w.R("effect"), p["r"]
    if p["kind"] == "assign": w.L_IT_assign(f"IT-{r}", r, rr, e=p["emp"], iid=p["option"], handle=p["handle"])
    elif p["kind"] == "order":
        prof = w.cur((f"HR-{r}", "emp", p["emp"], "profile")); q = w.quotes[p["option"]]
        g = f"FIN-{r}"
        for x in w.owner_exc:
            if x["dept"] == prof["dept"] and x["from"] == r and x["start"] <= w.day <= x["end"]: g = f"FIN-{x['to']}"
        amt = w.canary_plus(w.cur((f"PROC-{q['region']}", "quote", p["option"], "amount")), 3_000, 30_000)     # 견적 + 배송비
        w.commit_review(g, r, prof["dept"], amt, q["type"] + " (incl. shipping)", rr, handle=p["handle"])
    elif p["kind"] == "order_dept":
        g = f"FIN-{r}"
        for x in w.owner_exc:
            if x["dept"] == p["dept"] and x["from"] == r and x["start"] <= w.day <= x["end"]: g = f"FIN-{x['to']}"
        w.commit_review(g, r, p["dept"], w.canary_plus(p["amount"], 3_000, 30_000), "order (incl. shipping)", rr, handle=p["handle"])
    elif p["kind"] == "seats": w.apply_seat_allocation(p)
    elif p["kind"] == "renew": w.L_LEGAL_extend(f"LEGAL-{r}", r, rr, e=p["emp"], handle=p["handle"])
    elif p["kind"] == "recover":
        for _ in p["assets"]: w.L_IT_recover(f"IT-{r}", r, rr, only=set(p["assets"]), handle=p["handle"])
    w.counts["effect:" + p["kind"]] += 1

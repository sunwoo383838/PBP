"""규정 문서 = 단일 출처.

규칙마다 {id, group, title, text, params}. 에이전트는 text를 읽고, 정답 함수는 params만 읽는다.
정답 함수 코드에는 규칙 상수를 두지 않는다. text는 params에서 렌더링하므로 둘이 어긋날 수 없다.
"""
from .const import DEPTS, SOFTWARE


def _won(v): return f"{v:,} KRW"


def build(domains, regions, rng, canary):
    R = {}

    def add(g, name, title, params, render):
        rid = f"{g}.{name}"
        R[rid] = {"id": rid, "group": g, "title": title, "params": params, "text": render(params)}

    for r in regions:
        if "FIN" in domains:
            g = f"FIN-{r}"
            add(g, "approval_tiers", "Approval tiers",
                {"tiers": [[1_000_000, "team_lead"], [2_500_000, "division_head"], [None, "cfo"]]},
                lambda p: "Approver by spending amount: " + ", ".join(
                    (f"up to {_won(lim)}: {who}" if lim else f"above that: {who}") for lim, who in p["tiers"]) + ".")
            add(g, "newcomer_waiver", "New-hire equipment waiver",
                {"days": 30, "cap": 1_500_000, "approver": "team_lead"},
                lambda p: f"Equipment items of {_won(p['cap'])} or less for employees within {p['days']} days of joining are approved by {p['approver']} instead.")
            add(g, "pending_deduction", "Available budget (Art. 4.2)",
                {"deduct_statuses": ["reviewing", "pending"], "earmarks_deducted": True, "deduct_until": "day_before_settle"},
                lambda p: "Available budget = line balance − (sum of items under review or provisionally approved)"
                          + (" − (sum of earmarks in their validity period)" if p["earmarks_deducted"] else "")
                          + ". An item is deducted only until the day before its expected settlement day (not on the settlement day itself). An earmark is deducted through its end day.")
            add(g, "reset_calendar", "Quarterly budget reset",
                {"days": [16, 46, 76]},
                lambda p: "Line balances are reset to the base allocation on " + ", ".join(f"day {d}" for d in p["days"]) + ".")
            add(g, "owner_exception", "Executing office arrangement",
                {"exception_overrides_owner": True},
                lambda p: "If it has been agreed that another region's finance office executes a department budget, that office executes it for the agreed period.")
            add(g, "status_authority", "Validity of provisional approval status",
                {"authoritative": ["db", "owner_record"], "informal_excluded": True},
                lambda p: "Only the registered record and the handling officer's processing record determine a provisional approval's status. Informal remarks or discussions do not change it.")
            add(g, "q_exception_approver", "Quarterly spending control",
                {"approver": "division_head"},
                lambda p: f"For a department under a quarterly spending control, items above the threshold need {p['approver']} approval.")
            add(g, "invoice_match_precedence", "Reporting invoice mismatch causes",
                {"order": ["EMP_EXITED", "ASSET_NOT_REGISTERED", "RECEIPT_MISSING", "VENDOR_EXCLUDED",
                           "CONTRACT_EXPIRED", "COMMIT_CANCELLED", "COMMIT_NOT_CONFIRMED", "AMOUNT_MISMATCH"]},
                lambda p: "If an invoice fails to match for several reasons, report only the first one in this order: " + " > ".join(p["order"]) + ".")
            add(g, "seat_purchase_line", "Seat purchase budget",
                {"charge_to": "first_team"},
                lambda p: "Seat purchases are charged to the budget of the first team in the request list.")
        if "HR" in domains:
            g = f"HR-{r}"
            add(g, "transfer_effective_day", "Transfer effective day",
                {"inclusive": True},
                lambda p: "An employee belongs to the new department from the transfer's effective day itself.")
            add(g, "headcount_definition", "Headcount definition",
                {"count_status": "active"},
                lambda p: "Headcount counts only employees in active status. Employees whose transfer is not yet effective count in their current department.")
            add(g, "planning_headcount", "Planning headcount for allocation",
                {"horizon": 7, "include_confirmed_hires": True, "apply_transfers": True},
                lambda p: f"The planning headcount used for seat and equipment allocation is the headcount plus confirmed hires starting within {p['horizon']} days from today, "
                          f"with transfers taking effect within {p['horizon']} days counted in their new department.")
        if "IT" in domains:
            g = f"IT-{r}"
            add(g, "eligibility", "Equipment tier by grade",
                {"grade_tier": {"1": "basic", "2": "basic", "3": "standard", "4": "standard", "5": "premium"}},
                lambda p: "Default equipment tier by grade: " + ", ".join(f"grade {k} {v}" for k, v in sorted(p["grade_tier"].items())) + ". A higher tier needs an IT exception.")
            add(g, "tier_exception", "Equipment tier exception",
                {"exception_raises_tier": True},
                lambda p: "An equipment tier exception approved by IT replaces the grade-based default tier during the exception period.")
            add(g, "seat_price", "Standard seat price",
                {"price": canary(120_000, 260_000)},
                lambda p: f"When there is no supplier price, one seat costs {_won(p['price'])}.")
            add(g, "seat_transfer_share", "Inter-region seat transfer",
                {"share_num": 1, "share_den": 2},
                lambda p: f"Up to {p['share_num']}/{p['share_den']} (rounded down) of another region's free seats may be transferred.")
            add(g, "hold_policy", "Stock holds",
                {"holds_reduce_available": True},
                lambda p: "Stock held for a specific purpose and reserved seats are excluded from the available quantity during the hold.")
        if "PROC" in domains:
            g = f"PROC-{r}"
            add(g, "lead_time_limit", "Lead time limits",
                {"purchase_max_days": 7, "vendor_max_days": 10},
                lambda p: f"Personal equipment orders use only suppliers with a lead time of {p['purchase_max_days']} days or less; department orders {p['vendor_max_days']} days or less.")
            add(g, "delay_notice", "Delivery delay notice",
                {"delay_adds_to_lead": True},
                lambda p: "During a supplier's delay notice period, the notified delay is added to the registered lead time when checking lead time limits.")
            add(g, "vendor_onboarding", "Supplier registration",
                {"unregistered_step": "PROC_VENDOR_ONBOARD"},
                lambda p: "Trading with an unregistered supplier first requires the supplier registration step.")
            add(g, "no_cancel_after_receipt", "Cancellation after receipt",
                {"receipt_voids_cancel": True},
                lambda p: "Cancelling the provisional approval of an item whose goods receipt is confirmed has no effect (it stays provisionally approved).")
            add(g, "price_notice_policy", "Price increase notice",
                {"apply_from_effective_day": True},
                lambda p: "A notified price increase applies to all new items from the effective day stated in the notice.")
        if "LEGAL" in domains:
            g = f"LEGAL-{r}"
            add(g, "contractor_policy", "Contractor equipment policy",
                {"premium_requires_override": True, "above_allowed_requires_override": True,
                 "standard_with_nda": "nda", "override_approver": "legal_and_division_head", "nda_confirmation_clears": True},
                lambda p: "Premium equipment for contractors and equipment above the contract's allowed tier need a legal exception"
                          f" (approver {p['override_approver']}). Standard equipment for a contractor whose contract has an NDA clause needs an NDA check"
                          + (". However, a contractor whose signed NDA copy has been verified and is still valid skips the NDA check step." if p["nda_confirmation_clears"] else "."))
            add(g, "residency", "Data residency",
                {"restricted_depts": sorted(rng.sample(DEPTS[r], 2))},
                lambda p: "These departments may not use equipment from offshore suppliers: " + ", ".join(p["restricted_depts"]) + ".")
            add(g, "sw_contractor", "Contractor software restriction",
                {"blocked": sorted(rng.sample(SOFTWARE, 2))},
                lambda p: "Contractors are not assigned seats of these software products: " + ", ".join(p["blocked"]) + ".")
            add(g, "renewal_policy", "Contract renewal",
                {"min_grade": 2},
                lambda p: f"Renewal conditions: active employment, grade {p['min_grade']} or higher, renewal cost within the department's available budget.")
    return R

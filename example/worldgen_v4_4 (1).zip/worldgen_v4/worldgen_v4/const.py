"""고정 상수: 도메인·역할·이름·품목. 규칙 파라미터는 여기 두지 않는다(rulebook.py가 단일 출처)."""

ALL_DOMAINS = ["HR", "IT", "FIN", "PROC", "LEGAL"]
ALL_REGIONS = ["SEL", "TYO", "SGP"]

# v4.2: 그룹당 5명 = 서로 다른 역할 4개 + 가장 바쁜 역할 1개 중복. 도메인마다 한 need의 결정 필수 성분이
# 서로 다른 역할에 흩어지는 운영 사슬이 있다(HR 계획 인원, IT 가용 재고·좌석, FIN 집행 가능액, PROC 견적 후보, LEGAL 계약 게이트).
ROLES = {"HR": ["records", "records", "payroll", "recruiting", "mobility"],
         "IT": ["assets", "assets", "access", "licenses", "provisioning"],
         "FIN": ["budgeting", "payables", "payables", "closing", "control"],
         "PROC": ["buying", "buying", "vendors", "receiving", "quality"],
         "LEGAL": ["contracts", "contracts", "compliance", "privacy", "review"]}

# A2A card: 업무 범위만 적는다. 누가 어떤 건을 맡았는지, 진행 중인 건, 합의된 예외는 절대 넣지 않는다.
# A2A card: 업무 범위만 적는다. 누가 어떤 건을 맡았는지, 진행 중인 건, 합의된 예외는 절대 넣지 않는다.
CARD = {"records": "Look up and update employee department, grade and contract type records", "payroll": "Pay grades and grade changes",
        "recruiting": "Hiring, onboarding and offboarding", "mobility": "Personnel moves and department transfers",
        "assets": "Equipment assignment and recovery, in-house stock", "access": "Accounts and access rights, equipment tier decisions",
        "licenses": "Software license seat management", "provisioning": "Equipment and seat preparation for new hires",
        "budgeting": "Budget line planning, adjustment and balance lookup", "payables": "Provisional approval review, registration and settlement", "closing": "Month-end close and cancellation confirmation", "control": "Spending controls and budget owner arrangements",
        "buying": "Quote requests and purchase orders", "vendors": "Supplier ratings and lead times", "receiving": "Goods receipt and delivery confirmation", "quality": "Supplier quality management",
        "contracts": "Contract terms and durations", "compliance": "Approval policies and exception decisions", "privacy": "Data residency rules", "review": "Contract change review and NDA checks",
        "coordinator": "Request intake and worker dispatch", "worker": "Handles assigned items"}

# 부서명은 지역마다 서로 다르다(집행 주체 예외로 다른 지역 재무에 라인이 옮겨가도 키가 겹치지 않게).
DEPTS = {"SEL": ["Sales Team 1", "Sales Team 2", "Dev Team 1", "Dev Team 2", "Marketing Team", "Customer Support Team"],
         "TYO": ["Sales Section 1", "Sales Section 2", "Dev Section 1", "Dev Section 2", "Planning Section", "Support Section"],
         "SGP": ["Sales-A", "Sales-B", "Dev-A", "Dev-B", "Marketing", "Support"]}

NAMES = {"SEL": ["Kim Harin", "Park Doyun", "Lee Seojun", "Choi Jiwoo", "Jung Yerin", "Han Siwoo", "Oh Minjae", "Yoon Chaewon", "Jang Woojin", "Shin Daeun",
                 "Lim Hajun", "Kwon Soyul", "Cho Eunho", "Kang Seoa", "Bae Jihoon", "Moon Gaon", "Song Yuna", "Hwang Taeo", "Seo Jian", "Noh Haeun",
                 "Yoo Gunwoo", "Namgung Sol", "Pyo Jisung", "Ok Dain", "Jegal Yoon", "Bong Seoha", "Tak Jiho", "Mo Seoyun", "Pi Jaewon", "Byun Haram"],
         "TYO": ["Sato Yui", "Ono Ken", "Tanaka Sho", "Takahashi Misaki", "Suzuki Daisuke", "Ito Aoi", "Watanabe Ren", "Yamamoto Hina", "Nakamura Yu", "Kobayashi Rin",
                 "Kato Minato", "Yoshida Kaede", "Yamada Sou", "Matsumoto Tsumugi", "Inoue Ritsu", "Kimura Yuito", "Hayashi Mei", "Shimizu Hayate", "Yamaguchi Mio", "Mori Yamato",
                 "Ikeda Hikaru", "Hashimoto Moe", "Ishikawa Sota", "Maeda An", "Fujita Riku", "Okada Saki", "Goto Wataru", "Hasegawa Fuka", "Murakami Kota", "Kondo Aya"],
         "SGP": ["Tan Wei", "Lim Hui", "Ng Jia", "Goh Ren", "Lee Min", "Ong Kai", "Teo Yan", "Chua Li", "Koh Zhi", "Yeo Shan",
                 "Sim Rui", "Low Jun", "Ho Xin", "Seah En", "Tay Qi", "Wong Hao", "Chan Yi", "Toh Ming", "Poh Wen", "Quek Ann",
                 "Foo Kai", "Heng Lu", "Khoo Bo", "Lau Yi", "Neo Tian", "Pang Wei", "Soh Ling", "Yap Jin", "Zhou An", "Kwek Hui"]}

ITEM_TYPES = {"laptop": ["basic", "standard", "premium"], "workstation": ["standard", "premium"], "monitor": ["basic", "standard"]}
ITEM_CODE = {"laptop": "LT", "workstation": "WS", "monitor": "MN"}     # id에 쓰는 ASCII 품목 코드
TIER_RANK = {"basic": 0, "standard": 1, "premium": 2}
PRICE = {"basic": (450_000, 900_000), "standard": (900_000, 1_600_000), "premium": (1_600_000, 2_500_000)}
SOFTWARE = ["CAD", "IDE Pro", "Analytics", "Design Suite"]
CLASS_ORDER = {"A": 0, "B": 1, "C": 2, "D": 3}

# (etype, attr) → 이 값을 쓰는 need가 수치(금액·날짜·수량)를 요구하는가. 요약(digest)은 수치를 버리므로
# 수치 need는 원문 창 안에 있어야만 "살아 있다".
NUMERIC_ATTR = {("line", "remaining"): True, ("line", "base"): True, ("inv", "qty"): True, ("lic", "seats"): True,
                ("quote", "amount"): True, ("vendor", "lead"): True, ("seatprice", "amount"): True,
                ("commit", "status"): True, ("contract", "terms"): True,
                ("emp", "profile"): False, ("asset", "holder"): False, ("receipt", "received"): False}

TARGET_EMP_PER_REGION = 20

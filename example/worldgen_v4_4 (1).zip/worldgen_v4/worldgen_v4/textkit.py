"""벤치마크 고정 토크나이저와 결정적 요약.

토크나이저: Qwen2/Qwen3 공통 byte-level BPE(일반 텍스트 토큰화는 Qwen3와 동일). 평가 모델과 독립적으로 고정한다.
assets/qwen_tokenizer.json 은 llama.cpp 의 models/ggml-vocab-qwen2.gguf 에서 만든 것이다("Hello world" → [9707, 1879]).

요약: 원문 창 밖으로 밀려난 이력은 에이전트 컨텍스트에서 요약(digest) 한 줄로만 남는다.
요약은 결정·대상·범주형 값은 남기고 수치(금액·날짜·수량·비율)는 버린다. v4.3부터 원문은 영어다. 하네스 ContextBuilder도 같은 함수를 쓴다.
"""
import hashlib, os, re
from functools import lru_cache

_TOK = None
TOKENIZER_PATH = os.path.join(os.path.dirname(__file__), "assets", "qwen_tokenizer.json")


def tokenizer():
    global _TOK
    if _TOK is None:
        from tokenizers import Tokenizer
        _TOK = Tokenizer.from_file(TOKENIZER_PATH)
    return _TOK


def tokenizer_sha():
    return hashlib.sha256(open(TOKENIZER_PATH, "rb").read()).hexdigest()[:16]


@lru_cache(maxsize=200_000)
def ntok(text):
    if not text: return 0
    return len(tokenizer().encode(text).ids)


# 수치 제거 규칙(영어 원문): 단위가 붙은 수, 천 단위 구분 금액, 날짜(day N). 부서명(Sales Team 1), 직급(grade 3), id(A-SEL-1234)는 남긴다.
_NUM = [re.compile(r"-?\d+\s*/\s*\d+\s*seats?"),                            # in use 12/30 seats
        re.compile(r"\d{1,3}(?:,\d{3})+(?:\s*KRW)?"),                         # 2,917,340 KRW / 1,000,000
        re.compile(r"\d+\s*KRW"),
        re.compile(r"\bday\s+-?\d+"),                                          # until day 14, from day -3
        re.compile(r"-?\d+\s*(?:days?|seats?|units?|%)")]                        # 3 days, 2 seats, 1 unit, 10%


def strip_numbers(text):
    # Exact structured stored values are raw evidence, never a digest side channel.
    s = text.split(" Stored value: ", 1)[0]
    for p in _NUM: s = p.sub("…", s)
    s = re.sub(r"(…\s*)+", "… ", s)
    return re.sub(r"\s+", " ", s).strip()


def summarize(text, limit=100):
    """원문 한 줄 → 결정적 요약 한 줄 (수치 제거, 길이 제한)."""
    s = strip_numbers(text)
    return s if len(s) <= limit else s[:limit - 1] + "…"

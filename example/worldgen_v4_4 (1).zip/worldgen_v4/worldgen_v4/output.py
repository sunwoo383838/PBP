"""시나리오 산출물 동결: harness/(하네스 입력), private/(정답·원장), stats.json, manifest.json."""
import collections, glob, hashlib, json, os, shutil

from . import textkit
from .const import CARD
from .templates import ANSWER_SCHEMA, FOLLOW_SURFACE, TEMPLATES

MODES = ("stale", "partial", "neardup", "wrong_owner")


def jdump(obj, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f: json.dump(obj, f, ensure_ascii=False, indent=1, default=str, sort_keys=False)


def jlines(rows, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        for r in rows: f.write(json.dumps(r, ensure_ascii=False, default=str) + "\n")


def world_hash(w):
    h = hashlib.sha256()
    h.update(json.dumps(params_dict(w.P), sort_keys=True, default=str).encode())
    h.update(json.dumps(w.rules, sort_keys=True, ensure_ascii=False).encode())
    h.update(json.dumps({k: T["surface"] for k, T in TEMPLATES.items()}, sort_keys=True, ensure_ascii=False).encode())
    h.update(json.dumps(FOLLOW_SURFACE, sort_keys=True, ensure_ascii=False).encode())
    for f in sorted(glob.glob(os.path.join(os.path.dirname(__file__), "*.py"))): h.update(open(f, "rb").read())
    h.update(textkit.tokenizer_sha().encode())
    return h.hexdigest()[:20]


def params_dict(P):
    return {k: (sorted(v) if isinstance(v, set) else v) for k, v in vars(P).items() if k != "out"}


def rate(xs): xs = list(xs); return round(sum(xs) / max(1, len(xs)), 3)
def share(counter, keys=None):
    n = sum(counter.values()); keys = keys or sorted(counter)
    return {k: round(counter.get(k, 0) / max(1, n), 3) for k in keys}


def slice_stats(w, T):
    from .generate import CLASS_TARGET, group_target
    C = collections.Counter
    comp = [s for t in T for n in t["needs"] if not n["local"] for s in n["sources"]
            if s["type"] == "frag" and s.get("role") != "distractor" and s["frag"]["fid"] in n.get("critical_components", [])]
    sub = {"C_ops": [t for t in T if t["c_ops"]], "B": [t for t in T if t["state_class"] == "B"], "repeat_changed": [t for t in T if t["repeat_changed"]]}
    return {
        "tasks": len(T),
        "state_class": share(C(t["state_class"] for t in T), list(CLASS_TARGET)),
        "group_bin": share(C(t["group_bin"] for t in T), list(group_target(w.P.D))),
        "n_groups": dict(sorted(C(t["n_groups"] for t in T).items())),
        "R": share(C(t["R"] for t in T), ["R0", "R1", "R2", "R3"]),
        "C_ops": rate(t["c_ops"] for t in T),
        "oracle": {**{k: rate(t["oracle"][k] for t in T) for k in ("db_only", "card_db", "single_holder", "stale_one_version")},
                   "all_history": None,
                   "status": "structural_estimates; all_history_not_measured"},
        "targeted_sensitivity": {"C_ops→partial": rate(t["sensitive"]["partial"] for t in sub["C_ops"]),
                                 "B→neardup|wrong_owner": rate(t["sensitive"]["neardup"] or t["sensitive"]["wrong_owner"] for t in sub["B"]),
                                 "repeat_changed→stale": rate(t["sensitive"]["stale"] for t in sub["repeat_changed"]),
                                 "n": {k: len(v) for k, v in sub.items()}},
        "sensitivity_when_applicable": {m: rate(t["sensitive"][m] for t in T if t["cf_applicable"][m]) for m in MODES},
        "cf_applicable_share": {m: rate(t["cf_applicable"][m] for t in T) for m in MODES},
        "critical_component_disc": share(C(s["frag"]["disc"] for s in comp), ["H0", "H1", "H2"]),
        "critical_component_origin": share(C(s["frag"]["origin"] for s in comp)),
        "critical_component_kind": dict(C(s["frag"]["kind"] for s in comp).most_common()),
        "critical_components_per_task": round(len(comp) / max(1, len(T)), 2),
        "follow_up_rate": rate(bool(t["follows"]) for t in T),
        "top_signature_share": round(max(C(t["signature"] for t in T).values()) / max(1, len(T)), 3) if T else 0,
        "unique_signatures": len(set(t["signature"] for t in T)),
        "templates": dict(C(t["template"] for t in T).most_common()),
        "root_domain": dict(C(t["root_domain"] for t in T).most_common()),
        "ext_count": dict(sorted(C(len(t["ext"]) for t in T).items())),
        "fallback_accepts": sum(1 for t in T if t["fallback"]),
        "dispersion": dispersion_stats(T),
        "index_key_coverage": index_coverage(w, T),
    }


def index_coverage(w, T):
    """H0·H1 결정 필수 조각 중, need가 가리키는 엔티티(sem의 부서·품목·소프트웨어·id)가 그 조각의 색인 키에 있는 비율.
    색인 한 번 조회로 보유자를 찾을 수 있는가의 상한 추정(하네스의 catalog 연결 조회는 이보다 넓다)."""
    import re
    from .const import DEPTS, ITEM_TYPES, SOFTWARE
    vocab = {d for v in DEPTS.values() for d in v} | set(ITEM_TYPES) | set(SOFTWARE)
    idrx = re.compile(r"(?:CMT|OF|INV|Q|A|V|E)-[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*")
    c = collections.Counter()
    for t in T:
        for n in t["needs"]:
            if n["local"]: continue
            ne = {p for p in n["sem"].split("/")[1:] if p in vocab or idrx.fullmatch(p)}
            g = n["group"]; reg = g.split("-")[1]
            nj = ne | {q["vendor"] for q in w.quotes.values() if q["region"] == reg and q["type"] in ne and g.startswith("PROC")}   # catalog 한 단계: 품목 → 견적 → 공급사
            crit = set(n.get("critical_components") or [])
            for s_ in n["sources"]:
                if s_["type"] != "frag" or s_["frag"]["fid"] not in crit or s_["frag"]["disc"] == "H2": continue
                d = s_["frag"]["disc"]; c[d + ":n"] += 1
                ie = set(w.frags[s_["frag"]["fid"]].get("index_entities", []))
                c[d + ":hit"] += bool(ne & ie); c[d + ":join"] += bool(nj & ie)
    return {"index_only": {d: round(c[d + ":hit"] / max(1, c[d + ":n"]), 3) for d in ("H0", "H1")},
            "index_plus_catalog_join": {d: round(c[d + ":join"] / max(1, c[d + ":n"]), 3) for d in ("H0", "H1")}}


def dispersion_stats(T):
    """세 지표를 need 단위로 따로 센다(과제 단위 중복 제거 없음).
    holders: 결정 필수 성분을 하나라도 살아 있게 가진 에이전트 수(합집합) — 정보가 얼마나 넓게 퍼졌나.
    min_cover: 성분을 모두 덮는 최소 인원 — 반드시 몇 명에게 물어야 하나(2 이상 = C, none = 살아 있는 보유자 없는 성분 있음).
    C / C_ops need 도메인 비중: 여러 사람(운영 정보)을 합쳐야 하는 need가 어느 도메인에서 생기나."""
    b = lambda k: "0" if k == 0 else ("1" if k == 1 else ("2" if k == 2 else "3+"))
    keys = ["0", "1", "2", "3+"]; C = collections.Counter
    needs = [n for t in T for n in t["needs"] if not n["local"] and n.get("critical_components")]
    remote = [n for t in T for n in t["needs"] if not n["local"]]
    dom = collections.defaultdict(C)
    for n in needs: dom[n["group"].split("-")[0]][b(n.get("n_holders", 0))] += 1
    mc = C("none" if n.get("min_cover") is None else b(n["min_cover"]) for n in needs)
    cn = C(n["group"].split("-")[0] for n in remote if n.get("class") == "C")
    co = C(n["group"].split("-")[0] for n in remote if n.get("c_ops"))
    return {"unit": "remote need with ≥1 critical component (holders, min_cover); remote need (C, C_ops)",
            "need_holders": {k: C(b(n.get("n_holders", 0)) for n in needs)[k] for k in keys},
            "need_holders_by_domain": {d: {k: c[k] for k in keys} for d, c in sorted(dom.items())},
            "need_min_cover": {k: mc[k] for k in ["1", "2", "3+", "none"]},
            "c_needs": sum(cn.values()), "c_need_domain_share": share(cn),
            "c_ops_needs": sum(co.values()), "c_ops_need_domain_share": share(co),
            "task_max_holders": share(C(b(t.get("max_holders", 0)) for t in T), keys)}


def stats(w):
    T = w.tasks; C = collections.Counter
    out = {"D": w.P.D, "R_regions": w.P.R, "G": len(w.groups), "seed": w.P.seed, "T": w.P.T, "K": w.P.K, "S": w.P.S}
    out["all"] = slice_stats(w, T)
    out["prefix"] = {f"T={x}": slice_stats(w, [t for t in T if t["day"] <= x]) for x in (10, 30, 90) if x <= w.P.T}
    wins = [(a, min(a + 9, w.P.T)) for a in range(1, w.P.T + 1, 10)]
    out["by_window"] = {f"d{a:02d}-{b:02d}": {"state_class": share(C(t["state_class"] for t in T if a <= t["day"] <= b), ["A", "B", "C", "D"]),
                                               "card_db": rate(t["oracle"]["card_db"] for t in T if a <= t["day"] <= b)} for a, b in wins}
    cand = w.candidates
    out["candidates_natural"] = {"n": len(cand), "state_class": share(C(c["cls"] for c in cand), ["A", "B", "C", "D"]),
                                 "n_groups": dict(sorted(C(c["n_groups"] for c in cand).items())), "C_ops": rate(c["cops"] for c in cand),
                                 "R": share(C(c["R"] for c in cand), ["R0", "R1", "R2", "R3"])}
    frs = [f for f in w.frags.values() if f["copy_of"] is None and f["kind"] not in ("task_result",)]
    out["fragments_all"] = {"n": len(frs), "disc": share(C(f["disc"] for f in frs), ["H0", "H1", "H2"]),
                            "origin": share(C(f["origin"] for f in frs)), "eval_only_origin": share(C(f["origin"] for f in frs if f["day"] >= 1))}
    out["world_counts"] = dict(sorted(w.counts.items()))
    out["population"] = w.pop_series[-1] if w.pop_series else {}
    out["timeline_types"] = dict(C(e["type"] for e in w.timeline if e["day"] >= 1))
    return out


def dump(w, out):
    P = w.P; wh = world_hash(w)
    if os.path.isdir(out): shutil.rmtree(out)                  # 이전 실행의 파일이 섞이지 않게
    # ── harness/: 하네스가 받는 것(에이전트 노출 범위는 하네스의 접근표가 정함) ──
    jdump({g: [{"id": r["id"], "title": r["title"], "text": r["text"]} for r in w.rules.values() if r["group"] == g] for g in w.groups},
          f"{out}/harness/rulebook.json")
    jdump({"domains": w.domains, "regions": w.regions,
           "groups": {g: {"domain": G["domain"], "region": G["region"], "topology": G["topology"]} for g, G in w.groups.items()},
           "agent_cards": {a: {"group": m["group"], "name": f"{m['group']} {m['role']}", "description": CARD[m["role"]]}
                           for a, m in w.snapshot["roster"].items() if m["active"]}}, f"{out}/harness/world_init.json")
    S = w.snapshot; sd = f"{out}/harness/snapshot_day0"
    jdump(S["catalog"], f"{sd}/catalog.json")
    jlines(S["db_registered"], f"{sd}/db_registered.jsonl")
    jdump(S["roster"], f"{sd}/roster.json"); jdump(S["cards"], f"{sd}/cards.json")
    strip = lambda d: {g: [{k: v for k, v in x.items() if k != "fid"} for x in xs] for g, xs in d.items()}     # 조각 id는 하네스에 주지 않는다
    jdump(strip(S["journal"]), f"{sd}/index/journal.json"); jdump(strip(S["activity"]), f"{sd}/index/activity.json"); jdump(S["entity_index"], f"{sd}/index/entity.json")
    for a, es in S["transcripts"].items():
        jlines([{k: e[k] for k in ("i", "day", "round", "role", "text", "tok", "summary")} for e in es], f"{sd}/transcripts/{a}.jsonl")
    jlines([e for e in w.timeline if e["day"] >= 1], f"{out}/harness/timeline.jsonl")
    jlines([{"wid": t["wid"], "day": t["day"], "round": t["round"], "seq": t["seq"], "root": t["root"], "assignee": t["assignee"],
             "surface": t["surface"], "request": t["request"], "follows": t["follows"], "answer_slots": TEMPLATES[t["template"]]["slots"],
             "answer_types": {k: ANSWER_SCHEMA[t["template"]][k] for k in TEMPLATES[t["template"]]["slots"]}} for t in w.tasks],   # 템플릿마다 고정
           f"{out}/harness/work.jsonl")
    # ── private/: 정답·원장 (시스템에 절대 마운트하지 않음) ──
    jlines(w.tasks, f"{out}/private/gold.jsonl")
    jlines(w.local_gold, f"{out}/private/gold_local.jsonl")
    jlines([{k: v for k, v in f.items()} for f in w.frags.values()], f"{out}/private/fragments.jsonl")
    jlines([{"key": "/".join(map(str, k)), **v} for k, vs in w.db.items() for v in vs], f"{out}/private/db_versions.jsonl")
    jdump(w.rules, f"{out}/private/rulebook_full.json")
    jdump({"journal": w.journal, "activity": w.activity}, f"{out}/private/index_full.json")
    jdump({"db_pending": S["db_pending"], "queue": S["queue"], "entities": S["entities"]}, f"{out}/private/snapshot_day0_private.json")
    jlines([e for e in w.timeline if e["day"] < 1], f"{out}/private/warmup_timeline.jsonl")
    for a, es in w.tx.items(): jlines(es, f"{out}/private/transcripts_full/{a}.jsonl")
    jlines(w.pop_series, f"{out}/private/population.jsonl")
    jlines(w.candidates, f"{out}/private/candidates.jsonl")
    s = stats(w); jdump(s, f"{out}/stats.json")
    jdump({"world_hash": wh, "params": params_dict(P), "tokenizer": {"name": "qwen2/qwen3 byte-level BPE", "sha": textkit.tokenizer_sha()},
           "generator": "worldgen_v4.4", "schema_version": "4.4", "canaries": len(w.canaries), "tasks": len(w.tasks)}, f"{out}/manifest.json")
    return s, wh

"""Harness-side replay of PUBLIC files only; no generator objects or gold reads.

This class belongs to the trusted harness. It does not implement agent access
control or choose a context window. Expose only an authorized group view to an
agent, and keep the future event stream private to the harness.
"""
import copy
import json
from pathlib import Path


def jsonl(path):
    with open(path, encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


class PublicReplay:
    def __init__(self, scenario):
        base = Path(scenario) / "harness"
        snap = base / "snapshot_day0"
        self.catalogs = json.loads((snap / "catalog.json").read_text(encoding="utf-8"))
        self.versions = {}
        for row in jsonl(snap / "db_registered.jsonl"):
            self.register(row["key"], row["v"], row["value"])
        self.transcripts = {p.stem: jsonl(p) for p in (snap / "transcripts").glob("*.jsonl")}
        self.events = jsonl(base / "timeline.jsonl")
        self.offset = 0
        self.cutoff = -1

    def register(self, key, version, value):
        self.versions.setdefault(key, {})[version] = copy.deepcopy(value)

    def advance_before(self, seq):
        if seq < self.cutoff: raise ValueError("Replay cannot move backwards")
        while self.offset < len(self.events) and self.events[self.offset]["seq"] < seq:
            e = self.events[self.offset]
            if e["type"] == "db_register": self.register(e["key"], e["v"], e["value"])
            elif e["type"] == "catalog_upsert":
                self.catalogs.setdefault(e["group"], {})[e["key"]] = copy.deepcopy(e["value"])
            elif e["type"] == "tx": self.transcripts.setdefault(e["agent"], []).append(e)
            self.offset += 1
        self.cutoff = seq

    def get(self, group, key, version=None):
        if not key.startswith(group + "/"): raise PermissionError("Different group")
        versions = self.versions.get(key, {})
        if not versions: return None
        return copy.deepcopy(versions.get(max(versions) if version is None else version))

    def catalog(self, group, key):
        return copy.deepcopy(self.catalogs.get(group, {}).get(key))

    def search(self, group, text):
        """Literal convenience search, not a benchmark retrieval algorithm."""
        text = text.casefold()
        rows = [{"key": k, "value": self.get(group, k)} for k in self.versions if k.startswith(group + "/")]
        rows += [{"key": k, "value": v} for k, v in self.catalogs.get(group, {}).items()]
        return [copy.deepcopy(r) for r in rows if text in json.dumps(r, ensure_ascii=False).casefold()]

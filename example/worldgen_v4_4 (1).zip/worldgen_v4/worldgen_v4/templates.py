"""추론 템플릿 15종(v4.2: capacity·sourcing·contract_gate 추가): 샘플러(세계 상태에서 파라미터를 뽑음) + 정답 함수(TW만 통해 읽음) + 과제 문장.

템플릿은 요청 그룹(root) 후보를 여러 개 가진다. 같은 추론이라도 어느 그룹에서 요청이 생기느냐에 따라
원격 need가 달라지고, 관여 그룹 수 분포를 층화 수락으로 맞출 여지가 생긴다.
정답 함수 안에는 규칙 상수가 없다. 규칙 값은 t.rule(id)로 규정 문서에서 읽는다.
R 등급은 t.op(...)로 연산을 표시하고 사후에 최댓값으로 정한다.
"""
from .const import DEPTS, ITEM_TYPES, PRICE, SOFTWARE, TIER_RANK
from .tracing import TW, legal_gate
from .world import Skip

EXT = {"proc": "PROC", "residency": "LEGAL", "contract": "LEGAL"}


def pick_emp(w, r, rr, contractor=None, transfer=False):
    es = w.active_emps(r)
    if contractor is not None:
        es = [e for e in es if (w.cur((f"HR-{r}", "emp", e, "profile"))["contract"] == "contractor") == contractor]
    if transfer:
        tr = [e for e in es if (w.transfers.get(e) or {}).get("status") == "approved"]
        if tr and rr.random() < 0.8: es = tr
    if not es: raise Skip
    return rr.choice(es)


# ── purchase: 제약 만족 ──
def s_purchase(w, rr, p):
    p["emp"] = pick_emp(w, p["r"], rr, contractor=True if ("contract" in p["ext"] and rr.random() < 0.6) else None)
    p["itype"] = rr.choice(list(ITEM_TYPES)); p["xregion"] = "proc" in p["ext"] and len(w.regions) > 1 and rr.random() < 0.4
def g_purchase(t, p):
    e, r = p["emp"], p["r"]; prof = t.hr_profile(e); dept = prof["dept"]
    avail = t.fin_available(r, dept); tmax = t.it_tier(r, prof["grade"], e)
    if "proc" in p["ext"]:
        cands = t.proc_quotes([r] + (t.w.other_regions(r)[:1] if p.get("xregion") else []), p["itype"], "purchase_max_days")
    else:
        cands = t.it_inventory(r, p["itype"])
    restricted = t.legal_residency(r) if "residency" in p["ext"] else []
    terms = ov = pol = None
    if "contract" in p["ext"] and prof["contract"] == "contractor": terms, ov, pol = t.legal_terms(e)
    if len(cands) >= 2: t.op("R3", "compare_candidates")
    first = None
    for c in sorted(cands, key=lambda c: (c["cost"], c["id"])):
        f = []
        if c["cost"] > avail: f.append("budget")
        if TIER_RANK[c["tier"]] > TIER_RANK[tmax]: f.append("eligibility")
        if c["excluded"]: f.append("vendor_excluded")
        if not c["lead_ok"]: f.append("lead_time")
        if dept in restricted and c["country"] != r: f.append("residency")
        if terms is not None and legal_gate(terms, ov, c["tier"], pol) == "deny": f.append("contract")
        if not f:
            appr, _ = t.fin_approval(r, c["cost"], prof, dept)
            return {"decision": "order" if "proc" in p["ext"] else "assign", "option": c["id"], "approver": appr,
                    "nda": terms is not None and legal_gate(terms, ov, c["tier"], pol) == "nda", "budget_after": avail - c["cost"]}
        first = first or f[0]
    return {"decision": "none", "blocked_by": first or "no_candidate"}


# ── precedence: 규정 우선순위 ──
def s_precedence(w, rr, p):
    p["emp"] = pick_emp(w, p["r"], rr, contractor=True if ("contract" in p["ext"] and rr.random() < 0.6) else None)
    p["itype"] = rr.choice(list(ITEM_TYPES)); p["tier"] = rr.choice(ITEM_TYPES[p["itype"]]); p["amount"] = w.canary(*PRICE[p["tier"]])
def g_precedence(t, p):
    e, r = p["emp"], p["r"]; prof = t.hr_profile(e)
    appr, gov = t.fin_approval(r, p["amount"], prof, prof["dept"])
    it_exc = TIER_RANK[p["tier"]] > TIER_RANK[t.it_tier(r, prof["grade"], e)]
    if "contract" in p["ext"] and prof["contract"] == "contractor":
        terms, ov, pol = t.legal_terms(e); gate = legal_gate(terms, ov, p["tier"], pol)
        if gate == "deny": return {"approver": "not_allowed", "governing_rule": "contract_deny", "it_exception": it_exc}
        if gate == "override":
            t.op("R2", "legal_override"); return {"approver": pol["override_approver"], "governing_rule": "legal_override", "it_exception": it_exc}
    return {"approver": appr, "governing_rule": gov, "it_exception": it_exc}


# ── temporal: 날짜 축 추론 ──
def s_temporal(w, rr, p):
    p["emp"] = pick_emp(w, p["r"], rr, transfer=True); p["amount"] = w.canary(700_000, 2_400_000)
    p["itype"] = rr.choice(list(ITEM_TYPES)); p["horizon"] = 20
def g_temporal(t, p):
    e, r = p["emp"], p["r"]; x = t.hr_timeline(e)
    depts = [x["dept"]] + ([x["to"]] if x["to"] else []); sched = {}
    for dp in depts:
        rem, pend = t.fin_schedule(r, dp); rd, base = t.fin_reset(r, dp)       # 재설정일이 기간 안이면 그날부터 기준 배정액
        sched[dp] = (rem, pend, rd, base)
    lead, expiry = 0, None
    if "proc" in p["ext"]:
        ok = [q for q in t.proc_quotes([r], p["itype"], "purchase_max_days") if not q["excluded"]]
        if ok: lead = min(ok, key=lambda q: (q["cost"], q["id"]))["lead"]
    if "contract" in p["ext"] and x["contract"] == "contractor":
        terms, _, _ = t.legal_terms(e, numeric=True); expiry = terms["expiry"] if terms else None
    t.op("R2", "date_axis")
    for d in range(t.day, t.day + p["horizon"] + 1):
        dep = t.dept_on(x, d); rem, pend, rd, base = sched[dep]
        line = base if (rd is not None and base is not None and d >= rd) else rem
        if p["amount"] <= t.avail_on(line, pend, d) and (expiry is None or d + lead <= expiry):
            return {"budget_dept": dep, "earliest_day": d}
    return {"budget_dept": None, "earliest_day": None}


# ── alloc: 배분 ──
def s_alloc(w, rr, p):
    p["sw"] = rr.choice(SOFTWARE); p["teams"] = rr.sample(DEPTS[p["r"]], 3)
def g_alloc(t, p):
    r = p["r"]; free = max(0, t.it_free(r, p["sw"]))
    excl = "contract" in p["ext"] and t.legal_sw_block(r, p["sw"])
    need = [t.hr_headcount(r, d, excl_contract=excl) for d in p["teams"]]
    short = max(0, sum(need) - free); transfer = 0
    if short > 0 and t.w.other_regions(r):
        o = t.w.other_regions(r)[0]; of = t.it_free(o, p["sw"]); sh = t.rule(f"IT-{r}.seat_transfer_share")
        transfer = min(short, max(0, of) * sh["share_num"] // sh["share_den"]); short -= transfer
    buy = 0
    if short > 0:
        charge = t.rule(f"FIN-{r}.seat_purchase_line")["charge_to"]
        avail = t.fin_available(r, p["teams"][{"first_team": 0}[charge]])
        price = t.proc_seat_price(r, p["sw"]) if "proc" in p["ext"] else t.rule(f"IT-{r}.seat_price")["price"]
        buy = min(short, max(0, avail) // price)
    t.op("R3", "aggregate_allocate")
    pool, alloc = free + transfer + buy, []
    for n in need: a = max(0, min(n, pool)); alloc.append(a); pool -= a
    return {"alloc": alloc, "transfer": transfer, "buy": buy, "unmet": sum(need) - sum(alloc)}


# ── diag: 진단 ──
def s_diag(w, rr, p):
    r = p["r"]; cs = sorted(c for c, x in w.commits.items() if x["group"] == f"FIN-{r}")
    if not cs: raise Skip
    c = w.commits[rr.choice(cs)]; es = sorted(e for e in w.emps if w.emps[e]["region"] == r); e = rr.choice(es)
    mine = sorted(a for a, x in w.assets.items() if e in x["history"]); allr = sorted(a for a, x in w.assets.items() if x["region"] == r)
    p.update({"cid": c["cid"], "emp": e, "asset": rr.choice(mine) if mine and rr.random() < 0.7 else rr.choice(allr),
              "amount": c["amount"] if rr.random() < 0.75 else c["amount"] + rr.choice([-1, 1]) * rr.randint(10_000, 90_000),
              "vendor": rr.choice(sorted(v for v, x in w.vendors.items() if x["region"] == r)) if w.has("PROC") else None,
              "inv": f"INV-{rr.randint(10000, 99999)}"})
def g_diag(t, p):
    r, e = p["r"], p["emp"]; fail = set(); g = t.w.commits[p["cid"]]["group"]
    t.begin(f"{g}/{p['cid']}/status", g, "payables"); c = t.commit_pick(p["cid"]); st = t.commit_state(c)
    if st is None or st["status"] == "reviewing": fail.add("COMMIT_NOT_CONFIRMED")
    elif st["status"] == "cancelled": fail.add("COMMIT_CANCELLED")
    if st and st["amount"] != p["amount"]: fail.add("AMOUNT_MISMATCH")
    prof = t.hr_profile(e)
    if prof["status"] != "active": fail.add("EMP_EXITED")
    if p["asset"] not in t.it_assets(e): fail.add("ASSET_NOT_REGISTERED")
    if "proc" in p["ext"]:
        if not t.proc_receipt(r, c["cid"]): fail.add("RECEIPT_MISSING")
        t.begin(f"PROC-{r}/vendor/{p['vendor']}/status", f"PROC-{r}", "vendors")
        for x in t.w.exclusions:
            if x["vendor"] == p["vendor"] and x["start"] <= t.day <= x["end"] and t.frag(x["fid"]): fail.add("VENDOR_EXCLUDED")
        if "VENDOR_EXCLUDED" not in fail: t.neg(f"PROC-{r} exclusion order for supplier {p['vendor']}")
    if "contract" in p["ext"] and prof["contract"] == "contractor":
        terms, _, _ = t.legal_terms(e, numeric=True)
        if terms and terms["expiry"] < t.day: fail.add("CONTRACT_EXPIRED")
    order = t.rule(f"FIN-{r}.invoice_match_precedence")["order"]; t.op("R1", "precedence_rule")
    return {"cause": next((k for k in order if k in fail), "OK")}


# ── conflict: 모순 해소 ──
def s_conflict(w, rr, p):
    r = p["r"]; cs = [c for c, x in w.commits.items() if x["group"] == f"FIN-{r}" and w.day - x["review_day"] <= 14]
    if not cs: raise Skip
    talk = [c for c in cs if w.commits[c]["talk_fid"]]
    p["cid"] = rr.choice(sorted(talk if talk and rr.random() < 0.6 else cs))
def g_conflict(t, p):
    r = p["r"]; g = t.w.commits[p["cid"]]["group"]
    t.begin(f"{g}/{p['cid']}/effective_status", g, "payables"); c = t.commit_pick(p["cid"])
    st = t.commit_state(c); t.rule(f"{g}.status_authority"); t.op("R1", "authority_rule")
    if c["talk_fid"]: t.frag(c["talk_fid"], distractor=True)            # 비권위 발언: 읽고 배제해야 함
    if st is None: return {"status": "none", "amount": 0}
    status = st["status"]
    if "proc" in p["ext"] and status == "cancelled" and t.proc_receipt(r, c["cid"]):
        if t.rule(f"PROC-{r}.no_cancel_after_receipt")["receipt_voids_cancel"]:
            status = "pending"; t.op("R2", "receipt_voids_cancel")
    return {"status": status, "amount": st["amount"] if status in ("reviewing", "pending") else 0}


# ── whatif: 반사실 ──
def s_whatif(w, rr, p):
    p["emp"] = pick_emp(w, p["r"], rr); p["itype"] = rr.choice(list(ITEM_TYPES))
    t = TW(w, "none"); prof = t.hr_profile(p["emp"]); rem, pend = t.fin_schedule(p["r"], prof["dept"])
    now = t.avail_on(rem, pend, w.day); rd, base = t.fin_reset(p["r"], prof["dept"])
    if rd is None or base is None: raise Skip
    then = t.avail_on(base, pend, rd)
    anchor = rr.choice([now, then, then]); p["amount"] = max(300_000, anchor + rr.choice([-1, 1]) * rr.randint(40_000, 500_000))
def g_whatif(t, p):
    e, r = p["emp"], p["r"]; prof = t.hr_profile(e)
    rem, pend = t.fin_schedule(r, prof["dept"]); now = t.avail_on(rem, pend, t.day)
    rd, base = t.fin_reset(r, prof["dept"])
    if rd is None or base is None: raise Skip
    then = t.avail_on(base, pend, rd); amt = p["amount"]
    if "proc" in p["ext"]: amt = amt * (100 + t.proc_price_notice(r, p["itype"], rd)) // 100
    t.op("R2", "counterfactual_date")
    return {"now": p["amount"] <= now, "later": amt <= then, "available_then": then}


# ── plan: 순서 계획 ──
def s_plan(w, rr, p):
    p["emp"] = pick_emp(w, p["r"], rr, contractor=True if ("contract" in p["ext"] and rr.random() < 0.6) else None)
    p["itype"] = rr.choice(list(ITEM_TYPES)); p["tier"] = rr.choice(ITEM_TYPES[p["itype"]]); p["amount"] = w.canary(*PRICE[p["tier"]])
    p["vendor"] = rr.choice(sorted(v for v, x in w.vendors.items() if x["region"] == p["r"])) if w.has("PROC") else None
def g_plan(t, p):
    e, r = p["emp"], p["r"]; prof = t.hr_profile(e); steps = []
    if TIER_RANK[p["tier"]] > TIER_RANK[t.it_tier(r, prof["grade"], e)]: steps.append("IT_EXCEPTION")
    if "contract" in p["ext"] and prof["contract"] == "contractor":
        terms, ov, pol = t.legal_terms(e); gate = legal_gate(terms, ov, p["tier"], pol)
        if gate == "deny": return {"steps": ["BLOCKED_CONTRACT"]}
        if gate in ("nda", "override"): steps.append("LEGAL_" + gate.upper())
    appr, _ = t.fin_approval(r, p["amount"], prof, prof["dept"]); steps.append(f"FIN_{appr.upper()}")
    if p.get("vendor") and "proc" in p["ext"]:
        reg, step = t.proc_vendor_registered(r, p["vendor"])
        if not reg: steps.append(step)
    t.op("R1", "sequence_policy")
    return {"steps": steps}


# ── vendor: 공급사 선정 ──
def s_vendor(w, rr, p):
    p["dept"] = rr.choice(DEPTS[p["r"]]); p["itype"] = rr.choice(list(ITEM_TYPES)); p["xregion"] = len(w.regions) > 1 and rr.random() < 0.5
def g_vendor(t, p):
    r = p["r"]; avail = t.fin_available(r, p["dept"])
    qs = t.proc_quotes([r] + (t.w.other_regions(r)[:1] if p["xregion"] else []), p["itype"], "vendor_max_days")
    restricted = t.legal_residency(r) if "residency" in p["ext"] else []; first = None
    if len(qs) >= 2: t.op("R3", "compare_quotes")
    for q in sorted(qs, key=lambda q: (q["cost"], q["id"])):
        f = [k for k, bad in [("budget", q["cost"] > avail), ("vendor_excluded", q["excluded"]), ("lead_time", not q["lead_ok"]),
                              ("residency", p["dept"] in restricted and q["country"] != r)] if bad]
        if not f:
            appr, _ = t.fin_approval(r, q["cost"], {"hire_day": -10**6}, p["dept"])
            return {"vendor": q["vendor"], "option": q["id"], "amount": q["cost"], "approver": appr, "budget_after": avail - q["cost"]}
        first = first or f[0]
    return {"vendor": None, "blocked_by": first or "no_candidate"}


# ── renewal: 규정 + 집합 ──
def s_renewal(w, rr, p):
    r = p["r"]; cs = [e for e in w.contractors(r) if w.day - 10 <= w.cur((f"LEGAL-{r}", "contract", e, "terms"))["expiry"] <= w.day + 40]
    if not cs: raise Skip
    p["emp"] = rr.choice(cs); p["cost"] = w.canary(200_000, 1_400_000)
def g_renewal(t, p):
    e, r = p["emp"], p["r"]; t.legal_terms(e, numeric=True); pol = t.rule(f"LEGAL-{r}.renewal_policy")
    prof = t.hr_profile(e); avail = t.fin_available(r, prof["dept"]); assets = t.it_assets(e)
    ok = prof["status"] == "active" and prof["grade"] >= pol["min_grade"] and p["cost"] <= avail
    t.op("R1", "renewal_policy")
    return {"renew": ok, "recover_assets": [] if ok else assets}


# ── budget: 파생 (규정 4.2 적용 집행 가능액) ──
def s_budget(w, rr, p):
    p["dept"] = rr.choice(DEPTS[p["r"]])
def g_budget(t, p):
    rem, pend = t.fin_schedule(p["r"], p["dept"])
    return {"available": t.avail_on(rem, pend, t.day), "n_deducted": sum(1 for _, last in pend if last >= t.day)}


# ── lookup: 조회 (음성 대조) ──
def s_lookup(w, rr, p): p["emp"] = pick_emp(w, p["r"], rr)
def g_lookup(t, p):
    prof = t.hr_profile(p["emp"]); return {"dept": prof["dept"], "grade": prof["grade"], "assets": t.it_assets(p["emp"])}


# ── v4.2: 역할 간 운영 사슬을 직접 묻는 파생 템플릿 3종 (IT·PROC·LEGAL의 증거 분산원) ──
def s_capacity(w, rr, p):
    r = p["r"]; act = sorted({h["iid"] for h in w.holds if h["region"] == r and h["start"] <= w.day <= h["end"]})
    items = sorted(i for i, x in w.inv.items() if x["region"] == r)
    p["iid"] = rr.choice(act) if act and rr.random() < 0.7 else rr.choice(items)
    x = w.inv[p["iid"]]; p["itype"], p["tier"] = x["type"], x["tier"]
    ras = sorted({x["sw"] for x in w.reservations if x["region"] == r and x["start"] <= w.day <= x["end"]})
    p["sw"] = rr.choice(ras) if ras and rr.random() < 0.7 else rr.choice(SOFTWARE)
    p["xregion"] = len(w.regions) > 1 and rr.random() < 0.6
def g_capacity(t, p):
    r = p["r"]; stock = t.it_stock(r, p["iid"]); seats = t.it_free(r, p["sw"])
    other = max(0, t.it_free(t.w.other_regions(r)[0], p["sw"])) if p.get("xregion") else None
    return {"stock": max(0, stock), "seats": max(0, seats), "seats_other_region": other}


def s_sourcing(w, rr, p):
    r = p["r"]; hot = set()
    for x in w.exclusions + w.delays:
        if x["region"] == r and x["start"] <= w.day <= x["end"]:
            hot |= {q["type"] for q in w.quotes.values() if q["vendor"] == x["vendor"]}
    p["itype"] = rr.choice(sorted(hot)) if hot and rr.random() < 0.7 else rr.choice(list(ITEM_TYPES))
    p["dept"] = rr.choice(DEPTS[r]); p["xregion"] = len(w.regions) > 1 and rr.random() < 0.5
def g_sourcing(t, p):
    r = p["r"]; qs = t.proc_quotes([r] + (t.w.other_regions(r)[:1] if p.get("xregion") else []), p["itype"], "vendor_max_days")
    restricted = t.legal_residency(r) if "residency" in p["ext"] else []
    ok = sorted((q for q in qs if not q["excluded"] and q["lead_ok"] and not (p["dept"] in restricted and q["country"] != r)),
                key=lambda q: (q["cost"], q["id"]))
    if len(qs) >= 2: t.op("R3", "compare_quotes")
    return {"options": [[q["id"], q["cost"], q["lead"]] for q in ok]}


def s_contract_gate(w, rr, p):
    r = p["r"]; cs = [e for e in w.contractors(r) if (w.cur((f"HR-{r}", "emp", e, "profile")) or {}).get("status") == "active"]
    if not cs: raise Skip
    hot = sorted({x["emp"] for x in w.overrides + w.nda_checks if x["emp"] in cs and x["start"] <= w.day <= x["end"]}
                 | {e for e in cs if w.db[(f"LEGAL-{r}", "contract", e, "terms")][-1]["db_day"] > w.day})
    p["emp"] = rr.choice(hot) if hot and rr.random() < 0.8 else rr.choice(cs)
def g_contract_gate(t, p):
    """IT 기준 최고 등급(직급 기준 + 등급 예외)과 계약 기준 최고 등급(허용 등급 또는 법무 예외)을 각각."""
    e, r = p["emp"], p["r"]; prof = t.hr_profile(e); it = t.it_tier(r, prof["grade"], e)
    terms, ov, pol = t.legal_terms(e, numeric=True)
    if terms is None: raise Skip
    t.op("R1", "contract_gate")
    legal = "premium" if ov.get("ov") else terms["allowed_tier"]
    if ov.get("ov"): t.op("R2", "legal_override")
    return {"it_tier": it, "contract_tier": legal, "nda_step": legal_gate(terms, ov, "standard", pol) == "nda", "expiry": terms["expiry"]}


ROOT_ROLE = {"HR": "records", "IT": "assets", "FIN": "payables", "PROC": "buying", "LEGAL": "contracts"}

# roots: 요청 그룹 후보 (활성 도메인만). core: 없으면 템플릿이 꺼지는 도메인. exts: 해당 도메인이 활성일 때 p_ext로 붙는 확장 제약
TEMPLATES = {
    "purchase":   {"slots": ['decision', 'option', 'approver', 'nda', 'budget_after', 'blocked_by'], "family": "constraint", "roots": ["HR", "IT"], "core": {"HR", "IT", "FIN"}, "exts": ["proc", "residency", "contract"],
                   "weight": .13, "sampler": s_purchase, "gold": g_purchase,
                   "surface": "For {alias}'s {itype} request: can it be fulfilled with the cheapest option that meets all conditions, and whose approval is needed?"},
    "precedence": {"slots": ['approver', 'governing_rule', 'it_exception'], "family": "rule", "roots": ["IT", "FIN"], "core": {"HR", "IT", "FIN"}, "exts": ["contract"],
                   "weight": .10, "sampler": s_precedence, "gold": g_precedence,
                   "surface": "We got a request from {alias} for a {itype} ({tier}) at {amount:,} KRW. Work out the approval route and which rule governs it."},
    "temporal":   {"slots": ['budget_dept', 'earliest_day'], "family": "temporal", "roots": ["IT", "FIN", "HR"], "core": {"HR", "FIN"}, "exts": ["proc", "contract"],
                   "weight": .08, "sampler": s_temporal, "gold": g_temporal,
                   "surface": "Equipment for {alias} at {amount:,} KRW: taking personnel changes into account, which department's budget can pay for it and from which day?"},
    "alloc":      {"slots": ['alloc', 'transfer', 'buy', 'unmet'], "family": "allocation", "roots": ["IT"], "core": {"HR", "IT", "FIN"}, "exts": ["proc", "contract"],
                   "weight": .09, "sampler": s_alloc, "gold": g_alloc,
                   "surface": "Allocate {sw} seats to {teams[0]}, {teams[1]}, {teams[2]} in that order, up to each team's planning headcount. If short, pull seats from another region; if still short, buy within budget."},
    "diag":       {"slots": ['cause'], "family": "diagnosis", "roots": ["FIN", "IT"], "core": {"HR", "IT", "FIN"}, "exts": ["proc", "contract"],
                   "weight": .09, "sampler": s_diag, "gold": g_diag,
                   "surface": "Invoice {inv} ({amount:,} KRW, beneficiary {alias}, asset {asset}, provisional approval {cid}) does not match. Find the cause."},
    "conflict":   {"slots": ['status', 'amount'], "family": "conflict", "roots": ["PROC", "HR", "IT"], "core": {"FIN"}, "exts": ["proc"],
                   "weight": .10, "sampler": s_conflict, "gold": g_conflict,
                   "surface": "Check whether {cid} is still live and what amount to count for it. We are hearing conflicting things."},
    "whatif":     {"slots": ['now', 'later', 'available_then'], "family": "counterfactual", "roots": ["HR", "IT"], "core": {"HR", "FIN"}, "exts": ["proc"],
                   "weight": .07, "sampler": s_whatif, "gold": g_whatif,
                   "surface": "Can a {itype} for {alias} at {amount:,} KRW go ahead right now, and if not, will it work after the next budget reset?"},
    "plan":       {"slots": ['steps'], "family": "plan", "roots": ["PROC", "IT", "HR"], "core": {"HR", "IT", "FIN"}, "exts": ["proc", "contract"],
                   "weight": .07, "sampler": s_plan, "gold": g_plan,
                   "surface": "List, in order, the approvals needed before proceeding with a {itype} ({tier}) at {amount:,} KRW for {alias}."},
    "vendor":     {"slots": ['vendor', 'option', 'amount', 'approver', 'budget_after', 'blocked_by'], "family": "constraint", "roots": ["PROC", "FIN"], "core": {"PROC", "FIN"}, "exts": ["residency"],
                   "weight": .07, "sampler": s_vendor, "gold": g_vendor,
                   "surface": "{dept} needs a {itype}. Pick a compliant supplier within budget."},
    "renewal":    {"slots": ['renew', 'recover_assets'], "family": "rule", "roots": ["LEGAL", "HR"], "core": {"LEGAL", "HR", "FIN", "IT"}, "exts": [],
                   "weight": .06, "sampler": s_renewal, "gold": g_renewal,
                   "surface": "{alias}'s contract is about to expire. Can it be renewed, and if not, which assets must be recovered?"},
    "budget":     {"slots": ['available', 'n_deducted'], "family": "derive", "roots": ["IT", "HR", "PROC", "LEGAL"], "core": {"FIN"}, "exts": [],
                   "weight": .14, "sampler": s_budget, "gold": g_budget,
                   "surface": "How much budget can {dept} actually spend right now, after all deductions?"},
    "lookup":     {"slots": ['dept', 'grade', 'assets'], "family": "lookup", "roots": ["FIN", "IT", "LEGAL", "PROC"], "core": {"HR", "IT"}, "exts": [],
                   "weight": .09, "sampler": s_lookup, "gold": g_lookup,
                   "surface": "Check {alias}'s current department, grade and assets held."},
    "capacity":   {"slots": ['stock', 'seats', 'seats_other_region'], "family": "derive", "roots": ["HR", "FIN", "PROC"], "core": {"IT"}, "exts": [],
                   "weight": .10, "sampler": s_capacity, "gold": g_capacity,
                   "surface": "How many in-house {itype} ({tier}) units and {sw} seats are actually available right now?"},
    "sourcing":   {"slots": ['options'], "family": "constraint", "roots": ["IT", "FIN", "HR"], "core": {"PROC"}, "exts": ["residency"],
                   "weight": .07, "sampler": s_sourcing, "gold": g_sourcing,
                   "surface": "{dept} will place a department order for a {itype}. List the usable quotes right now from cheapest, with quote amount and actual lead time."},
    "contract_gate": {"slots": ['it_tier', 'contract_tier', 'nda_step', 'expiry'], "family": "rule", "roots": ["FIN", "PROC", "HR"], "core": {"LEGAL", "HR", "IT"}, "exts": [],
                   "weight": .09, "sampler": s_contract_gate, "gold": g_contract_gate,
                   "surface": "For {alias}: the highest equipment tier allowed right now under IT rules (grade and tier exceptions) and under the contract (allowed tier and legal exceptions) separately, whether standard equipment needs an NDA check step, and the contract expiry day."},
}

# 답 형식: 템플릿마다 고정(답에 따라 달라지지 않음 → 슬롯 모양으로 정답이 새지 않는다). 검증기 I17이 정답이 이 형식을 따르는지 확인한다.
APPROVERS = ["team_lead", "division_head", "cfo"]
TIERS = ["basic", "standard", "premium"]
_int, _bool = {"type": "integer"}, {"type": "boolean"}
def _enum(vals, nullable=False): return {"type": "enum", "values": vals, "nullable": nullable}
def _n(x): return {**x, "nullable": True}
_ids = {"type": "array", "items": {"type": "string", "format": "id"}, "ordered": False}
ANSWER_SCHEMA = {
    "purchase": {"decision": _enum(["assign", "order", "none"]), "option": _n({"type": "string", "format": "id"}), "approver": _enum(APPROVERS, True),
                 "nda": _n(_bool), "budget_after": _n(_int),
                 "blocked_by": _enum(["budget", "eligibility", "vendor_excluded", "lead_time", "residency", "contract", "no_candidate"], True)},
    "precedence": {"approver": _enum(APPROVERS + ["legal_and_division_head", "not_allowed"]),
                   "governing_rule": _enum(["tiers", "newcomer_waiver", "q_exception", "legal_override", "contract_deny"]), "it_exception": _bool},
    "temporal": {"budget_dept": _n({"type": "string", "format": "department"}), "earliest_day": _n(_int)},
    "alloc": {"alloc": {"type": "array", "items": _int, "ordered": True, "note": "one count per team, in request order"},
              "transfer": _int, "buy": _int, "unmet": _int},
    "diag": {"cause": _enum(["EMP_EXITED", "ASSET_NOT_REGISTERED", "RECEIPT_MISSING", "VENDOR_EXCLUDED", "CONTRACT_EXPIRED",
                             "COMMIT_CANCELLED", "COMMIT_NOT_CONFIRMED", "AMOUNT_MISMATCH", "OK"])},
    "conflict": {"status": _enum(["reviewing", "pending", "settled", "cancelled", "none"]), "amount": _int},
    "whatif": {"now": _bool, "later": _bool, "available_then": _int},
    "plan": {"steps": {"type": "array", "ordered": True, "items": _enum(["IT_EXCEPTION", "LEGAL_NDA", "LEGAL_OVERRIDE", "BLOCKED_CONTRACT",
                                                                        "FIN_TEAM_LEAD", "FIN_DIVISION_HEAD", "FIN_CFO", "PROC_VENDOR_ONBOARD"])}},
    "vendor": {"vendor": _n({"type": "string", "format": "id"}), "option": _n({"type": "string", "format": "id"}), "amount": _n(_int),
               "approver": _enum(APPROVERS, True), "budget_after": _n(_int),
               "blocked_by": _enum(["budget", "vendor_excluded", "lead_time", "residency", "no_candidate"], True)},
    "renewal": {"renew": _bool, "recover_assets": _ids},
    "budget": {"available": _int, "n_deducted": _int},
    "lookup": {"dept": {"type": "string", "format": "department"}, "grade": _int, "assets": _ids},
    "capacity": {"stock": _int, "seats": _int, "seats_other_region": _n(_int)},
    "sourcing": {"options": {"type": "array", "ordered": True, "note": "cheapest first",
                             "items": {"type": "tuple", "items": [{"type": "string", "format": "id"}, _int, _int], "names": ["quote_id", "amount", "lead_days"]}}},
    "contract_gate": {"it_tier": _enum(TIERS), "contract_tier": _enum(TIERS), "nda_step": _bool, "expiry": _int},
}

FOLLOW_SURFACE = {"plan_explicit": "For the person in {handle}, we want to go ahead with a {itype} ({tier}) at that same amount. List the approvals needed, in order.",
                  "vendor": "That department from {handle} needs a {itype}. Pick a compliant supplier within budget.",
                  "lookup": "Re-check the current department, grade and assets of the person in {handle}.",
                  "plan": "We want to go ahead with {handle} as is. List the approvals needed, in order.",
                  "conflict": "Check whether the provisional approval raised for {handle} is still live and what amount to count for it."}

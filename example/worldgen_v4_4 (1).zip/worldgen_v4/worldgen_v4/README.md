# Worldgen 4.1 Python 패키지

실행 방법은 배포 루트의 README.md, 전체 설명은 GUIDE_ko.md, 검증 결과는 VALIDATION.md를 참조한다.

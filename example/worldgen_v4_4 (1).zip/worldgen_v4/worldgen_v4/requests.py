"""Public task inputs. These are request constraints, never answer/evidence labels.

Follow-ups keep inherited subject/amount in the previous interaction; only new
constraints are rendered explicitly. The harness must expose request AND surface.
"""


# 템플릿 자체가 해당 그룹을 반드시 읽는 경우(v4.2 sourcing·contract_gate 포함). 검증기 I15가 need와 대조한다.
CORE_PROC = ("vendor", "sourcing")
CORE_CONTRACT = ("renewal", "contract_gate")


def scope_for(p, name):
    ext = set(p.get("ext", []))
    x = bool(p.get("xregion", False))
    return {"procurement": "proc" in ext or name in CORE_PROC, "contract_policy": "contract" in ext or name in CORE_CONTRACT,
            "residency_policy": "residency" in ext,
            "other_regions": x and name != "capacity",              # 장비 견적 지역
            "other_region_seats": x and name == "capacity"}          # capacity: 다른 지역 좌석도 조회


def public_request(w, c):
    p = c["p"]
    q = {"region": p["r"], "scope": scope_for(p, c["name"])}
    # A follow-up still needs its earlier request/result to resolve these values.
    if not c["follow"]:
        if "emp" in p:
            e = p["emp"]
            q["subject"] = {"employee_id": e, "alias": w.emps[e]["alias"]}
        names = {"amount": "amount", "cost": "renewal_cost", "dept": "department",
                 "teams": "departments", "sw": "software", "cid": "commit_id",
                 "asset": "asset_id", "inv": "invoice_id"}
        for src, dst in names.items():
            if src in p: q[dst] = p[src]
    else:
        q["previous_work"] = c["follow"]["handle"]
    for src, dst in {"itype": "item_type", "tier": "tier", "vendor": "supplier_id",
                     "horizon": "search_days"}.items():
        if src in p and p[src] is not None: q[dst] = p[src]
    return q


def clarify_surface(text, request):
    q, s = request, request["scope"]
    notes = []
    if "item_type" in q: notes.append("item=" + q["item_type"])
    if "renewal_cost" in q: notes.append(f"renewal cost={q['renewal_cost']:,} KRW")
    if "supplier_id" in q: notes.append("target supplier=" + q["supplier_id"])
    if "search_days" in q: notes.append(f"search window=today through {q['search_days']} days later (inclusive)")
    notes.append("procurement review=" + ("apply procurement quotes, prices, receipts and registration rules" if s["procurement"] else "excluded; equipment candidates are in-house stock, seats use the standard price"))
    notes.append("contract review=" + ("included" if s["contract_policy"] else "excluded"))
    notes.append("data residency review=" + ("included" if s["residency_policy"] else "excluded"))
    notes.append("equipment quote regions=" + ("the requesting region and the first other region in the public region list" if s["other_regions"] else "requesting region only"))
    if s.get("other_region_seats"): notes.append("seat lookup regions=the requesting region and the first other region in the public region list (report each separately)")
    return text + "\n[Request scope] " + "; ".join(notes) + ". Evaluate within the optional review scope stated here."

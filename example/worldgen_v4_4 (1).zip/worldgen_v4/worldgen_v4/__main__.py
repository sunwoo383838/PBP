"""python3 -m worldgen_v4 --seed 7 --D 5 --T 30 --out out_v4"""
import argparse, heapq, json, time

from .output import dump
from .world import World
from .const import ALL_REGIONS


def params(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=7); ap.add_argument("--D", type=int, default=5); ap.add_argument("--R", type=int, default=2)
    ap.add_argument("--T", type=int, default=30, help="evaluation days; generating 90 days and truncating gives the same result (prefix invariant)")
    ap.add_argument("--warmup", type=int, default=20); ap.add_argument("--tasks_per_day", type=int, default=10)
    ap.add_argument("--K", type=int, default=8000, help="agent raw window (tokens)"); ap.add_argument("--S", type=int, default=2000, help="digest budget (tokens)")
    ap.add_argument("--out", default="out_v4")
    ap.add_argument("--local_mode", choices=["replay", "llm"], default="replay", help="local tasks: replayed as rendered lines (default) or executed by the LLM")
    P = ap.parse_args(argv)
    if P.D not in (3, 4, 5): ap.error("D must be 3, 4, or 5 (HR/IT/FIN are mandatory)")
    if not 1 <= P.R <= len(ALL_REGIONS): ap.error("R must be 1, 2, or 3")
    if min(P.T, P.warmup, P.tasks_per_day, P.K) <= 0 or P.S < 0: ap.error("positive T/warmup/tasks_per_day/K and nonnegative S required")
    # ── 세계 파라미터 ──
    P.db_lag = (1, 3); P.p_cover = 0.2; P.mu_agent = 0.012; P.p_handover = 0.3; P.p_summary_value = 0.5; P.mu_emp = 0.010; P.kappa_emp = 0.50
    P.disc_mix = [0.4, 0.4, 0.2]; P.local_per_agent = 1.2
    P.out_overhead = 220      # 에이전트 자기 출력(도구 호출·답변) 추정 토큰 — 파일럿으로 보정
    P.resp_est = 300          # 교차 요청 응대 추정 토큰(응답 측)
    P.swarm = sorted({"IT-TYO", "PROC-SEL"} & {f"{d}-{r}" for d in ["HR", "IT", "FIN", "PROC", "LEGAL"][:P.D] for r in ALL_REGIONS[:P.R]})
    P.local_mix = {"HR": [["transfer", .20], ["grade", .08], ["routine", .72]],
                   "IT": [["assign", .12], ["restock", .10], ["license", .10], ["recover", .08], ["hold", .12], ["reserve", .10], ["tier_exc", .06], ["routine", .32]],
                   "FIN": [["line_adjust", .10], ["commit_review", .28], ["earmark", .12], ["owner_exc", .04], ["q_exc", .03], ["routine", .43]],
                   "PROC": [["quote_update", .12], ["exclude", .04], ["receipt", .15], ["lead", .05], ["price_notice", .06], ["lead_delay", .05], ["routine", .53]],
                   "LEGAL": [["amend", .08], ["extend", .08], ["override", .10], ["nda_check", .10], ["routine", .64]]}
    # ── 작업 합성·수락 ──
    P.p_ext = 0.5; P.max_tries = 300; P.slack = 1.5; P.cops_min = 0.20; P.cops_aim = 0.225; P.sens_min = 0.80; P.sig_cap = 0.03; P.cooldown = 5
    P.p_follow_plan = 1.0; P.p_follow_conflict = 1.0; P.follow_target = 0.10; P.follow_slack = 8.0; P.p_follow_lookup = 0.5; P.r_weight = 0.5; P.disc_weight = 0.3
    P.dd_weight = 0.4; P.dd_slack = 3.0     # v4.2: C need 수의 도메인 균형(need 단위, 약한 축)
    return P


def run(P):
    w = World(P); w.init()
    for day in range(-P.warmup + 1, P.T + 1):
        w.day, w.round = day, 0
        if day == 1: w.phase = "eval"
        w.register_due(); w.schedule_day()
        while w.pq and w.pq[0][0] <= day:
            _, rnd, _, _, typ, payload = heapq.heappop(w.pq); w.round = rnd; w.dispatch(typ, payload)
        w.flush_index()
        w.pop_series.append({"day": day, "employees": {r: len(w.active_emps(r)) for r in w.regions},
                             "agents": {g: sum(1 for a in G["agents"] if w.active[a] and w.agent_role[a] != "worker") for g, G in w.groups.items()},
                             "workers_active": sum(1 for a, x in w.active.items() if x and w.agent_role[a] == "worker"),
                             "open_commits": sum(1 for c in w.commits.values() if (w.cur((c["group"], "commit", c["cid"], "status")) or {"status": "reviewing"})["status"] in ("reviewing", "pending"))})
        if day == 0: w.freeze_day0()
    return w


def main(argv=None):
    P = params(argv); t0 = time.time()
    w = run(P); out = f"{P.out}/D{P.D}_s{P.seed}_T{P.T}"
    s, wh = dump(w, out)
    brief = {k: s["all"][k] for k in ("tasks", "state_class", "group_bin", "R", "C_ops", "oracle", "targeted_sensitivity", "critical_component_disc",
                                      "critical_component_origin", "follow_up_rate", "top_signature_share", "fallback_accepts")}
    print(json.dumps({"out": out, "world_hash": wh, "sec": round(time.time() - t0, 1), **brief, "counts": {k: v for k, v in s["world_counts"].items() if k.startswith(("rej", "fall", "cand", "follow", "slot", "spawn", "despawn"))}}, ensure_ascii=False, indent=1))


if __name__ == "__main__": main()

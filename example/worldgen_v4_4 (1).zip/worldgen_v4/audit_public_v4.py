"""Public-input integrity audit (NOT a full-history solving oracle).

Replay reads harness/ only. The auditor separately uses private/ as expected
values to check publication, source timing, request closure and shadow lineage.
No audit result or private value should be passed to evaluated agents.
"""
import json
from pathlib import Path
from worldgen_v4.replay import PublicReplay, jsonl


def audit(scenario):
    base = Path(scenario)
    replay = PublicReplay(base)
    gold = jsonl(base / "private/gold.jsonl")
    works = {w["wid"]: w for w in jsonl(base / "harness/work.jsonl")}
    frags = {f["fid"]: f for f in jsonl(base / "private/fragments.jsonl")}
    versions = {(x["key"], x["v"]): x for x in jsonl(base / "private/db_versions.jsonl")}
    errors, checked = [], {"tasks": 0, "db_sources": 0, "catalog_sources": 0, "pending_values": 0, "public_fragments": 0}

    def require(ok, *detail):
        if not ok: errors.append(list(detail))

    for f in frags.values():
        if f["shadow"]: continue
        ancestor = f
        while ancestor.get("copy_of"):
            ancestor = frags[ancestor["copy_of"]]
            require(not ancestor["shadow"], "shadow_ancestor", f["fid"], ancestor["fid"])
        checked["public_fragments"] += 1

    for t in gold:
        replay.advance_before(t["seq"])
        wid, p, q = t["wid"], t["params"], works[t["wid"]]["request"]
        checked["tasks"] += 1
        require(q == t["request"], wid, "request_export")
        scope = q["scope"]
        for field, ext in (("procurement", "proc"), ("contract_policy", "contract"), ("residency_policy", "residency")):
            expected = ext in t["ext"] or (field == "procurement" and t["template"] in ("vendor", "sourcing")) \
                or (field == "contract_policy" and t["template"] in ("renewal", "contract_gate"))
            require(scope[field] == expected, wid, "scope", field)
        x = bool(p.get("xregion", False))
        require(scope["other_regions"] == (x and t["template"] != "capacity"), wid, "region_scope")
        require(scope.get("other_region_seats", False) == (x and t["template"] == "capacity"), wid, "seat_region_scope")
        require(q["region"] == p["r"], wid, "request_region")
        common = {"itype": "item_type", "tier": "tier", "vendor": "supplier_id", "horizon": "search_days"}
        if not t["follows"]:
            common.update({"amount": "amount", "cost": "renewal_cost", "dept": "department", "teams": "departments", "sw": "software", "cid": "commit_id", "asset": "asset_id", "inv": "invoice_id"})
            if "emp" in p:
                require(q.get("subject", {}).get("employee_id") == p["emp"], wid, "employee_input")
                require(replay.catalog(f"HR-{p['r']}", "employees/" + p["emp"]) is not None, wid, "employee_catalog")
        else:
            previous = works.get(t["follows"])
            require(previous is not None and previous["seq"] < t["seq"], wid, "previous_request")
            require(q.get("previous_work") == t["follows"], wid, "previous_handle")
        for src, dst in common.items():
            if p.get(src) is not None: require(q.get(dst) == p[src], wid, "request_parameter", src)
        for need in t["needs"]:
            for source in need["sources"]:
                typ = source["type"]
                if typ == "catalog":
                    checked["catalog_sources"] += 1
                    require(replay.catalog(source["group"], source["key"]) is not None, wid, "catalog_missing", source["key"])
                elif typ == "db":
                    checked["db_sources"] += 1
                    expected = versions[(source["key"], source["v"])]["value"]
                    require(replay.get(source["key"].split('/')[0], source["key"], source["v"]) == expected, wid, "db_value", source["key"])
                elif typ == "frag":
                    f = frags[source["frag"]["fid"]]
                    if f["shadow"]:
                        # Previous agent output is runtime-dependent, not public gold.
                        require(bool(t["follows"]) and need["local"] and f["kind"] == "task_result", wid, "unexpected_shadow_source")
                        continue
                    entries = replay.transcripts.get(f["agent"], [])
                    text = "\n".join(e["text"] for e in entries if e["i"] in f["entries"])
                    require(f["target"] in text and f["body"] in text, wid, "raw_evidence_missing", f["fid"])
                    if f["origin"] == "db_pending":
                        checked["pending_values"] += 1
                        marker = " Stored value: "
                        try: value = json.loads(f["body"].split(marker, 1)[1])
                        except (IndexError, ValueError): value = object()
                        require(value == f["value"], wid, "pending_value_not_encoded", f["fid"])
    return {"ok": not errors, "checked": checked, "errors": errors,
            "scope": "input/source integrity only; not a solving oracle; follow-up results supplied by runtime agents"}


if __name__ == "__main__":
    import sys
    reports = {p: audit(p) for p in sys.argv[1:]}
    print(json.dumps(reports, ensure_ascii=False, indent=2))
    sys.exit(0 if all(r["ok"] for r in reports.values()) else 1)

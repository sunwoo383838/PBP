# Worldgen 4.4

여러 부서·지역의 업무 세계, 사건 기록, 교차 과제와 채점용 정답을 생성한다. LLM 실행 하네스는 포함하지 않는다. Python 패키지명은 기존 호환성을 위해 worldgen_v4로 유지한다.

압축을 푼 뒤 이 README가 있는 루트에서 실행한다.

```bash
python -m pip install -r requirements.txt
python -m unittest -v
python -m worldgen_v4 --seed 7 --D 5 --R 2 --T 30 --out out
python validate_v4.py out/D5_s7_T30
python audit_public_v4.py out/D5_s7_T30
python score_answers.py out/D5_s7_T30 answers.jsonl
```

- GUIDE_ko.md: 전체 생성·실행·평가 과정과 하네스 연결 방법.
- VALIDATION.md 및 validation/: 수정본의 실제 검증 결과.
- harness/: 시점과 그룹 권한에 따라 하네스가 전달할 공개 입력.
- private/: gold와 내부 감사 원장. 에이전트에게 전달하지 않는다.

4.1은 숨은 요청 파라미터를 surface/request에 명시하고, 그룹별 catalog와 정확한 DB 변경 원문을 공개 입력에 추가한다. 좌석 이관·구매·사용량 효과와 shadow 인수인계를 수정했다. PublicReplay는 등록 버전 중 가장 큰 버전을 읽는다. 공개 입력 감사기와 exact scorer를 추가했고, 미측정 all_history는 null로 기록한다. 4.1.1은 가승인이 DB에 처음 등록되는 날에만 catalog에 올라가도록 고쳤다(검토 중인 건의 존재가 catalog로 새지 않음, 검증기 I14).

하네스는 surface와 request를 함께 전달하고 catalog 및 catalog_upsert 이벤트를 처리해야 한다. 구버전과 과제 및 토큰량이 달라지므로 모든 비교 조건을 같은 수정본에서 다시 실행한다. 출력 폴더명에는 R/K/S가 포함되지 않으므로 설정마다 다른 --out을 사용한다.

4.4는 색인 항목에 조각이 언급하는 모든 엔티티(부서·품목·소프트웨어·id·직원)를 키로 싣고, 부서 이동 기록에 원래 부서를 적는다. `stats.json`의 `index_key_coverage`로 색인 조회 상한을 보고한다.

4.3은 에이전트가 보는 모든 문장(과제, 이력, 규정, card, 요청 범위)을 영어로 생성하고, 과제마다 고정 답 형식(`answer_types`)을 싣고, 로컬 작업 결과 줄을 재생용 공개 이력으로 내보낸다(`--local_mode replay`, 기본). 하네스는 번역하지 않는다.

4.2는 specialist 그룹을 5명(서로 다른 역할 4개 + 중복 1개)으로 늘리고, 도메인마다 한 need의 결정 필수 성분이 여러 역할에 흩어지는 운영 사슬과 교차 템플릿 3개(capacity, sourcing, contract_gate)를 추가했다. C need(여러 사람의 정보를 합쳐야 하는 need)의 도메인 비중을 약한 수락축으로 맞춘다. 분산은 보유자 수, 최소 커버 인원, C·C_ops need 도메인 비중으로 나눠 보고한다. 자세한 내용은 GUIDE_ko.md의 "4.2 변경"을 본다.

이번 수정은 분포 목표를 완화하지 않았다. 층화 수락과 fallback, 교차 과제가 없는 warmup, 정답 기준으로 고정된 외생 timeline은 유지한다. 전체 이력 oracle, 실제 에이전트 실행, 비용·손실 게이트·통계 분석은 별도 하네스와 분석기가 필요하다.

import json
import tempfile
import unittest
from pathlib import Path
from score_answers import score


class ScoringTests(unittest.TestCase):
    def test_missing_boolean_and_set_order(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp); (p/'private').mkdir()
            tasks = [
                {'wid':'W1','gold':{'ok': True},'state_class':'A','template':'x','c_ops':False},
                {'wid':'W2','gold':{'assets':['a','b']},'state_class':'C','template':'x','c_ops':True},
                {'wid':'W3','gold':{'x':None},'state_class':'D','template':'x','c_ops':False}]
            (p/'private/gold.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in tasks))
            a=p/'a.jsonl'; a.write_text(json.dumps({'wid':'W1','answer':{'ok':1}})+'\n'+json.dumps({'wid':'W2','answer':{'assets':['b','a']}})+'\n')
            result=score(p,a)
            self.assertEqual(result['missing_answers'],1)
            self.assertEqual(result['metrics']['all']['correct'],1)
            a.write_text('{"wid":"W1","answer":{}}\n'*2)
            with self.assertRaises(ValueError):score(p,a)


if __name__=='__main__':unittest.main()

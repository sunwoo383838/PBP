#!/usr/bin/env python3
"""validate_v4.py — worldgen v4 산출물 검증기. 생성기 코드를 import하지 않고 산출 파일만 읽는다.

    python3 validate_v4.py <out_dir> [<out_dir> ...]

검사 항목 (규격 v3 §8 불변식 + 동결 기준)
  I1  타임라인 순서 역전 0 (워밍업 + 평가)
  I2  초기화 워커 0, spawn == despawn, 1일차 명부에 활동 중인 워커 0
  I3  정답이 쓴 규칙은 전부 규정 문서에 있음
  I4  도달 불가 need 0 (출처 존재, 조각·DB 버전·ABSENT 판정이 원장과 일치)
  I5  카나리 값 유일 (견적·가승인 금액)
  I6  과제 문장에 그룹 id·에이전트 id·내부 id·숨은 필드 0
  I7  조각 원문이 주인 이력에 그대로 있음. H2는 선행(대상) + 지시어(값) 발화, 색인 없음. H0는 일지, H1은 흔적만
  I8  설계 등급 독립 재계산 (이력 토큰·요약 토큰·활동 구간으로 창을 다시 계산해 need 등급·C_ops 비교)
  I9  하네스 디렉터리에 정답·등급 필드 누출 0, card 설명에 구체 업무 내용 0
  I10 개체수 목표 ±20% (직원 일별, 에이전트 그룹 평균)
  I11 10일 창별 로컬 발생률 ±10%, 템플릿 혼합 ±10%p
  I14 가승인 catalog는 DB 등록 이후에만
  I15 요청 범위(request.scope와 본문 [요청 범위])가 정답이 읽은 그룹을 모두 포함 (v4.2)
  I16 최소 커버 인원·보유자 수가 설계 등급과 정합 (v4.2)
  I17 정답 값이 공개 답 형식(work.jsonl answer_types)을 따름 (v4.3)
  F*  동결 기준: 상태 등급·그룹 수·R·발견성 ±5%p, card+DB 40±5, 한 명 60±5, 이력 전체 100, C_ops ≥20,
      표적 민감도 ≥80, 최대 서명 ≤3%, 명시적 후속 8~12%
"""
import bisect, collections, glob, json, os, re, sys

C = collections.Counter


def jl(p): return [json.loads(l) for l in open(p)] if os.path.exists(p) else []
def jf(p): return json.load(open(p))


class Report:
    def __init__(s): s.rows = []
    def check(s, cid, ok, detail=""): s.rows.append((cid, bool(ok), detail))
    def ok(s): return all(r[1] for r in s.rows)
    def integrity_ok(s): return all(ok for cid, ok, _ in s.rows if not cid.startswith(("F1 ", "F2 ", "F3 ", "F4 ", "F5 ", "F6 ", "F7 ", "F8 ", "I10 ", "I11 ")))
    def show(s, name):
        print(f"\n== {name} ==")
        for cid, ok, d in s.rows: print(f"  [{'PASS' if ok else 'FAIL'}] {cid:<46} {d}")
        print(f"  → integrity={'PASS' if s.integrity_ok() else 'FAIL'}; distribution={'PASS' if s.ok() else 'CHECK FAILED ROWS'}")


def validate(out):
    R = Report()
    man = jf(f"{out}/manifest.json"); P = man["params"]; K, S, D = P["K"], P["S"], P["D"]
    gold = jl(f"{out}/private/gold.jsonl"); frags = {f["fid"]: f for f in jl(f"{out}/private/fragments.jsonl")}
    tl = jl(f"{out}/harness/timeline.jsonl"); wtl = jl(f"{out}/private/warmup_timeline.jsonl")
    rules = jf(f"{out}/private/rulebook_full.json"); dbv = collections.defaultdict(list)
    for v in jl(f"{out}/private/db_versions.jsonl"): dbv[v["key"]].append(v)
    tx = {os.path.basename(p)[:-6]: jl(p) for p in glob.glob(f"{out}/private/transcripts_full/*.jsonl")}

    # I1 순서
    allt = wtl + tl; inv = sum(1 for a, b in zip(allt, allt[1:]) if (b["day"], b["round"], b["seq"]) < (a["day"], a["round"], a["seq"]))
    R.check("I1 timeline order inversions == 0", inv == 0, f"{inv} inversions / {len(allt)} events")

    # I2 워커
    sp = sum(1 for e in allt if e["type"] == "spawn"); de = sum(1 for e in allt if e["type"] == "despawn")
    init_sp = sum(1 for e in allt if e["type"] == "spawn" and e.get("phase") == "init")
    roster = jf(f"{out}/harness/snapshot_day0/roster.json")
    live_workers = [a for a, m in roster.items() if m["role"] == "worker" and m["active"]]
    R.check("I2 no init workers, spawn==despawn, 0 live workers at day0", init_sp == 0 and sp == de and not live_workers,
            f"spawn {sp} despawn {de} init {init_sp} live@day0 {len(live_workers)}")

    # I3 규칙
    refs = {s["ref"] for t in gold for n in t["needs"] for s in n["sources"] if s["type"] == "rule"}
    missing = refs - set(rules)
    R.check("I3 all gold rule refs in rulebook", not missing and all(r["text"] for r in rules.values()), f"{len(refs)} refs used, missing {sorted(missing)[:3]}")

    # I4 도달 가능성
    bad = []
    for t in gold:
        for n in t["needs"]:
            if not n["local"] and not n["sources"]: bad.append((t["wid"], n["sem"], "no_source"))
            for s in n["sources"]:
                if s["type"] == "frag":
                    f = frags.get(s["frag"]["fid"])
                    if f is None or not f["entries"] or f["agent"] not in tx: bad.append((t["wid"], n["sem"], "frag_missing"))
                elif s["type"] == "db":
                    vs = dbv.get(s["key"], [])
                    if not any(v["v"] == s["v"] and v["db_day"] <= t["day"] for v in vs): bad.append((t["wid"], s["key"], "db_version"))
                elif s["type"] == "db_query" and s.get("result") == "ABSENT":
                    if any(v["seq"] < t["seq"] for v in dbv.get(s["key"], [])): bad.append((t["wid"], s["key"], "absent_but_exists"))
    R.check("I4 unreachable / inconsistent needs == 0", not bad, f"{len(bad)} {bad[:2]}")

    # I5 카나리
    amts = collections.defaultdict(set)
    for k, vs in dbv.items():
        if "/quote/" in k:
            for v in vs: amts[v["value"]].add(k)
    dup_q = [a for a, ks in amts.items() if len(ks) > 1]
    cm = C(f["value"]["amount"] for f in frags.values() if f["kind"] == "pending_intent" and f["key"] and "/commit/" in f["key"] and f["copy_of"] is None)
    dup_c = [a for a, n in cm.items() if n > 1]
    R.check("I5 canary values unique (quotes, commits)", not dup_q and not dup_c, f"dup quotes {len(dup_q)} dup commits {len(dup_c)}")

    # I6 과제 문장
    groups = list(jf(f"{out}/harness/world_init.json")["groups"])
    pat = re.compile("|".join([re.escape(g) for g in groups] + [r"\b[a-z]+-[a-z]+\.(?:a|c|n|w)\d", r"FR-\d", r"\bneed\b", r"\bL-\d"]))
    work = jl(f"{out}/harness/work.jsonl"); leaks = [w["wid"] for w in work if pat.search(w["surface"])]
    R.check("I6 surfaces free of group/agent/internal ids", not leaks, f"{len(leaks)} leaks {leaks[:3]}")

    # I7 조각 원문·발견성·색인
    snap_tx = {os.path.basename(p)[:-6]: jl(p) for p in glob.glob(f"{out}/harness/snapshot_day0/transcripts/*.jsonl")}
    idx = jf(f"{out}/private/index_full.json")                # 조각 id가 붙은 색인(비공개). 하네스 색인에는 id가 없다
    j_f = {x["fid"]: x for g in idx["journal"].values() for x in g}; a_f = {x["fid"]: x for g in idx["activity"].values() for x in g}
    hj = jf(f"{out}/harness/snapshot_day0/index/journal.json"); ha = jf(f"{out}/harness/snapshot_day0/index/activity.json")
    hj_set = {(g, x["agent"], x["text"]) for g, xs in hj.items() for x in xs}; ha_set = {(g, x["agent"], x["trace"]) for g, xs in ha.items() for x in xs}
    ev_idx = {(x["group"], x["agent"], x.get("text") or x.get("trace")) for e in tl if e["type"] == "index_batch" for x in e["entries"]}
    attr_leak = [k for e in tl if e["type"] == "index_batch" for x in e["entries"] for k in x.get("entities", []) if "/" in str(k)]
    attr_leak += [k for g in jf(f"{out}/harness/snapshot_day0/index/entity.json").values() for k in g if "/" in k]
    errs = C()
    for f in frags.values():
        es = tx.get(f["agent"], [])
        if any(i >= len(es) for i in f["entries"]): errs["entry_oob"] += 1; continue
        if f["disc"] == "H2":
            ante, ana = es[f["entries"][0]], es[f["entries"][1]]
            if f["target"] not in ante["text"]: errs["h2_ante_no_target"] += 1
            if f["body"] not in ana["text"] or f["target"] in ana["text"]: errs["h2_ana"] += 1
            if f["fid"] in j_f or f["fid"] in a_f: errs["h2_indexed"] += 1
        else:
            if f["text"] not in es[f["entries"][0]]["text"]: errs["text_mismatch"] += 1
        if f["day"] <= 0:
            st = snap_tx.get(f["agent"], [])
            if any(i >= len(st) or st[i]["text"] != es[i]["text"] for i in f["entries"]): errs["snapshot_mismatch"] += 1
            if f["disc"] == "H0" and (f["fid"] not in j_f or j_f[f["fid"]]["text"] != f["text"] or (f["group"], f["agent"], f["text"]) not in hj_set): errs["h0_journal"] += 1
            if f["disc"] == "H1" and (f["fid"] not in a_f or f["body"] in a_f[f["fid"]]["trace"] or (f["group"], f["agent"], a_f[f["fid"]]["trace"]) not in ha_set): errs["h1_trace"] += 1
        elif not f.get("shadow"):                                  # 평가 기간 색인 증가분은 타임라인 index 이벤트로 전달돼야 함
            if f["disc"] == "H0" and (f["group"], f["agent"], f["text"]) not in ev_idx: errs["h0_index_event_missing"] += 1
            if f["disc"] == "H1" and (f["group"], f["agent"], a_f.get(f["fid"], {}).get("trace")) not in ev_idx: errs["h1_index_event_missing"] += 1
    if attr_leak: errs["index_entity_reveals_fact_type"] = len(attr_leak)
    R.check("I7 fragment text/discoverability/index", not errs, dict(errs) or f"{len(frags)} fragments ok")

    # I8 설계 등급 독립 재계산
    act = collections.defaultdict(list)                     # agent → [(seq, active)] (합류·생성·이탈·소멸 이벤트)
    for e in allt:
        if e["type"] in ("spawn", "agent_join"): act[e["agent"]].append((e["seq"], True))
        elif e["type"] in ("despawn", "agent_leave"): act[e["agent"]].append((e["seq"], False))
    def active(a, seq):
        evs = act.get(a, []); st = not (evs and evs[0][1] is True)   # 도중에 합류·생성된 에이전트는 그 전에는 없음
        for s, x in evs:
            if s < seq: st = x
        return st
    cum = {a: [] for a in tx}; scum = {a: [] for a in tx}; seqs = {a: [e["seq"] for e in es] for a, es in tx.items()}
    for a, es in tx.items():
        c1 = c2 = 0
        for e in es: c1 += e["tok"]; c2 += e["stok"]; cum[a].append(c1); scum[a].append(c2)
    def state(a, i, seq):
        n = bisect.bisect_left(seqs[a], seq)               # 과제 시점 이전 항목 수
        if i >= n: return None
        total = cum[a][n - 1]; thr = total - K
        r0 = 0 if thr <= 0 else bisect.bisect_left(cum[a], thr) + 1
        if i >= r0: return "raw"
        if not tx[a][i]["stok"]: return None
        tot = scum[a][r0 - 1] - (scum[a][i - 1] if i > 0 else 0)
        return "digest" if tot <= S else None
    def alive(fid, numeric, seq):
        f = frags[fid]; a = f["agent"]
        if not active(a, seq): return False
        if f["disc"] == "H2":
            s1, s2 = state(a, f["entries"][0], seq), state(a, f["entries"][1], seq)
            return s2 == "raw" and s1 in ("raw", "digest")
        s = state(a, f["entries"][0], seq); return s == "raw" or (s == "digest" and not numeric)
    order = {"A": 0, "B": 1, "C": 2, "D": 3}; mism = C(); cops_m = 0
    for t in gold:
        cls_all, cops = [], False
        for n in t["needs"]:
            if n["local"]: continue
            comps = [s for s in n["sources"] if s["type"] == "frag" and s.get("role") != "distractor" and s["frag"]["fid"] in n["critical_components"]]
            live = []
            for s in comps:
                ids = [s["frag"]["fid"]] + frags[s["frag"]["fid"]]["copies"]
                live.append({frags[x]["agent"] for x in ids if frags[x]["seq"] < t["seq"] and alive(x, s["frag"]["numeric"], t["seq"])})
            if not comps: cl = "A"
            elif any(not L for L in live): cl = "D"
            else:
                inter = set.intersection(*live); cl = "A" if n["card"] in inter else ("B" if inter else "C")
            ops = [L for s, L in zip(comps, live) if s["frag"]["origin"] != "db_pending"]
            nc = cl == "C" and len(ops) >= 2 and not set.intersection(*ops)
            if cl != n["class"]: mism[f"{n['class']}→{cl}"] += 1
            cls_all.append(cl); cops = cops or nc
        tc = max(cls_all, key=lambda c: order[c]) if cls_all else None
        if tc != t["state_class"]: mism["task"] += 1
        if cops != t["c_ops"]: cops_m += 1
    R.check("I8 design class re-derived independently", not mism and not cops_m, f"need/task mismatches {dict(mism)} c_ops mismatches {cops_m} ({len(gold)} tasks)")

    # I9 누출: 하네스 파일에 정답·등급·조각 표시(kind/fid)·템플릿 이름이 없어야 하고, 답 슬롯은 결과와 무관(템플릿마다 고정)
    forbidden = {"gold", "state_class", "critical_components", "counterfactual", "sensitive", "oracle", "expected", "fid", "fids", "kind", "template"}
    def keys(o):
        if isinstance(o, dict):
            for k, x in o.items(): yield k; yield from keys(x)
        elif isinstance(o, list):
            for x in o: yield from keys(x)
    hl = []
    for p in glob.glob(f"{out}/harness/**/*.json*", recursive=True):
        rows = jl(p) if p.endswith(".jsonl") else [jf(p)]
        bad_k = {k for r in rows for k in keys(r) if k in forbidden}
        if bad_k: hl.append((os.path.relpath(p, out), sorted(bad_k)))
    tmpl = {t["wid"]: t["template"] for t in gold}; slots = collections.defaultdict(set)
    for wk in work: slots[tmpl[wk["wid"]]].add((tuple(wk["answer_slots"]), json.dumps(wk.get("answer_types"), sort_keys=True)))
    varying = [k for k, s in slots.items() if len(s) > 1]
    cards = jf(f"{out}/harness/world_init.json")["agent_cards"]
    card_pat = re.compile(r"\d{3,}|\d[\d,]*\s*(?:원|KRW)|E-[A-Z]{3}|CMT-|A-[A-Z]{3}-|V-[A-Z]{3}|W-\d|INV-|Q-V")
    bad_cards = [a for a, c in cards.items() if card_pat.search(c["description"])]
    by_wid = {t["wid"]: t for t in gold}
    hidden = [t["wid"] for t in gold if t["follows"] and t["template"] == "plan" and by_wid.get(t["follows"], {}).get("template") in ("whatif", "temporal")
              and f"({t['params']['tier']})" not in t["surface"]]
    R.check("I9 no answer/fragment leaks in harness/, fixed slots, scope-only cards", not hl and not varying and not bad_cards and not hidden,
            f"leaky files {hl[:2]} varying slots {varying} bad cards {bad_cards[:2]} hidden follow params {hidden[:2]}")

    # I10 개체수
    pop = [x for x in jl(f"{out}/private/population.jsonl") if x["day"] >= 1]
    emp_bad = [(x["day"], r, n) for x in pop for r, n in x["employees"].items() if not (16 <= n <= 24)]
    ag = collections.defaultdict(list)
    for x in pop:
        for g, n in x["agents"].items(): ag[g].append(n)
    from worldgen_v4.const import ROLES
    n_g = lambda g: len(ROLES[g.split("-")[0]])                  # specialist 목표 인원 = 역할 수(v4.2: 5), swarm = coordinator 1
    ag_bad = {g: round(sum(v) / len(v), 2) for g, v in ag.items() if not (1 <= sum(v) / len(v) <= 1.2 or 0.8 * n_g(g) <= sum(v) / len(v) <= 1.2 * n_g(g))}
    R.check("I10 population within ±20% of target", not emp_bad and not ag_bad, f"employee days out {len(emp_bad)} agent groups out {ag_bad}")

    # I11 10일 창
    T = P["T"]; wins = [(a, min(a + 9, T)) for a in range(1, T + 1, 10) if min(a + 9, T) - a == 9]
    lg = jl(f"{out}/private/gold_local.jsonl")
    loc = [sum(1 for e in lg if e.get("root") and a <= e["day"] <= b) for a, b in wins]   # 뿌리 로컬 작업
    mean = sum(loc) / max(1, len(loc)); dev = max((abs(x - mean) / mean for x in loc), default=0)
    mix_all = C(t["template"] for t in gold); n_all = len(gold); mixdev = 0
    for a, b in wins:
        ts = [t for t in gold if a <= t["day"] <= b]
        for k in mix_all: mixdev = max(mixdev, abs(C(t["template"] for t in ts)[k] / max(1, len(ts)) - mix_all[k] / n_all))
    R.check("I11 10-day window rates ±10%, template mix ±10%p", dev <= 0.10 and mixdev <= 0.10, f"local counts {loc} maxdev {dev:.3f}; mix maxdev {mixdev:.3f}")

    # F 동결 기준
    N = len(gold); share = lambda cnt, k: cnt[k] / max(1, N)
    cls = C(t["state_class"] for t in gold); tgt = {"A": .40, "B": .20, "C": .25, "D": .15}
    R.check("F1 state class A/B/C/D 40/20/25/15 ±5", all(abs(share(cls, k) - v) <= .05 for k, v in tgt.items()), {k: round(share(cls, k), 3) for k in tgt})
    gt = {"2": .40, "3+": .60} if D <= 3 else ({"2": .30, "3": .40, "4+": .30} if D == 4 else {"2": .20, "3": .30, "4": .30, "5+": .20})
    gb = C(t["group_bin"] for t in gold)
    R.check("F2 group count bins ±5", all(abs(share(gb, k) - v) <= .05 for k, v in gt.items()), {k: round(share(gb, k), 3) for k in gt})
    rt = {"R0": .15, "R1": .40, "R2": .25, "R3": .20}; rc = C(t["R"] for t in gold)
    R.check("F3 R tiers 15/40/25/20 ±5", all(abs(share(rc, k) - v) <= .05 for k, v in rt.items()), {k: round(share(rc, k), 3) for k in rt})
    dc = C(s["frag"]["disc"] for t in gold for n in t["needs"] if not n["local"] for s in n["sources"]
           if s["type"] == "frag" and s["frag"]["fid"] in n["critical_components"]); nd = sum(dc.values())
    R.check("F4 discoverability of critical comps 40/40/20 ±5", all(abs(dc[k] / nd - v) <= .05 for k, v in {"H0": .4, "H1": .4, "H2": .2}.items()),
            {k: round(dc[k] / nd, 3) for k in ("H0", "H1", "H2")})
    o = {k: sum(t["oracle"][k] for t in gold) / N for k in ("card_db", "single_holder", "db_only")}
    R.check("F5 structural card+DB 40±5, single 60±5, DB ≤30", abs(o["card_db"] - .4) <= .05 and abs(o["single_holder"] - .6) <= .05
            and o["db_only"] <= .30, {k: round(v, 3) for k, v in o.items()})
    R.check("I12 all-history oracle not falsely asserted", all(t["oracle"]["all_history"] is None for t in gold), "not measured")
    from audit_public_v4 import audit
    public = audit(out)
    R.check("I13 public inputs and shadow lineage", public["ok"], public["checked"] if public["ok"] else public["errors"][:5])
    # I14 catalog에는 DB에 등록된 가승인만 (검토 중인 건의 존재는 운영 메모에만)
    cat0 = jf(f"{out}/harness/snapshot_day0/catalog.json")
    reg0 = {json.loads(l)["key"] for l in open(f"{out}/harness/snapshot_day0/db_registered.jsonl")}
    early = [k for g, v in cat0.items() for k in v if k.startswith("commits/") and f"{g}/commit/{k.split('/')[1]}/status" not in reg0]
    seen = set(reg0)
    for e in tl:
        if e["type"] == "db_register": seen.add(e["key"])
        elif e["type"] == "catalog_upsert" and e["key"].startswith("commits/"):
            if f"{e['group']}/commit/{e['key'].split('/')[1]}/status" not in seen: early.append(e["key"])
    R.check("I14 commit catalog only after DB registration", not early, f"{len(early)} early entries {early[:3]}")
    # I15 요청 범위 ⇐ 정답이 실제로 읽은 그룹 (범위 밖이라고 적어 놓고 그 그룹 정보를 정답에 쓰면 모순)
    bad_scope = []
    for t in gold:
        sc, r0 = t["request"]["scope"], t["request"]["region"]
        for n in t["needs"]:
            if n["local"]: continue
            d, reg = n["group"].split("-")
            need = []
            if d == "PROC": need.append("procurement")
            if d == "LEGAL": need.append("residency_policy" if "/residency" in n["sem"] else "contract_policy")
            if d == "PROC" and reg != r0: need.append("other_regions")
            if d == "IT" and reg != r0 and t["template"] != "alloc": need.append("other_region_seats")   # alloc은 본문이 다른 지역 이관을 명시
            for k in need:
                if not sc.get(k): bad_scope.append((t["wid"], t["template"], k))
        notes = {"procurement": "procurement review=apply", "contract_policy": "contract review=included", "residency_policy": "data residency review=included",
                 "other_regions": "equipment quote regions=the requesting region and", "other_region_seats": "seat lookup regions="}
        for k, txt in notes.items():
            if bool(sc.get(k)) != (txt in t["surface"]): bad_scope.append((t["wid"], t["template"], "surface:" + k))
    R.check("I15 request scope covers every group the gold reads", not bad_scope, f"{len(bad_scope)} {sorted(set(bad_scope))[:4]}")
    # I16 분산 지표 정합: 최소 커버 인원 1 ⇔ A/B, ≥2 ⇔ C, 없음 ⇔ D; 합집합 보유자 수 ≥ 최소 커버
    bad_mc = []
    for t in gold:
        for n in t["needs"]:
            if n["local"] or not n.get("critical_components"): continue
            mc, cl, nh = n.get("min_cover"), n.get("class"), n.get("n_holders", 0)
            ok = (cl in ("A", "B") and mc == 1) or (cl == "C" and mc is not None and mc >= 2) or (cl == "D" and mc is None)
            if not ok or (mc is not None and nh < mc): bad_mc.append((t["wid"], n["sem"], cl, mc, nh))
    R.check("I16 min_cover consistent with class, holders ≥ min_cover", not bad_mc, f"{len(bad_mc)} {bad_mc[:3]}")
    # I17 정답 값이 공개 답 형식(answer_types)을 따른다
    def conforms(v, ty):
        if v is None: return bool(ty.get("nullable"))
        t_ = ty["type"]
        if t_ == "integer": return isinstance(v, int) and not isinstance(v, bool)
        if t_ == "boolean": return isinstance(v, bool)
        if t_ == "string": return isinstance(v, str)
        if t_ == "enum": return v in ty["values"]
        if t_ == "array": return isinstance(v, list) and all(conforms(x, ty["items"]) for x in v)
        if t_ == "tuple": return isinstance(v, list) and len(v) == len(ty["items"]) and all(conforms(x, s_) for x, s_ in zip(v, ty["items"]))
        return False
    types_of = {wk["wid"]: wk.get("answer_types") or {} for wk in work}
    bad_ty = [(t["wid"], k) for t in gold for k, v in t["gold"].items() if k not in types_of[t["wid"]] or not conforms(v, types_of[t["wid"]][k])]
    R.check("I17 gold values conform to the public answer types", not bad_ty, f"{len(bad_ty)} {bad_ty[:4]}")
    cops = sum(t["c_ops"] for t in gold) / N
    R.check("F6 C_ops ≥ 20%", cops >= .20, round(cops, 3))
    sub = [("C_ops→partial", [t for t in gold if t["c_ops"]], lambda t: t["sensitive"]["partial"]),
           ("B→neardup|wrong_owner", [t for t in gold if t["state_class"] == "B"], lambda t: t["sensitive"]["neardup"] or t["sensitive"]["wrong_owner"]),
           ("repeat_changed→stale", [t for t in gold if t["repeat_changed"]], lambda t: t["sensitive"]["stale"])]
    sv = {n: round(sum(map(f, ts)) / max(1, len(ts)), 3) for n, ts, f in sub}
    R.check("F7 targeted sensitivity ≥ 80%", all(v >= .80 for v in sv.values()), sv)
    top = max(C(t["signature"] for t in gold).values()) / N; fu = sum(1 for t in gold if t["follows"]) / N
    R.check("F8 top signature ≤ 3%, explicit follow-ups 8–12%", top <= .03 + 1e-9 and .08 <= fu <= .12, f"top {top:.3f} follow {fu:.3f}")
    R.check("F9 task count", N == P["T"] * P["tasks_per_day"], f"{N} / {P['T'] * P['tasks_per_day']}")
    return R


if __name__ == "__main__":
    strict = "--integrity-only" not in sys.argv
    allok = True
    for out in (a for a in sys.argv[1:] if a not in ("--strict-distribution", "--integrity-only")):
        r = validate(out); r.show(out); allok &= r.ok() if strict else r.integrity_ok()
    sys.exit(0 if allok else 1)

"""Small regression tests for the audited bugs. Run: python -m unittest -v."""
import copy
import unittest
from worldgen_v4.__main__ import params
from worldgen_v4.world import World
from worldgen_v4.requests import public_request, clarify_surface
from worldgen_v4.replay import PublicReplay
from worldgen_v4.textkit import summarize


class RegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.initial = World(params(["--seed", "7", "--D", "5", "--T", "1"]))
        cls.initial.init()

    def world(self):
        w = copy.deepcopy(self.initial)
        w.day, w.round, w.phase = 1, 1, "eval"
        return w

    def test_hidden_constraints_are_public(self):
        w = self.world()
        base = {"name": "purchase", "follow": None, "p": {"r": "SEL", "ext": [], "emp": "E-SEL-1000", "itype": "laptop", "xregion": False}}
        a = public_request(w, base)
        for key, value in [("ext", ["proc"]), ("ext", ["contract"]), ("ext", ["residency"]), ("xregion", True)]:
            b = copy.deepcopy(base); b["p"][key] = value
            q = public_request(w, b)
            self.assertNotEqual(a, q)
            self.assertNotEqual(clarify_surface("요청", a), clarify_surface("요청", q))

    def test_cost_supplier_horizon_and_core_scope(self):
        w = self.world()
        c = {"name": "renewal", "follow": None, "p": {"r": "SEL", "ext": [], "emp": "E-SEL-1000", "cost": 123456}}
        q = public_request(w, c)
        self.assertEqual(q["renewal_cost"], 123456)
        self.assertTrue(q["scope"]["contract_policy"])
        self.assertIn("123,456", clarify_surface("연장", q))
        c.update(name="temporal", p={"r": "SEL", "ext": ["proc"], "itype": "monitor", "horizon": 20, "vendor": "V-SEL-3"})
        q = public_request(w, c)
        self.assertEqual((q["search_days"], q["supplier_id"], q["item_type"]), (20, "V-SEL-3", "monitor"))

    def test_followup_preserves_history_dependency(self):
        w = self.world()
        c = {"name": "plan", "follow": {"handle": "W-00001"}, "p": {"r": "SEL", "ext": [], "emp": "E-SEL-1000", "amount": 123456, "tier": "standard", "itype": "monitor"}}
        q = public_request(w, c)
        self.assertEqual(q["previous_work"], "W-00001")
        self.assertNotIn("subject", q)
        self.assertNotIn("amount", q)

    def test_catalog_and_exact_delayed_value(self):
        w = self.world()
        item = "INV-SEL-MNB"
        self.assertEqual(w.catalog["IT-SEL"]["inventory/"+item]["cost"], w.inv[item]["cost"])
        fid = w.write("IT-SEL", "inv", item, "qty", 19, "it-sel.a1", "재고", "입고 반영.", lag=3, disc="H2")
        f = w.frags[fid]
        self.assertIn("Stored value: 19", w.tx[f["agent"]][f["entries"][1]]["text"])
        self.assertGreater(w.db[("IT-SEL", "inv", item, "qty")][-1]["db_day"], w.day)
        self.assertNotIn("Stored value", summarize("Receipt added. Stored value: 19"))

    def test_shadow_does_not_escape_handover(self):
        w = self.world()
        src = "hr-sel.a1"
        w.frag("HR-SEL", src, "task_result", "operational", ("task", "W-TEST", "result"), {"answer": 998877}, "W-TEST 건", "결과: answer=998877", True, shadow=True)
        w.active[src] = False
        w.agent_join({"group": "HR-SEL", "agent": "hr-sel.test", "role": "records", "from": src, "handover": True})
        self.assertFalse(any("998877" in e.get("text", "") for e in w.timeline))

    def test_seats_conserve_supply_and_increase_use(self):
        w = self.world()
        for r in ("SEL", "TYO"):
            key = (f"IT-{r}", "lic", "CAD", "seats")
            w.db[key][-1]["value"] = {"seats": 20, "used": 5}
        before = sum(w.cur((f"IT-{r}", "lic", "CAD", "seats"))["seats"] for r in ("SEL", "TYO"))
        w.apply_seat_allocation({"r": "SEL", "sw": "CAD", "allocate": 8, "transfer": 3, "buy": 2, "handle": "W-TEST"})
        dst = w.cur(("IT-SEL", "lic", "CAD", "seats"))
        src = w.cur(("IT-TYO", "lic", "CAD", "seats"))
        self.assertEqual(dst, {"seats": 25, "used": 13})
        self.assertEqual(src, {"seats": 17, "used": 5})
        self.assertEqual(src["seats"] + dst["seats"], before + 2)

    def test_capacity_race_is_explicit_failure(self):
        w = self.world()
        key = ("IT-SEL", "lic", "CAD", "seats")
        w.db[key][-1]["value"] = {"seats": 20, "used": 20}
        before = copy.deepcopy(w.cur(key))
        w.apply_seat_allocation({"r": "SEL", "sw": "CAD", "allocate": 8, "transfer": 0, "buy": 0, "handle": "W-TEST"})
        self.assertEqual(w.cur(key), before)
        self.assertTrue(any(e.get("event") == "seat_allocation_failed" for e in w.timeline))

    def test_db_out_of_order_registration(self):
        replay = PublicReplay.__new__(PublicReplay)
        replay.versions = {}
        replay.register("HR-SEL/x", 3, "new")
        replay.register("HR-SEL/x", 2, "old")
        self.assertEqual(replay.get("HR-SEL", "HR-SEL/x"), "new")
        self.assertEqual(replay.get("HR-SEL", "HR-SEL/x", 2), "old")
        with self.assertRaises(PermissionError): replay.get("FIN-SEL", "HR-SEL/x")

    # ── v4.2: 역할 5개와 역할 간 운영 사슬 ──
    def test_v42_five_roles_per_specialist_group(self):
        from worldgen_v4.const import ROLES, CARD
        w = self.world()
        for g, G in w.groups.items():
            if G["topology"] != "specialist": continue
            self.assertEqual(sorted(w.agent_role[a] for a in G["agents"]), sorted(ROLES[G["domain"]]))
            self.assertEqual(len(set(ROLES[G["domain"]])), 4)
        for role in ("mobility", "provisioning", "control", "quality", "review"):
            self.assertNotRegex(CARD[role], r"\d")

    def test_v42_planning_headcount_counts_offer_and_transfer(self):
        from worldgen_v4.tracing import TW
        w = self.world(); r = "SEL"; g = f"HR-{r}"; dept = "Sales Team 1"
        base = TW(w, "IT-SEL").hr_headcount(r, dept)
        w.phase = "eval"; import random; rr = random.Random(0)
        w.L_HR_offer(g, r, rr); w.offers[-1]["dept"] = dept; w.offers[-1]["contract"] = "regular"; w.offers[-1]["start"] = w.day + 3
        t = TW(w, "IT-SEL"); n = t.hr_headcount(r, dept)
        self.assertEqual(n, base + 1)
        self.assertEqual(w.agent_role[w.frags[w.offers[-1]["fid"]]["agent"]], "recruiting")
        t2 = TW(w, "IT-SEL", ("partial", "all")); self.assertEqual(t2.hr_headcount(r, dept), base)

    def test_v42_core_scope_of_new_templates(self):
        w = self.world()
        cases = [("sourcing", {"itype": "laptop", "dept": "Sales Team 1", "xregion": True}, {"procurement": True, "other_regions": True}, "procurement review=apply"),
                 ("contract_gate", {"emp": "E-SEL-1000"}, {"contract_policy": True}, "contract review=included"),
                 ("capacity", {"iid": "INV-SEL-MNB", "itype": "monitor", "tier": "basic", "sw": "CAD", "xregion": True},
                  {"other_region_seats": True, "other_regions": False, "procurement": False}, "seat lookup regions=")]
        for name, extra, want, note in cases:
            q = public_request(w, {"name": name, "follow": None, "p": {"r": "SEL", "ext": [], **extra}})
            for k, v in want.items(): self.assertEqual(q["scope"][k], v, (name, k))
            self.assertIn(note, clarify_surface("요청", q), name)

    def test_v42_min_cover(self):
        from worldgen_v4.generate import min_cover
        self.assertEqual(min_cover([{"a", "b"}, {"a"}]), 1)          # 합집합은 2명이어도 한 명이 다 가짐
        self.assertEqual(min_cover([{"a"}, {"b"}, {"a", "c"}]), 2)
        self.assertEqual(min_cover([{"a"}, {"b"}, {"c"}]), 3)
        self.assertIsNone(min_cover([{"a"}, set()]))

    def test_v43_replay_local_results_are_public(self):
        w = self.world(); w.phase = "eval"
        ctx = w.task("HR-SEL", "hr-sel.a1", "routine", "Answer a remaining-leave inquiry"); w.done(ctx, "Answered", expected=[])
        e = w.tx["hr-sel.a1"][-1]
        self.assertFalse(e["shadow"]); self.assertEqual(e["tok_est"], 0)
        self.assertTrue(any(x.get("type") == "tx" and x.get("text") == "[Result] Answered" for x in w.timeline))

    def test_v43_answer_schema_fixed_and_complete(self):
        from worldgen_v4.templates import ANSWER_SCHEMA, TEMPLATES
        for k, T in TEMPLATES.items(): self.assertEqual(list(ANSWER_SCHEMA[k]), T["slots"], k)

    def test_v44_index_entities_cover_departments_and_ids(self):
        import random
        w = self.world(); w.phase = "eval"
        w.L_HR_transfer("HR-SEL", "SEL", random.Random(3))
        f = next(x for x in reversed(list(w.frags.values())) if x["kind"] == "pending_intent" and x["key"] and x["key"].endswith("/transfer"))
        emp = f["key"].split("/")[2]; frm = w.cur(("HR-SEL", "emp", emp, "profile"))["dept"]
        ents = w.entities(("HR-SEL", "emp", emp, "transfer"), f"{f['target']} {f['body']}")
        self.assertIn(emp, ents); self.assertIn(f["value"]["to"], ents); self.assertIn(frm, ents)
        self.assertFalse(any("/" in k for k in ents))

    def test_v42_nda_check_clears_gate(self):
        from worldgen_v4.tracing import legal_gate
        pol = {"premium_requires_override": True, "above_allowed_requires_override": True, "standard_with_nda": "nda", "nda_confirmation_clears": True}
        terms = {"allowed_tier": "standard", "nda": True}
        self.assertEqual(legal_gate(terms, {"ov": None, "nda": None}, "standard", pol), "nda")
        self.assertEqual(legal_gate(terms, {"ov": None, "nda": {"emp": "x"}}, "standard", pol), "ok")
        self.assertEqual(legal_gate(terms, {"ov": {"emp": "x"}, "nda": None}, "premium", pol), "override")


if __name__ == "__main__": unittest.main()

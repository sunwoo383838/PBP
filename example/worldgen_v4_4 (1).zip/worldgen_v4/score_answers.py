"""Deterministic task-level exact scoring; scorer-only access to private/gold.
Usage: python score_answers.py SCENARIO ANSWERS.jsonl
Answers: one {"wid": "W-00001", "answer": {...all answer_slots...}} per task.
This does not run agents, compute causal loss gates or statistical intervals.
"""
import collections
import json
import sys
from pathlib import Path
from worldgen_v4.replay import jsonl


def canonical(answer):
    if not isinstance(answer, dict): return None
    answer = dict(answer)
    for field in ("assets", "recover_assets"):
        if field in answer and isinstance(answer[field], list):
            if not all(isinstance(x, str) for x in answer[field]): return None
            answer[field] = sorted(answer[field])
    return json.dumps(answer, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def score(scenario, answers_path):
    gold = jsonl(Path(scenario) / "private/gold.jsonl")
    ids = {t["wid"] for t in gold}
    answers = {}
    for row in jsonl(answers_path):
        wid = row.get("wid")
        if wid not in ids: raise ValueError(f"Unknown work id: {wid}")
        if wid in answers: raise ValueError(f"Duplicate work id: {wid}")
        answers[wid] = row.get("answer")
    groups = collections.defaultdict(lambda: {"n": 0, "correct": 0})
    for t in gold:
        answer = answers.get(t["wid"])
        good = isinstance(answer, dict) and set(answer) == set(t["gold"]) and canonical(answer) == canonical(t["gold"])
        for group in ["all", "class:" + t["state_class"], "template:" + t["template"]] + (["C_ops"] if t["c_ops"] else []):
            groups[group]["n"] += 1
            groups[group]["correct"] += int(good)
    return {"missing_answers": len(ids - set(answers)),
            "metrics": {g: {**v, "Acc_exact": v["correct"] / v["n"]} for g, v in sorted(groups.items())}}


if __name__ == "__main__":
    if len(sys.argv) != 3: raise SystemExit(__doc__)
    print(json.dumps(score(*sys.argv[1:]), ensure_ascii=False, indent=2))
